#include <iostream>
#include <fstream>
#include <cstdio>
#include <vector>
#include <map>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

using namespace std;

#include "Utils2.h"
#include "MarginalTree.h"
#include "SprILP.h"
#include "Network.h"

//*****************************************************************************
// Test Code only
// ***************************************************************************



//*****************************************************************************
// Global data
// ***************************************************************************
int minCutLB = -1;


// ***************************************************************************
// Main for computing lower bound
// ***************************************************************************
static void Usage()
{
	cout << "Usage: SPRDist -N <INPUT-FILE-NAME-NEWICK>  -L k. " << endl;
	cout << "Usage: SPRDist -T <INPUT-FILE-1> <INPUT-FILE-2> " << endl;
	cout << "Usage: SPRDist -F <INPUT-FILE-NAME>  -L k. " << endl;
    cout << "Or use SPRDist -R numLeaves numTests" << endl;
    cout << "Or use SPRDist -M matrix.dat" << endl;
	exit(1);
}

// Parameters
static bool fTreesFile = false;
static bool fTwoTreesFiles = false;
static bool fMatrixFile = false;
static bool fTreesFileNewick = false; 
char *fileName = NULL;
char *fileName2 = NULL;
static int numRandLeaves = -1;
static int numRandTests = -1;


// GLobal variables

// Local functions
static bool CheckArguments(int argc, char **argv) 
{
    if( argc == 1  )
    {
        return false;
    }

    // Check argument one by one
    int argpos = 1;
    while( argpos < argc)
    {
        // 
        if( argv[ argpos ][ 0 ] != '-' )
        {
            // must have this
            return false;
        }
        
        if( argv[argpos][1] == 'F' )
        {
            // setup filename
            argpos ++;
            fTreesFile = true;
            fileName = argv[argpos];
            argpos++;
//cout << "Set tree files name = " << fileName << endl;
//            return true;
        }
        else if( argv[argpos][1] == 'N' )
        {
            // setup filename
            argpos ++;
            fTreesFileNewick = true;
            fileName = argv[argpos];
            argpos++;
//cout << "Set tree files name = " << fileName << endl;
//            return true;
        }
        else if( argv[argpos][1] == 'T' )
        {
            // setup filename
            argpos ++;
            fTwoTreesFiles = true;
            fileName = argv[argpos];
            argpos++;
			fileName2 = argv[argpos];
            argpos++;
//cout << "Set tree first files name = " << fileName << endl;
//cout << "Set tree second files name = " << fileName2 << endl;
//            return true;
        }
        else if( argv[argpos][1] == 'R' )
        {
            // read in the number of trees
            argpos++;
            sscanf( argv[argpos],  "%d", &numRandLeaves );
            argpos++;
            sscanf( argv[argpos],  "%d", &numRandTests );
cout << "Set numLeaves = " << numRandLeaves << ", numTests = " << numRandTests << endl;
            argpos++;
//            return true;
        }
        else if( argv[argpos][1] == 'L' )
        {
            if( fTreesFile == false )
            {
                return false;
            }
            argpos++;
            sscanf( argv[argpos],  "%d", &minCutLB );
            argpos++;
cout << "Set known Lower Bound = " << minCutLB << endl;

        }
        else if( argv[argpos][1] == 'M' )
        {
            if( fTreesFile == true )
            {
                return false;
            }
            fMatrixFile = true;
            argpos++;
            fileName = argv[argpos];
            argpos++;
cout << "Set matrix files name = " << fileName << endl;
        }
        else
        {
            return false;
        }
    }


    return true;
}


// test by picking two uniform trees
static void TestUniformTrees( int numLeaves, int numTests )
{
    int totSPRDist = 0;
    int totSPRDistHeuris = 0;
    for( int t = 0; t<numTests; ++t )
    {
cout << "Test t = " << t << endl;
        MarginalTree tree1, tree2;
        GenRandBinaryTree(numLeaves, tree1);
        GenRandBinaryTree(numLeaves, tree2);

        // now preprocess the trees
        AddRootAsLeafToTree( tree1 );
        AddRootAsLeafToTree( tree2 );
        MarginalTree tree1Red, tree2Red;
        ReducePairTreesMAF( tree1, tree2, tree1Red, tree2Red);

        if(numTests == 1)
        {
            OutputILPMaxAgreeForest("maf.lp", tree1Red, tree2Red );
            OutputILPMaxAgreeForestTest("maf1.lp", tree1Red, tree2Red );
            OutputILPMaxAgreeForestTest2("maf2.lp", tree1Red, tree2Red );
            OutputILPMaxGoodAgreeForest( "mafg.lp", tree1Red, tree2Red );
            cout << "ILP file maf.lp outputed.\n";
        }

int numItems = HeurisTreeCut(tree1, tree2);
cout << "Heuristc cut size = " << numItems << endl;
continue;

//cout << "Random tree1 = \n";
//tree1.Dump();
        ILPSolverSPR solver( tree1Red, tree2Red );
        int distSPR = solver.ComputeILP();
        cout <<  "For test " << t <<  ", the rSPR distance between two trees = " << distSPR << endl;
        totSPRDist += distSPR;

        vector<int> cutEdges;
        solver.GetCutEdges(cutEdges);
        cout << "The edges cut in MAF = ";
        DumpIntVec( cutEdges );

        if( IsMAFGood( tree1Red, cutEdges, tree2Red ) == true)
        {
            cout << "This is a good MAF.\n";
        }
        else
        {
            cout << "Warning: this is a BAD MAF.\n";
        }


        int distSPRHeuris = solver.ComputeHeuristic();
        totSPRDistHeuris += distSPRHeuris;
        cout << "The rSPR (heuristic) distance between two trees = " << distSPRHeuris << endl;


    }
    cout << "The average SPR distance = " << (double)totSPRDist/numTests << endl;
    cout << "The average SPR (heuristic) distance = " << (double)totSPRDistHeuris/numTests << endl;
}

static void OutputNewickMargTree( MarginalTree *ptree )
{
	// first get par pos
	vector<int> parPosList;
	ptree->GetParPosInfo( parPosList );

	// 
	PhylogenyTree phtree;
	phtree.ConsOnParPosList( parPosList );
	string strNewick;
	phtree.ConsNewick(strNewick);
	cout << "Tree = " << strNewick << endl;
}



//******************************************************************
int main(int argc, char **argv)
{

//    int seq = 0x001;
//    int seqMut;
//    MutateHCSeqAt(seq, seqMut, 4, 2);
//cout << "mutated seq = " << seqMut << endl;

	// first verify usage
	if( CheckArguments(  argc, argv  ) == false)
	{
		Usage(); 
	}

    if( (fTreesFile == true || fTreesFileNewick == true || fTwoTreesFiles == true) && fileName != NULL)
    {

        // Open the file
    //cout << "Genotype data = " <<  argv[fileArgIndex] << endl;
	    ifstream inFile( fileName );
	    if(!inFile)
	    {
		    cout << "Can not open "<< fileName <<endl;
		    exit(1);
	    }

		bool fLabelNOAdjByDecOne = true;
		vector<MarginalTree> listTrees;
		if( fTreesFile == true )
		{
			// If the inputs are given trees, then we just read in trees and run tests
			// read in the set of trees 
			ReadinMarginalTrees( inFile, listTrees );
		}
		else if(fTreesFileNewick == true)
		{
			// read Newick form here
			// use -1 to indicate trees are really just binary
			if( ReadinMarginalTreesNewick(  inFile, -1, listTrees  ) == false )
			{
				fLabelNOAdjByDecOne = false;
			}
		}
		else
		{
			// now specify two files
			if( ReadinMarginalTreesNewick(  inFile, -1, listTrees  ) == false )
			{
				fLabelNOAdjByDecOne = false;
			}
			vector<MarginalTree> listTrees2;
			ifstream inFile2( fileName2 );
			if(!inFile2)
			{
				cout << "Can not open "<< fileName2 <<endl;
				exit(1);
			}
			ReadinMarginalTreesNewick(  inFile2, -1, listTrees2  );
			listTrees.push_back( listTrees2[0] );
			inFile2.close();

		}


        inFile.close();

        // now compute SPR dist between two trees
        // make sure only two trees are inputed
        if( listTrees.size() <= 1 )
        {
            cout << "You need to input two trees to compute SPR distance\n";
            exit(1);
        }

        if( listTrees.size() > 2 )
        {
            cout << "Warning: we normally assume only two trees. Since you input contains more than 2 trees,\n";
            cout << "We simply compute the first and the last tree\n";
        }

		// for debugging purpose
		listTrees[0].OutputGML( "t1.gml" );
		listTrees[listTrees.size()-1].OutputGML( "t2.gml" );

		// dump out trees
		//listTrees[0].Dump();
		//listTrees[  listTrees.size()-1  ].Dump();
		//OutputNewickMargTree( &listTrees[0]);
		//OutputNewickMargTree( &listTrees[  listTrees.size()-1  ] );

        // now preprocess the two trees
        AddRootAsLeafToTree( listTrees[0] );
        AddRootAsLeafToTree( listTrees[ listTrees.size()-1 ] );
        MarginalTree tree1, tree2;
		vector< pair<int,int> > listRmHistory;
		vector<int> listSurviors;
        ReducePairTreesMAF(listTrees[0], listTrees[ listTrees.size()-1 ], tree1, tree2, &listRmHistory, &listSurviors);

		// report how many leaves still remain
		cout << "After data reduction, the trees have " << tree1.GetNumLeaves() << " leaves\n";

//
//cout << "Output one ILP file\n";
//OutputILPMaxAgreeForestVarReduced("maf-red.lp", tree1, tree2 );
//OutputILPMaxAgreeForest("maf.lp", tree1, tree2 );
        //OutputILPMaxAgreeForestTest("maf1.lp", tree1, tree2 );
        //OutputILPMaxAgreeForestTest2("maf2.lp", tree1, tree2 );
        //OutputILPMaxGoodAgreeForest( "mafg.lp", tree1, tree2 );
        //OutputILPMaxGoodAgreeForestTest( "mafgt.lp", tree1, tree2 );
        //cout << "ILP file maf.lp outputed.\n";


        //int numItems = HeurisTreeCut(tree1, tree2);
        //cout << "Heuristc cut size = " << numItems << endl;
//YW_ASSERT_INFO(false, "early abort");
        // now use ILP to directly solve it
        // timestamp it
        long tstart1 = GetCurrentTimeTick();

        ILPSolverSPR solver( tree1, tree2 );
        int distSPR = solver.ComputeILP();
        cout << "The rSPR distance between two trees = " << distSPR << endl;
        vector<int> cutEdges;
        solver.GetCutEdges(cutEdges);
//        cout << "The edges cut in MAF = ";
//        DumpIntVec( cutEdges );

        if( IsMAFGood( tree1, cutEdges, tree2 ) == true)
        {
            cout << "This is a GOOD MAF.\n";
        }
        else
        {
            cout << "Warning: this is a BAD MAF.\n";
        }
		vector< set<int> > ssLeavesByCuts;
		tree1.GetLeafSetsForCuts( cutEdges, ssLeavesByCuts );
		vector<int> listParentsTree1;
		for( int ii=0; ii<(int)ssLeavesByCuts.size(); ++ii )
		{
			vector<int> ssLeavesInCut;
			PopulateVecBySet(ssLeavesInCut, ssLeavesByCuts[ii]);
			set<int> setOrigLeaves;
			RecoverOrigSubsetLeaves( ssLeavesInCut, listRmHistory, listSurviors, setOrigLeaves  );

			// here if we have decreased before, now add it back
			if( fLabelNOAdjByDecOne == false )
			{
				set<int> setLabelsNew;
				for( set<int> :: iterator it = setOrigLeaves.begin(); it != setOrigLeaves.end(); ++it)
				{
					setLabelsNew.insert( (*it) + 1 );
				}
				setOrigLeaves = setLabelsNew;
			}

			cout << "The original subtrees in the MAF = ";
			DumpIntSet( setOrigLeaves );
		}

#if 0
vector< set<int> > ssLeavesByCuts;
tree1.GetLeafSetsForCuts( cutEdges, ssLeavesByCuts );
vector<int> listParentsTree1;
for( int ii=0; ii<(int)ssLeavesByCuts.size(); ++ii )
{
int npp = tree1.GetMRCAForNodes( ssLeavesByCuts[ii] );
cout << "Parent = " << npp <<  " for leave sets ";
DumpIntSet( ssLeavesByCuts[ii] );
listParentsTree1.push_back(npp);
}
for( int ii=0; ii<(int)listParentsTree1.size(); ++ii )
{
for(int jj=ii+1; jj<(int)listParentsTree1.size(); ++jj)
{
if( tree1.IsNodeUnder(listParentsTree1[ii], listParentsTree1[jj]  ) == true)
{
cout << "Cluster " << jj << " is ancestral to cluster " << ii << endl ;
}
else if( tree1.IsNodeUnder(listParentsTree1[jj], listParentsTree1[ii]  ) == true)
{
cout << "Cluster " << ii << " is ancestral to cluster " << jj << endl ;
}

}
}
vector<int> listParentsTree2;
for( int ii=0; ii<(int)ssLeavesByCuts.size(); ++ii )
{
int npp = tree2.GetMRCAForNodes( ssLeavesByCuts[ii] );
cout << "Parent = " << npp <<  " for leave sets ";
DumpIntSet( ssLeavesByCuts[ii] );
listParentsTree2.push_back(npp);
}
for( int ii=0; ii<(int)listParentsTree2.size(); ++ii )
{
for(int jj=ii+1; jj<(int)listParentsTree2.size(); ++jj)
{
if( tree2.IsNodeUnder(listParentsTree2[ii], listParentsTree2[jj]  ) == true)
{
cout << "Cluster " << jj << " is ancestral to cluster " << ii << endl ;
}
else if( tree2.IsNodeUnder(listParentsTree2[jj], listParentsTree2[ii]  ) == true)
{
cout << "Cluster " << ii << " is ancestral to cluster " << jj << endl ;
}

}
}
#endif
        // how long does it take?
        cout << "Elapsed time = " << GetElapseTime( tstart1 ) << " seconds." << endl;

#if 0
        // acyclic rSPR
        tstart1 = GetCurrentTimeTick();
        int distarSPR = solver.ComputeAcyclicrSPR();
        cout << "The acyclic rSPR distance between two trees = " << distarSPR << endl;
        solver.GetCutEdges(cutEdges);
        cout << "The edges cut in MAF = ";
        DumpIntVec( cutEdges );
        // how long does it take?
        cout << "Elapsed time = " << GetElapseTime( tstart1 ) << " seconds." << endl;

        long tstart2 = GetCurrentTimeTick();

        int distSPRHeuris = solver.ComputeHeuristic();
        cout << "The rSPR (heuristic) distance between two trees = " << distSPRHeuris << endl;


        // how long does it take?
        cout << "Elapsed time = " << GetElapseTime( tstart2 ) << " seconds." << endl;
#endif
        return 0;

    }
    
    if( fMatrixFile == true)
    {
        // here is the input of matrix
        BinaryMatrix matInput;
	    ifstream inFile( fileName );
	    if(!inFile)
	    {
		    cout << "Can not open "<< fileName  <<endl;
		    exit(1);
	    }

        matInput.ReadFromFile (inFile );
        inFile.close();

        // preprocess the matrix
        matInput.TrimNonInformativeSites();
        matInput.TrimNgbrDupCompSites();
        matInput.TrimFullyCompatibleSites();
        matInput.TrimDupRows();
        cout << "After preprocessing, matirx = ";
        matInput.Dump();

        // now find the perfect phylogeny
        BuildMaxPhylogeny(matInput);

        return 0;
    }


    {
        YW_ASSERT_INFO(numRandLeaves >0 && numRandTests > 0, "settings wrong");

        // now use ILP to directly solve it
        // timestamp it
        long tstart1 = GetCurrentTimeTick();
        TestUniformTrees( numRandLeaves, numRandTests );

        // how long does it take?
        cout << "Elapsed time = " << GetElapseTime( tstart1 ) << " seconds." << endl;

    }

    return 0;

}

