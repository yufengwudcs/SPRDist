#ifndef GLPK_WRAPER_H
#define GLPK_WRAPER_H

#ifdef LPSOLVER_GLPK


#include "glpk.h"

// this file is a wraper for GLPK solver

extern "C" LPX* my_lpx_create_prob(void);
extern "C" void my_lpx_set_prob_name(LPX *, char *);
extern "C" void my_lpx_set_class(LPX *, int);
extern "C" void my_lpx_delete_prob(LPX *);
extern "C" void my_lpx_add_rows( LPX *, int  );
extern "C" void my_lpx_add_cols( LPX *, int );

extern "C" void	my_lpx_set_col_name(LPX *, int, char *);
extern "C" void	my_lpx_set_col_bnds(LPX *, int, int, double, double);
extern "C" void	my_lpx_set_col_kind(LPX *, int, int);
extern "C" void	my_lpx_set_col_coef(LPX *, int, double );
extern "C" void	my_lpx_set_row_name(LPX *, int, char *);
extern "C" void	my_lpx_set_row_bnds(LPX *, int, int, double, double);
//extern "C" void	my_lpx_set_row_coef(LPX *, int, double );
extern "C" void	my_lpx_load_mat3(LPX *, int, int [], int [], double []);
extern "C" void	my_lpx_set_obj_dir(LPX *, int);

#if 0
extern "C" void my_lpx_get_col_info(LPX *, int, int *tagx,  double *vx, double *dx);
#endif

extern "C" int my_lpx_integer(LPX *);
extern "C" void my_lpx_write_lpt(LPX *lp, char *fname);
extern "C" int my_lpx_get_num_int(LPX *lp);
extern "C" int my_lpx_simplex(LPX *lp);
extern "C" double my_lpx_get_mip_col(LPX *lp, int c);
extern "C" void my_lib_set_print_hook(void *info, int (*hook)(void *info, char *msg));
extern "C" double my_lpx_get_mip_obj(LPX *lp);

#endif

#endif	// GLPK_WRAPER_H

