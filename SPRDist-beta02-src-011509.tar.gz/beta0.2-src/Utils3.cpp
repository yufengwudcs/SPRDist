
#include "Utils3.h"
#include "ctime"
#include "cstdlib"
#include "cstdio"


/////////////////////////////////////////////////////////////////////////////////////////
// HashTable functions
/////////////////////////////////////////////////////////////////////////////////////////

YWHashItem :: ~YWHashItem()
{
}


YWHashTable :: YWHashTable( int nB ) : numBuckets( nB)
{
}

YWHashTable :: ~YWHashTable()
{
    // NOTE: has to free memory here
    for( unsigned int i=0; i<hashTable.size(); ++i)
    {
        delete hashTable[i];
    }
    hashTable.clear();
}


void YWHashTable :: AddItem( YWHashItem *pItem )
{
    hashTable.push_back( pItem );
}

YWHashItem* YWHashTable :: GetIdenticalItem( YWHashItem *pItem )
{
cout << "GetIdenticalItem: key = " << pItem->Key() << endl;
    for( unsigned int i=0; i<hashTable.size(); ++i)
    {
//cout << "We are here.\n";
        YW_ASSERT_INFO( hashTable[i] != NULL, "Can not be nothing here." );
        if( *hashTable[i]  == *pItem )
        {
cout << "find it here.\n";
            return hashTable[i];
        }
    }
cout << "did not find.\n";
    return NULL;
}

YWHashItem *  YWHashTable :: GetFirstItem()
{
cout << "GetFirstItem: size = " << hashTable.size() << endl;
    if( hashTable.size() == 0 )
    {
        return NULL;
    }
    this->curPos = 0;
    return hashTable[0];
}

YWHashItem * YWHashTable :: GetNextItem()
{
cout << "GetNextItem: size = " << hashTable.size() ;
cout << ", curPos = " << curPos << endl;
    if( this->curPos + 1>= (int)hashTable.size() )
    {
cout << "No more item.\n";
        return NULL;
    }
    this->curPos ++;
    YWHashItem *pItem = hashTable[ this->curPos ];
    YW_ASSERT_INFO( pItem != NULL, "Can not be nothing." );
cout << "GetNextItem.key() = " << pItem->Key() << endl;
    return pItem;
}

int YWHashTable :: GetTotalItemNum() const
{
    return hashTable.size();
}

void YWHashTable :: Dump() const
{
    for( unsigned int i=0; i<hashTable.size(); ++i)
    {
//cout << "We are here.\n";
        cout << "Key for item " << i << " = " << hashTable[i]->Key() << endl;
    }
}


// 
bool SequenceCmp :: operator() ( const SEQUENCE &seq1, const SEQUENCE &seq2 ) const
{
    if( seq1.size() != seq2.size() )
    {
        DumpSequence( seq1);
        DumpSequence( seq2);
    }

    YW_ASSERT_INFO( seq1.size() == seq2.size(), "Can not compare two things with different length" );

    for( int i=0; i<(int)seq1.size(); ++i )
    {
        if( seq1[i] < seq2[i] )
        {
            return true;
        }
        else if( seq1[i] > seq2[i] )
        {
            return false;
        }
    }

    // if all are equal
    return false;
}

/////////////////////////////////////////////////////////////////////////////////////////
// substring functions
/////////////////////////////////////////////////////////////////////////////////////////
bool IsIntervalContained( const INTERVAL &iv1, const INTERVAL &iv2)
{
    if( (iv1.first  >= iv2.first && iv1.second <= iv2.second) 
        ||  (iv2.first  >= iv1.first && iv2.second <= iv1.second)     )
    {
        return true;
    }
    return false;
}
int GetIntervalLen( const INTERVAL &iv)
{
    return iv.second - iv.first + 1;
}

int GetRandItemInSet( const set<int> &items )
{
    vector<int> itemsVec;
    PopulateVecBySet( itemsVec, items );
    return GetRandItemInVec(itemsVec);
}

int GetRandItemInVec( const vector<int> &items )
{
    YW_ASSERT_INFO( items.size() >0, "You can not sample from an empty set" );

    double frac = GetRandFraction();
    return items[ (int)(items.size() * frac) ];
}

void GetRandVector( vector<int> &rndVec, int start, int end )
{
    set<int> itemsNotUsed;
    PopulateSetWithInterval( itemsNotUsed, start, end);
    while( itemsNotUsed.size() > 0 )
    {
        int itemRnd = GetRandItemInSet( itemsNotUsed );
        rndVec.push_back( itemRnd );
        itemsNotUsed.erase( itemRnd );
    }
}


int GetWeightedRandItemInVec( const vector<int> &items, const vector<double> &itemWeights )
{
//cout << "items = ";
//DumpIntVec( items );

    YW_ASSERT_INFO( items.size() == itemWeights.size(), "Size mismatch" );
    double accum = 0.0;
    for( unsigned int i=0; i<itemWeights.size(); ++i )
    {
//cout << "one weight = " << itemWeights[i] << endl;
        accum += itemWeights[i];
    }
    YW_ASSERT_INFO( accum > 0.0000001, "2.Can not be too small" );
    double frac = GetRandFraction();
    double curFract = 0.0;
    for( unsigned int i=0; i<itemWeights.size(); ++i )
    {
        curFract += itemWeights[i]/accum;
        if( curFract >= frac )
        {
            return items[i];
        }
    }
    return -1;      // should nothappen


}

// This functionreturn a weighted uniformly item index from the list
int GetWeightedRandItemIndex( const vector<double> &itemWeights )
{
    double accum = 0.0;
    for( unsigned int i=0; i<itemWeights.size(); ++i )
    {
//cout << "one weight = " << itemWeights[i] << endl;
        accum += itemWeights[i];
    }
    YW_ASSERT_INFO( accum > 0.0000001, "3. Can not be too small" );
    double frac = GetRandFraction();
    double curFract = 0.0;
    for( unsigned int i=0; i<itemWeights.size(); ++i )
    {
        curFract += itemWeights[i]/accum;
        if( curFract >= frac )
        {
            return i;
        }
    }
    // Can not come here
    YW_ASSERT_INFO(false, "Something wrong here");
    return -1;      // should nothappen

}

void GetOrigSubset( const vector<int> &origVec, const set<int> &subsetInd, set<int> &subsetOrig )
{
    subsetOrig.clear();
    for( set<int> :: iterator it = subsetInd.begin(); it != subsetInd.end(); ++it )
    {
        YW_ASSERT_INFO( *it < (int)origVec.size(), "Size exceeds" );
        subsetOrig.insert( origVec[*it] );
    }
}

void MutateSequenceAtSites( SEQUENCE & mutSeq, vector<int> & mutSites )
{
    for( unsigned int p=0; p<mutSites.size(); ++p )
    {
        MutateSeqAtSite( mutSeq, mutSites[p]  );
    }
}

void DumpDoubleVec(const vector<double> &vecDoubles)
{
    cout << "Double vector contains: ";
    for( unsigned int i=0; i<vecDoubles.size(); ++i)
    {
        cout << vecDoubles[i] << ", ";
    }
    cout << endl;
}
void DumpDoubleVec(const vector<long double> &vecDoubles)
{
    cout << "Double vector contains: ";
    for( unsigned int i=0; i<vecDoubles.size(); ++i)
    {
        cout << vecDoubles[i] << ", ";
    }
    cout << endl;
}
void DumpBoolVec( const vector<bool> &vecBools)
{
    cout << "Bool vector contains: ";
    for( unsigned int i=0; i<vecBools.size(); ++i)
    {
        if( vecBools[i] == true )
        {
            cout << "1,";
        }
        else
        {
            cout << "0, ";
        }
    }
    cout << endl;
}

int GetLargestIndiceInDoubleVec(const vector<double> &vecDoubles)
{
    double maxv = 0.0;
    int res = 0;
    for( unsigned int i=0; i<vecDoubles.size(); ++i)
    {
        if( vecDoubles[i]  > maxv )
        {
            maxv = vecDoubles[i];
            res = i;
        }
    }
    return res;
}

int GetLargestIndiceInDoubleVec(const vector<long double> &vecDoubles)
{
    long double maxv = 0.0;
    int res = 0;
    for( unsigned int i=0; i<vecDoubles.size(); ++i)
    {
        if( vecDoubles[i]  > maxv )
        {
            maxv = vecDoubles[i];
            res = i;
        }
    }
    return res;
}

double FindMedian( const vector<double> &vecVals )
{
    // for now, if there is nothing in the list, return 0.0
    if( vecVals.size() == 0 )
    {
        return 0.0;
    }


    YW_ASSERT_INFO( vecVals.size() > 0, "FindMedian: Can not be empty" );

    // Find median value for the vector
    // first sort the list of course
    vector<double> listToTry = vecVals;
    SortDoubleVec( listToTry );
    // now find the median one
    //int totSize = (int)listToTry.size();
    int pos = (int)( ((int)listToTry.size()-1)/2);
    return listToTry[pos];
}

long double FindMedian( const vector<long double> &vecVals )
{
    YW_ASSERT_INFO( vecVals.size() > 0, "FindMedian: Can not be empty" );

    // Find median value for the vector
    // first sort the list of course
    vector<long double> listToTry = vecVals;
    SortDoubleVec( listToTry );
    // now find the median one
    //int totSize = (int)listToTry.size();
    int pos = (int)( ((int)listToTry.size()-1)/2);
    return listToTry[pos];
}

double FindMaxDouble( const vector<double> &vecVals )
{
    // fnd max value of the solution here, assuming all values are non-negative
    vector<double> listToTry = vecVals;
    SortDoubleVec( listToTry );
//cout << "vecVals = ";
//DumpDoubleVec( vecVals );
    
    double res = listToTry[ listToTry.size()-1 ];
//cout << "res = " << res << endl;
    return res;
}

double FindMaxDouble( const vector<long double> &vecVals )
{
    // fnd max value of the solution here, assuming all values are non-negative
    vector<long double> listToTry = vecVals;
    SortDoubleVec( listToTry );
//cout << "vecVals = ";
//DumpDoubleVec( vecVals );
    
    double res = listToTry[ listToTry.size()-1 ];
//cout << "res = " << res << endl;
    return res;
}


static int QSortCompareDouble( const void *arg1, const void *arg2 )
{
   /* Compare all of both strings: */
    // assume sorting in accending order
    double n1 = *((double *) arg1);
    double n2 = *((double *) arg2);
//cout <<"arg1 = " << n1 << ", arg2 = " << n2 << endl;
    if( n1 > n2)
    {
        return 1;
    }
    else if( n1 < n2)
    {
        return -1;
    }
    else 
    {
        return 0;
    }
}


void SortDoubleVec( vector<double> &vecVals, int start, int end )
{
//#if 0
    if( vecVals.size() <= 1)
    {
        // do nothing
        return;
    }
//cout << "Before sort, double vec = ";
//DumpDoubleVec( vecVals );
	if (end < 0 )
	{
		end = vecVals.size() - 1;
	}
    int sortLen = end - start +1;
    double *array = new double[sortLen];
    for(int i=start; i<= end; ++i)
    {
        array[i-start] = vecVals[i];
    }
    qsort( (void *)array, sortLen, sizeof( double ), QSortCompareDouble );
    // Now write back
    for(int i=start; i<=end; ++i)
    {
        vecVals[i] = array[i-start];
    }

    delete [] array;
//#endif
//cout << "After sort, double vec = ";
//DumpDoubleVec( vecVals );
}


static int QSortCompareLongDouble( const void *arg1, const void *arg2 )
{
   /* Compare all of both strings: */
    // assume sorting in accending order
    long double n1 = *((long double *) arg1);
    long double n2 = *((long double *) arg2);
//cout <<"arg1 = " << n1 << ", arg2 = " << n2 << endl;
    if( n1 > n2)
    {
        return 1;
    }
    else if( n1 < n2)
    {
        return -1;
    }
    else 
    {
        return 0;
    }
}


void SortDoubleVec( vector<long double> &vecVals, int start, int end )
{
//#if 0
    if( vecVals.size() <= 1)
    {
        // do nothing
        return;
    }
//cout << "Before sort, double vec = ";
//DumpDoubleVec( vecVals );
	if (end < 0 )
	{
		end = vecVals.size() - 1;
	}
    int sortLen = end - start +1;
    long double *array = new long double[sortLen];
    for(int i=start; i<= end; ++i)
    {
        array[i-start] = vecVals[i];
    }
    qsort( (void *)array, sortLen, sizeof( long double ), QSortCompareLongDouble );
    // Now write back
    for(int i=start; i<=end; ++i)
    {
        vecVals[i] = array[i-start];
    }

    delete [] array;
//#endif
//cout << "After sort, double vec = ";
//DumpDoubleVec( vecVals );
}

void FindUniformColumns( const vector<SEQUENCE> &listSeqs, set<int> &uniSites)
{
    uniSites.clear();
    if( listSeqs.size() == 0 )
    {
        return;
    }
    int numSites = (int) listSeqs[0].size();
    for( int i=0; i<numSites; ++i )
    {
        bool f0=false, f1=false;
        for( int r = 0; r<(int)listSeqs.size(); ++r )
        {
            if( listSeqs[r][i] == 0 )
            {
                f0 = true;
            }
            else if(listSeqs[r][i] == 1)
            {
                f1 = true;
            }
            if( f0 == true && f1 == true )
            {
                // not uniform, 
                break;
            }
        }
        if( f0 == false || f1 == false )
        {
            // yes, this site is uniform
            uniSites.insert( i );
        }
    }
}

void BreakSeqAtBkpt( const SEQUENCE &seq, int bkpt, SEQUENCE &seqLeft, SEQUENCE &seqRight  )
{
    seqLeft.clear();
    seqRight.clear();
    for( int i=0; i<(int)seq.size(); ++i )
    {
        if( i <= bkpt )
        {
            // then the right seq get MV
            seqLeft.push_back( seq[i] );
            seqRight.push_back( MISSING_VALUE_BIT );
        }
        else
        {
            seqLeft.push_back( MISSING_VALUE_BIT );
            seqRight.push_back( seq[i] );
        }
    }
}

bool AreTwoSeqsBroken( const SEQUENCE &seqLeft, const SEQUENCE &seqRight )
{
    // test whether the two sequences are broken from a single sequence
    // to avoid duplicate events mainly
    bool foundBkpt = false;
    if( seqLeft.size() != seqRight.size() )
    {
        return false;
    }

    for( int i=0; i<(int)seqLeft.size(); ++i)
    {
        if(IsMissingValueBit( seqLeft[i] ) == false && IsMissingValueBit( seqRight[i] ) == false)
        {
            return false;   // no, not a broken seqs pair
        }

        if( IsMissingValueBit( seqRight[i] ) == false )
        {
            if( foundBkpt == false )
            {
                foundBkpt = true;
            }
        }
        if( foundBkpt == true && IsMissingValueBit( seqLeft[i] ) == false )
        {
            return false;
        }
    }
    return true;
}

///////////////////////////////////////////////////////////////////////////////////////////
int GetSubstringLeftPos( const INTERVAL_SUBSTRING &substr )
{
    return substr.first.first;
}
int GetSubstringRightPos( const INTERVAL_SUBSTRING &substr )
{
    return substr.first.second;
}
INTERVAL GetSubstringInterval( const INTERVAL_SUBSTRING &substr)
{
    return substr.first;
}
bool GetSubstringSegment(const INTERVAL_SUBSTRING &substr, const INTERVAL &ivToRead, SEQUENCE &segment)
{
    YW_ASSERT_INFO( IsIntervalContained(ivToRead, substr.first) == true, "Two intervals do not have contained" );

    // remember we have to offset a little
    int startPos = GetSubstringLeftPos( substr );
    GetSeqInterval(substr.second, segment, ivToRead.first-startPos, ivToRead.second-startPos);
    return true;
}

int GetSubstringValAt( const INTERVAL_SUBSTRING &substr, int pos )
{
    YW_ASSERT_INFO( pos >= GetSubstringLeftPos(substr) && pos <= GetSubstringRightPos(substr), "Range error." );

    int convPos = pos - GetSubstringLeftPos( substr );
    return substr.second[ convPos ];
}

bool IsSegmentContained( const INTERVAL_SUBSTRING &seqContained, const INTERVAL_SUBSTRING& seqContainer   )
{
    // First the range has to match
    if( GetSubstringLeftPos(seqContained)  < GetSubstringLeftPos(seqContainer)  || 
        GetSubstringRightPos(seqContained)  > GetSubstringRightPos(seqContainer)  )
    {
        return false;
    }
    // Then the corresponding position must match too
    for( int p = GetSubstringLeftPos(seqContained); p<= GetSubstringRightPos(seqContained); p++ )
    {
        if( GetSubstringValAt(seqContained, p)  !=  GetSubstringValAt( seqContainer, p) )
        {
            return false;
        }
    }
    return true;
}

bool AreSegmentsConsistent( const INTERVAL_SUBSTRING &seq1, const INTERVAL_SUBSTRING& seq2 )
{
    // If disjoint, yes, it is consistent
    INTERVAL ivInt;
    bool fInt = GetIntervalOverlap( GetSubstringInterval(seq1), GetSubstringInterval(seq2), ivInt);
    if( fInt == false  )
    {
        return true;
    }
//cout << "ivInt.first = " << ivInt.first << ", ivInt.second = " << ivInt.second << endl;
    // make sure the two things matches
    SEQUENCE seqp1;
    GetSubstringSegment( seq1, ivInt, seqp1);
//cout << "seqp1 = ";
//DumpSequence( seqp1 );
    SEQUENCE seqp2;
    GetSubstringSegment( seq2, ivInt, seqp2);
//cout << "seqp2 = ";
//DumpSequence( seqp2 );

    if( seqp1 == seqp2 )
    {
        return true;
    }
    else
    {
        return false;
    }

}

int GetSegmentsIntersection( const INTERVAL_SUBSTRING &seq1, const INTERVAL_SUBSTRING& seq2, INTERVAL &iv )
{
    // we simply get how larget the intersection from the interval ONLY

    bool fInt = GetIntervalOverlap( GetSubstringInterval(seq1), GetSubstringInterval(seq2), iv);
    if( fInt == false  )
    {
        return 0;
    }
    return iv.second - iv.first+1;
}

bool AreSegmentsNextto( const INTERVAL_SUBSTRING &seq1, const INTERVAL_SUBSTRING& seq2 )
{
//cout << "seq1.left = " <<  GetSubstringLeftPos(seq1) << ", right = " <<  GetSubstringRightPos(seq1) << endl;
//cout << "seq2.left = " <<  GetSubstringLeftPos(seq2) << ", right = " <<  GetSubstringRightPos(seq2) << endl;
    // Two segments are next to each other if the can form a single bigger ungapped piece
    if( GetSubstringLeftPos(seq1) == GetSubstringRightPos(seq2) + 1
        || GetSubstringLeftPos(seq2) == GetSubstringRightPos(seq1) + 1  )
    {
//cout << "Yes, neighbours.\n";
        return true;
    }
    else
    {
//cout << "No, not neighbours.\n";
        return false;
    }
}

void DumpSubstring( const INTERVAL_SUBSTRING &substr )
{
    cout << "[" << GetSubstringLeftPos(substr) << ",";
    cout << GetSubstringRightPos(substr) << "], ";
    DumpSequence( substr.second );
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
// More useful functions

// This is a very useful function, so expose it
int FindMatchedSeqForFounders( const vector<SEQUENCE> &founder, const SEQUENCE &seq,
                                  set<int> &endRows, bool fPrefix)
{
    // Return the number of crossovers
    // This function computes the minimum recombination weight for the given hapRow
    // when restricted to interval [left, right] in mat
    int res = 0;

    set<int> lastTrackRows;  // set of rows that matching the hapRow

    // Ohterwise, we can start from all possible rows
    for( unsigned int i=0; i<founder.size(); ++i )
    {
        lastTrackRows.insert( i );
    }

    int curpos  = 0; 
    int end = seq.size();
    if( fPrefix == false )
    {
        curpos = seq.size()-1;
        end = -1;
    }


    while( curpos != end )
    {
        // Each time, we intersect the set with the sets matching the current bit
        set<int> trackRows;
        for(unsigned int i=0; i<founder.size(); ++i)
        {
            if( IsTwoStatesCompatible( founder[i][curpos] , seq[curpos]) == true )
            {
                // Yes, this row matches
                trackRows.insert( i );
            }
        }

        // Now we test if there is intersection, if non-empty, we contiinue
        set<int> sint;
        JoinSets(trackRows, lastTrackRows, sint);
        if(sint.size() == 0)
        {
            break;
        }
        else
        {
            // In this case, we still continue
            lastTrackRows = sint;
        }

        if( fPrefix == true)
        {
            curpos++;
        }
        else
        {
            curpos--;
        }
    }

    endRows = lastTrackRows;

    // what is the length of the prefix/suffix
    if( fPrefix )
    {
        res = curpos;
    }
    else
    {
        res = seq.size() - 1 - curpos;
    }

    return res;
}

int FindNoninformativeRow( const vector<SEQUENCE> &listSeqs, int col)
{
	int numZeros = 0, numOnes = 0, numMissing = 0;
	// now we compare these two cols: c1, c2
	// if they match, we put c2 into set
    int res0 = -1, res1 = -1;
	for(unsigned int r = 0; r< listSeqs.size(); ++r)
	{	
		if(listSeqs[r][col] == 0)
		{
			numZeros ++;
            res0 = r;
		}
		else if(listSeqs[r][col] == 1)
		{
			numOnes ++;
            res1 = r;
		}
        else if(  IsMissingValueBit( listSeqs[r][col] ) == true  )
        {
            numMissing++;
        }
        if(  numZeros > 1 && numOnes > 1 )
        {
            return -1;  // no such row
        }
	}

	// Check to see if this is non-informative
	if( numZeros ==1  && numOnes >= 1  )
	{
		// we find a duplicate
//			cout << "Site  " << c1+1 << "is  non-informative" << endl;
        return res0;
	}	
    else if( numOnes == 1  && numZeros >= 1)
    {
        return res1;
    }
    else
    {
        return -1;
    }
}


