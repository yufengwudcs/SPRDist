#include "Network.h"
#include "UnWeightedGraph.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
const int MIN_IV_LENGTH_PF_TEST = 8;    // prefer each tree has at least this many splits


// test whether MAF is good: first a valid MAF, and then is acyclic
bool IsMAFGood( const MarginalTree &tree1, const vector<int> &cutEdges, const MarginalTree &tree2  )
{

    // first make sure the cut create a valid MAF

    vector< set<int> > ssLeavesByCuts;
    tree1.GetLeafSetsForCuts( cutEdges, ssLeavesByCuts );

    // 
    vector<vector<bool> > ancestralRelations( ssLeavesByCuts.size()  );
    for( int i=0; i<(int) ssLeavesByCuts.size(); ++i )
    {
        for(int j=0; j<(int)ssLeavesByCuts.size(); ++j)
        {
            ancestralRelations[i].push_back( false );;
        }
    }



    vector<int> listParentsTree1;
    for( int ii=0; ii<(int)ssLeavesByCuts.size(); ++ii )
    {
        int npp = tree1.GetMRCAForNodes( ssLeavesByCuts[ii] );
//        cout << "Parent = " << npp <<  " for leave sets ";
//        DumpIntSet( ssLeavesByCuts[ii] );
        listParentsTree1.push_back(npp);
    }
    for( int ii=0; ii<(int)listParentsTree1.size(); ++ii )
    {
        for(int jj=ii+1; jj<(int)listParentsTree1.size(); ++jj)
        {
            if( tree1.IsNodeUnder(listParentsTree1[ii], listParentsTree1[jj]  ) == true)
            {
                ancestralRelations[jj][ii] = true;
//cout << "Cluster " << jj << " is ancestral to cluster " << ii << endl ;
            }
            else if( tree1.IsNodeUnder(listParentsTree1[jj], listParentsTree1[ii]  ) == true)
            {
                ancestralRelations[ii][jj] = true;
//cout << "Cluster " << ii << " is ancestral to cluster " << jj << endl ;
            }

        }
    }

    vector<int> listParentsTree2;
    for( int ii=0; ii<(int)ssLeavesByCuts.size(); ++ii )
    {
        int npp = tree2.GetMRCAForNodes( ssLeavesByCuts[ii] );
//        cout << "Parent = " << npp <<  " for leave sets ";
//        DumpIntSet( ssLeavesByCuts[ii] );
        listParentsTree2.push_back(npp);

        // for debugging
        set<int> leavesUnder;
        tree2.GetLeavesUnder( npp, leavesUnder );
    }
    for( int ii=0; ii<(int)listParentsTree2.size(); ++ii )
    {
        for(int jj=ii+1; jj<(int)listParentsTree2.size(); ++jj)
        {
            if( tree2.IsNodeUnder(listParentsTree2[ii], listParentsTree2[jj]  ) == true)
            {
                ancestralRelations[jj][ii] = true;
//cout << "Cluster " << jj << " is ancestral to cluster " << ii << endl ;
            }
            else if( tree2.IsNodeUnder(listParentsTree2[jj], listParentsTree2[ii]  ) == true)
            {
                ancestralRelations[ii][jj] = true;
//cout << "Cluster " << ii << " is ancestral to cluster " << jj << endl ;
            }

        }
    }

    // now we create a graph with a node corresponding to a partition
    // and test for acyclic 
    DirectedGraph graphPartition;
    vector<int> nodesId;
    for( int i=0; i<(int)ssLeavesByCuts.size(); ++i  )
    {
        // is this cut good?
        nodesId.push_back( graphPartition.AddVertex(0) );
    }
    // now create edges
    for( int i=0; i<(int) ssLeavesByCuts.size(); ++i )
    {
        for(int j=0; j<(int)ssLeavesByCuts.size(); ++j)
        {
            if( ancestralRelations[i][j] == true )
            {
                // add an edge
                graphPartition.AddEdge( nodesId[i], nodesId[j], 0);

            }
        }
    }
graphPartition.OutputGML("graphPartition.gml");
    return graphPartition.IsAcyclic();
}


// search for both directions new splits we can add to
static void AugmentPfTree( const BinaryMatrix &matInput, int coreLeft, int coreRight, PhylogenyTree &phTree,
                          vector<int> &listSitesNew)
{
cout << "coreLeft = " << coreLeft << ", coreRight = " << coreRight << endl;

    listSitesNew.clear();

    int totSitesNum = coreRight - coreLeft + 1;
    BinaryMatrix submat;
    matInput.SubMatrix(0, matInput.GetRowNum()-1, coreLeft, coreRight, submat );

    // if this segment is large enough, no need to search more
    if( totSitesNum >= MIN_IV_LENGTH_PF_TEST )
    {
        vector<int> rootSeq;
        for(int ii = 0; ii < totSitesNum; ++ii )
        {
            rootSeq.push_back( 0 );
        }
        phTree.SetRoot( rootSeq );
        bool ftree = phTree.ConsOnBinMatrix( submat );
        YW_ASSERT_INFO( ftree == true, "fail to build the tree" );

        return;
    }

    // now try to search for both directions what kind of new splits we can add into submat
    int curdist = 1;
    bool fMoveLeft = true;
    bool fNoMoreLeft = false, fNoMoreRight = false;
    while( totSitesNum < MIN_IV_LENGTH_PF_TEST && (fNoMoreLeft == false || fNoMoreRight == false)  )
    {
cout << "curdist = " << curdist << ", fMoveLeft = " << fMoveLeft << ", fNoMoreLeft = " << fNoMoreLeft << 
", fNoMoreRight = " << fNoMoreRight << endl;
        // 
        int siteNew = -1;
        if( fMoveLeft == true)
        {
            siteNew = coreLeft - curdist;
            if( siteNew < 0 )
            {
                // no more left
                fNoMoreLeft = true;
            }

            // switch if still possible
            if( fNoMoreRight == false )
            {
                fMoveLeft = false;
            }       

            // should move dist if we can no longer move right
            if( fNoMoreRight == true)
            {
                curdist ++;
            }
        }
        else
        {
            siteNew = coreLeft + curdist;
            if( siteNew >= matInput.GetColNum() )
            {
                // no more left
                fNoMoreRight = true;
                siteNew = -1;
            }

            // switch if still possible
            if( fNoMoreLeft == false )
            {
                fMoveLeft = true;
            }       

            // one more level
            curdist ++;
        }


        if( siteNew < 0 )
        {
            continue;
        }

        // now add this one more site
        BinaryMatrix singleSiteMat;
        matInput.SubMatrix(0, matInput.GetRowNum()-1, siteNew, siteNew, singleSiteMat );

        // append it
        submat.AppendMatrixByCol(singleSiteMat);

        // if it is not perfect phylogeny, drop it
        if( submat.IsPerfectPhylogeny() == false  )
        {
            // remove this site
            set<int> colSingle;
            colSingle.insert( submat.GetColNum()-1 );
            submat.RemoveColumns(colSingle);
        }
        else
        {
            // keep it
            totSitesNum ++;
            listSitesNew.push_back( siteNew );
        }

    }

    // finally build the tree
    vector<int> rootSeq;
    for(int ii = 0; ii < totSitesNum; ++ii )
    {
        rootSeq.push_back( 0 );
    }
cout << "Augmented matrix = ";
submat.Dump();
    phTree.SetRoot( rootSeq );
    bool ftree = phTree.ConsOnBinMatrix( submat );
    YW_ASSERT_INFO( ftree == true, "fail to build the tree" );
}


void BuildMaxPhylogeny( const BinaryMatrix &matInput )
{
    // start from left end and scan to the right, to build phylogeny
    int lend, rend = 0;
    BinaryMatrix matPrev;
    int treeNum = 0;
    int lastIntPf = -1;
    for( lend = 0; lend < matInput.GetColNum(); ++lend )
    {
        // is (lend, rend) has perfect phylogeny?
        while( rend < matInput.GetColNum() )
        {
            BinaryMatrix submat;
            matInput.SubMatrix(0, matInput.GetRowNum()-1, lend, rend, submat );
            bool fPf = submat.IsPerfectPhylogeny();
             
            if( fPf == false || (fPf == true && rend == matInput.GetColNum()-1  )  )
            {
                // we take the previous submat
                PhylogenyTree treeFound;

                // set root ot all 0
                vector<int> rootSeq;
                int seqLen = matPrev.GetColNum();
                int curPfRight = rend-1;
                if( fPf == true )
                {
                    seqLen = rend - lend +1;
                    curPfRight = rend;
                }
                // quit if this is already outputed
                if( curPfRight == lastIntPf )
                {
                    break;
                }
                lastIntPf = curPfRight;

                // now find the tree
                vector<int> listNodesNew;
                AugmentPfTree( matInput, lend, curPfRight, treeFound, listNodesNew);
cout << "Working on interval: left = " << lend << ", right = " << curPfRight << endl;
cout << "This tree contains new nodes: ";
DumpIntVec( listNodesNew );

#if 0
                for(int ii = 0; ii < seqLen; ++ii )
                {
                    rootSeq.push_back( 0 );
                }
                treeFound.SetRoot( rootSeq );

                bool ftree;
                if( fPf == false )
                {
                    ftree = treeFound.ConsOnBinMatrix( matPrev );
cout << "Found a perfect phylogeny between " << lend << ", and " << rend -1 << endl;
                }
                else
                {
cout << "Found a perfect phylogeny between " << lend << ", and " << rend << endl;
                    ftree = treeFound.ConsOnBinMatrix( submat );
                    rend ++;
                }
                YW_ASSERT_INFO( ftree == true, "Must true" );
#endif

                // output the file
                treeNum++;
                char buf[100];
                sprintf(buf, "TreePf%d.gml", treeNum);
                treeFound.OutputGML(buf);
                break;
            }

            if( fPf == true)
            {
                // move on
                rend ++;
                matPrev = submat;
            }
        }
    }

}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////




