#ifndef NETWORK_H
#define NETWORK_H

#include <map>
#include "Utils.h"
#include "Utils2.h"
#include "MarginalTree.h"
#include "ILPSolver.h"
#include "BinaryMatrix.h"
#include "PhylogenyTree.h"

using namespace std;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// test whether MAF is good: first a valid MAF, and then is acyclic
bool IsMAFGood( const MarginalTree &tree1, const vector<int> &edgesCut, const MarginalTree &tree2  );
void BuildMaxPhylogeny( const BinaryMatrix &matInput );


////////////////////////////////////////////////////////////////////////////////////////////////////////////////



#endif  // NETWORK_H

