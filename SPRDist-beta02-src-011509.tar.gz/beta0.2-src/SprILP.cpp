#include "SprILP.h"
#include "ILPSolver.h"
#include <queue>
#include "UnWeightedGraph.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
extern int minCutLB;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////

static int CalcTreeNewOffsetAfterDel( int offOld, int  leafNew )
{
    if( offOld < 0  )
    {
        return offOld;
    }

    if( offOld < leafNew )
    {
        return offOld -1;
    }
    else
    {
        return offOld -2;
    }
}

static void MergeTwoLeavesOfTree( MarginalTree &tree1, int lf1, int lf2 )
{
    // 
    MarginalTree treeRes;
    treeRes.numLeaves = tree1.numLeaves;

    int leafNew = tree1.GetParent( lf1 );
    YW_ASSERT_INFO( leafNew == tree1.GetParent(lf2), "Can not merge such pair" );

    // first fill in leaves
    for( int i=0; i<tree1.GetNumLeaves(); ++i )
    {
        if( i != lf1 && i != lf2 )
        {
            treeRes.listNodeLabels.push_back( tree1.listNodeLabels[i] );

            int oldPar = tree1.GetParent(i);
            YW_ASSERT_INFO( oldPar != leafNew, "Merge error" );
            int parNew;
            if( oldPar < leafNew )
            {
                // just minus 1
                parNew = oldPar - 1;
            }
            else
            {
                // otherwise, we lost two
                parNew = oldPar - 2;
            }
            treeRes.listParentNodePos.push_back(parNew);
        }
    }
    // now add the single new leaf
    treeRes.listNodeLabels.push_back( tree1.listNodeLabels[ leafNew ] );
    treeRes.listParentNodePos.push_back(  tree1.GetParent(leafNew) - 2  );

    // now fill in the rest
    for( int i=tree1.GetNumLeaves(); i < tree1.GetTotNodesNum(); ++i )
    {
        // is this node good?
        if( i != leafNew )
        {
            treeRes.listNodeLabels.push_back( tree1.listNodeLabels[ i ] );
            treeRes.listParentNodePos.push_back(  CalcTreeNewOffsetAfterDel(tree1.GetParent( i ) , leafNew )  );

        }
    }


    // finally update the number of leaves
    tree1 = treeRes;
    tree1.numLeaves --;
}

typedef struct
{
    int lv1;
    int lv2;
    int lv3;
    int lv4;    // = -1 if this is a triple system
    int mrca1;
    int mrca2;
    set<int> edgesInPathes;
} COMBO_PATH_INFO;
int HeurisTreeCut(const MarginalTree &tree1, const MarginalTree &tree2)
{
tree1.OutputGML( "tree1.gml" );
tree2.OutputGML( "tree2.gml" );

    // test code to see how the bottom-up cut strategy works
    // find out the set of all triple-sets: 3 leaves, mrca, paths
    vector< COMBO_PATH_INFO > listTriplePathInfo;
    vector< COMBO_PATH_INFO > listTwinPathInfo;

    // now try all possible triples of leaves i,j,k
    for( int i= 0; i< tree1.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1.GetNumLeaves(); ++j)
        {
            for(int k=j+1; k< tree1.GetNumLeaves(); ++k)
            {
                // is these have different triples on T1 and T2?
                // we do this by getting MRCA for all pairs of MRCAs
                int mrcaij1 = tree1.GetMRCA( i, j );
                int mrcajk1 = tree1.GetMRCA( j, k );
                int mrcaik1 = tree1.GetMRCA( i, k );
                int mrcaij2 = tree2.GetMRCA( i, j );
                int mrcajk2 = tree2.GetMRCA( j, k );
                int mrcaik2 = tree2.GetMRCA( i, k );

                bool fIncTriple = false;

                // now just test exhustively
                if( mrcaij1 == mrcajk1 )
                {
                    if( mrcaij2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }
                else if( mrcaij1 == mrcaik1 )
                {
                    if( mrcaij2 != mrcaik2  )
                    {
                        fIncTriple = true;
                    }
                }
                else 
                {
                    if( mrcaik2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }

                if(fIncTriple == false)
                {
                    // we are only interested in incompatible triple
                    continue;
                }


//#if 0
                // we find the edges on the path
                set<int> triPathEdges;
                set<int> listEdgesij;
                tree1.GetPath( i,j, listEdgesij );
                triPathEdges = listEdgesij;
                set<int> listEdgesjk;
                tree1.GetPath( j,k, listEdgesjk );
                UnionSets( triPathEdges, listEdgesjk );
                set<int> listEdgesik;
                tree1.GetPath( i,k, listEdgesik );
                UnionSets( triPathEdges, listEdgesik );
                triPathEdges.insert( mrcaij1 );
                triPathEdges.insert( mrcajk1 );
                triPathEdges.insert( mrcaik1 );

                COMBO_PATH_INFO pinfo;
                pinfo.lv1 = i;
                pinfo.lv2 = j;
                pinfo.lv3 = k;
                pinfo.lv4 = -1;
                pinfo.mrca1 = mrcaij1;
                pinfo.mrca2 = mrcajk1;
                if( pinfo.mrca1 == pinfo.mrca2 )
                {
                    pinfo.mrca2 = mrcaik1;
                }
                OrderInt( pinfo.mrca1, pinfo.mrca2 );
                YW_ASSERT_INFO(triPathEdges.size() > 0, "Can not be empty");
                pinfo.edgesInPathes = triPathEdges;
                listTriplePathInfo.push_back( pinfo );
            }
        }
    }
//#endif


    // now we test for all pair of leaf pairs, to ensure there is no intersection in two trees
    // if the two pairs are left in one tree
    for( int i= 0; i< tree1.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1.GetNumLeaves(); ++j)
        {
            for(int p=i+1; p< tree1.GetNumLeaves(); ++p)
            {
                // make sure p <>i or j
                if(  p == j )
                {
                    continue;
                }
                for(int q = p+1; q < tree1.GetNumLeaves(); ++q)
                {
                    // make sure q is unique twoo
                    if(  q == j )
                    {
                        continue;
                    }

                    // now we only worry about two disjoint path (i,j) and (p,q)
                    if( tree1.AreTwoPathsDisjoint( i, j, p, q ) == false  )
                    {
                        continue;
                    }
                    // also ignore when tree2 has disjoint (i,j) and (p,q), since they auto satisfy the partition
                    if( tree2.AreTwoPathsDisjoint( i, j, p, q ) == true  )
                    {
                        continue;
                    }

                    // now for this, make sure Mi,j + Mp,q <= 1
//                    OutputMkij( outFile, 1, i, j );
//                    outFile << " + ";
//                    OutputMkij( outFile, 1, p, q );
//                    outFile << " <= 1\n";

                    // rertreive the path here
                    set<int> twinPathEdges;
                    set<int> listEdgesij;
                    tree1.GetPath( i,j, listEdgesij );
                    twinPathEdges = listEdgesij;
                    set<int> listEdgespq;
                    tree1.GetPath( p,q, listEdgespq );
                    UnionSets( twinPathEdges, listEdgespq );

                    // make sure the mrca is included
                    twinPathEdges.insert(tree1.GetMRCA( i, j ));
                    twinPathEdges.insert(tree1.GetMRCA( p, q ));

                    COMBO_PATH_INFO pinfo;
                    pinfo.lv1 = i;
                    pinfo.lv2 = j;
                    pinfo.lv3 = p;
                    pinfo.lv4 = q;
                    pinfo.mrca1 = tree1.GetMRCA( i, j );
                    pinfo.mrca2 = tree1.GetMRCA( p, q );
                    OrderInt( pinfo.mrca1, pinfo.mrca2 );
                    YW_ASSERT_INFO(twinPathEdges.size() > 0, "Can not be empty");
                    pinfo.edgesInPathes = twinPathEdges;
                    listTwinPathInfo.push_back( pinfo );


                }
            }
        }
    }
//cout << "Total number of triple constarints = " << listTriplePathInfo.size() << endl;
//cout << "Total number of twin path constarints = " << listTwinPathInfo.size() << endl;
    // now setup priority queue 
    typedef pair<int, pair<int, COMBO_PATH_INFO *>  > COMBO_PATH_ENTRY;
    priority_queue<COMBO_PATH_ENTRY> queueComboPath;
    set<int> edgesCut;
    for( int i=0; i<(int)listTriplePathInfo.size(); ++i  )
    {
        COMBO_PATH_ENTRY cpp;
        cpp.first =  -listTriplePathInfo[i].mrca2;
        cpp.second.first = -listTriplePathInfo[i].mrca1;
        cpp.second.second = &listTriplePathInfo[i] ;
        queueComboPath.push( cpp );
    }
    // now get the lowest combo path (wrt mrca2)
    while( queueComboPath.empty() == false )
    {
        COMBO_PATH_ENTRY cpp = queueComboPath.top();
        queueComboPath.pop();
//cout << "Processing i = " << cpp.second.second->lv1;
//cout << ", j = " << cpp.second.second->lv2;
//cout << ", k = " << cpp.second.second->lv3;
//cout << ", mrca2 = " << cpp.second.second->mrca2;
//cout << endl;
        // if this edge is already covered, skip
        set<int> joinEdges;
        JoinSets( cpp.second.second->edgesInPathes, edgesCut, joinEdges);
        if(  joinEdges.size() > 0 )
        {
//cout << "This combo path covered by cuts ";
//DumpIntSet(joinEdges);
            // not active, 
            continue;
        }
//cout << "Now cut " << cpp.second.second->mrca1 << endl;
cout << "Now cut " << cpp.second.second->mrca2 << endl;
        // add this cut. For simplicity, denote as the mrca, rather than real edges
//        edgesCut.insert( cpp.second.second->mrca1 );
        edgesCut.insert( cpp.second.second->mrca2 );
    }
    // now find out which twin paths remain un-cut
    vector<COMBO_PATH_INFO *> listTwinRemained;
    
    for( int i=0; i<(int)listTwinPathInfo.size(); ++i  )
    {
        set<int> joinEdges;
        JoinSets( listTwinPathInfo[i].edgesInPathes, edgesCut, joinEdges);
        if(  joinEdges.size() == 0 )
        {
#if  0
cout << "Checking twin paths still active: i = " << listTwinPathInfo[i].lv1;
cout << ", j = " << listTwinPathInfo[i].lv2;
cout << ", p = " << listTwinPathInfo[i].lv3;
cout << ", q = " << listTwinPathInfo[i].lv4;
cout << endl;
            // still active, 
            cout << "This twin path STILL active.\n";
#endif

            // now enqueue it
            //COMBO_PATH_ENTRY cpp;
            //cpp.first =  -listTwinPathInfo[i].mrca1;
            //cpp.second.first = -listTwinPathInfo[i].mrca2;
            //cpp.second.second = &listTwinPathInfo[i] ;
            //queueComboPath.push(cpp);
            listTwinRemained.push_back( &listTwinPathInfo[i]  );
        }
        else
        {
            //cout << "This twin path not active.\n";
        }
    }

    // now continue to cut
#if 0
    vector<COMBO_PATH_INFO *> listTwinSelected;
    while( queueComboPath.empty() == false )
    {
        COMBO_PATH_ENTRY cpp = queueComboPath.top();
        queueComboPath.pop();
        // if this edge is already covered, skip
        set<int> joinEdges;
        JoinSets( cpp.second.second->edgesInPathes, edgesCut, joinEdges);
        if(  joinEdges.size() > 0 )
        {
            // not active, 
            continue;
        }
//cout << "Now cut " << cpp.second.second->mrca1 << endl;
cout << "Now cut (second stage) " << cpp.second.second->mrca1 << endl;
cout << "Now cut (second stage) " << cpp.second.second->mrca2 << endl;
cout << "This combo path covered by cuts ";
DumpIntSet(joinEdges);
cout << "This is for Processing i = " << cpp.second.second->lv1;
cout << ", j = " << cpp.second.second->lv2;
cout << ", p = " << cpp.second.second->lv3;
cout << ", q = " << cpp.second.second->lv4;
cout << ", mrca2 = " << cpp.second.second->mrca2;
cout << endl;
        // check whether this is a path indpendent of the rest
        for( int jj = 0; jj< (int)listTwinSelected.size(); ++jj  )
        {
            set<int> sint;
            JoinSets(cpp.second.second->edgesInPathes, listTwinSelected[jj]->edgesInPathes, sint);
            if( sint.size() > 0 )
            {
cout << "edgesInPaths = ";
DumpIntSet(cpp.second.second->edgesInPathes);
cout << "TwinSelected: ";
DumpIntSet( listTwinSelected[jj]->edgesInPathes );
cout << "sint = ";
DumpIntSet( sint );
                cout << "WARNING: this path is NOT an independent twin path.\n";
YW_ASSERT_INFO( false, "ERROR");
            }
        }
        listTwinSelected.push_back( cpp.second.second );

        // add this cut. For simplicity, denote as the mrca, rather than real edges
        edgesCut.insert( cpp.second.second->mrca1 );
        edgesCut.insert( cpp.second.second->mrca2 );
    }
#endif

#if 0
    DirectedGraph graphPartition;
    vector<int> nodesId;
    for( int i=0; i<(int)listTwinRemained.size(); ++i  )
    {
        // is this cut good?
        nodesId.push_back( graphPartition.AddVertex(0) );
    }
    // now create edges
    for( int i=0; i<(int) listTwinRemained.size(); ++i )
    {
        for(int j=i+1; j<(int)listTwinRemained.size(); ++j)
        {
            set<int> sint;
            JoinSets(listTwinRemained[i]->edgesInPathes, listTwinRemained[j]->edgesInPathes, sint);

            // if no intsection, no edge
            if( sint.size() == 0)
            {
                continue;
            }
            if( listTwinRemained[i]->mrca1 ==  listTwinRemained[j]->mrca1 )
            {
                if( listTwinRemained[i]->mrca2 ==  listTwinRemained[j]->mrca2 )
                {
                    continue;
                }
                else if( listTwinRemained[i]->mrca2 <  listTwinRemained[j]->mrca2 )
                {
                    graphPartition.AddEdge( nodesId[i], nodesId[j], 0);
                }
                else
                {
                    graphPartition.AddEdge( nodesId[j], nodesId[i], 0);
                }
                continue;
            }
            if( listTwinRemained[i]->mrca2 ==  listTwinRemained[j]->mrca2 )
            {
                if( listTwinRemained[i]->mrca1 ==  listTwinRemained[j]->mrca1 )
                {
                    continue;
                }
                else if( listTwinRemained[i]->mrca1 <  listTwinRemained[j]->mrca1 )
                {
                    graphPartition.AddEdge( nodesId[i], nodesId[j], 0);
                }
                else
                {
                    graphPartition.AddEdge( nodesId[j], nodesId[i], 0);
                }
                continue;
            }



            // consider the cases when both branches intersects
            if( sint.find(listTwinRemained[i]->mrca1 ) != sint.end()  && 
                sint.find(listTwinRemained[j]->mrca2 ) != sint.end()  )
            {
                YW_ASSERT_INFO( false, "edge can not be oriented"  );
            }

            if( sint.find(listTwinRemained[j]->mrca1 ) != sint.end()  && 
                sint.find(listTwinRemained[i]->mrca2 ) != sint.end()  )
            {
                YW_ASSERT_INFO( false, "edge can not be oriented"  );
            }


            if(   listTwinRemained[i]->mrca1   listTwinRemained[i]->mrca2 ) != sint.end()  )
            {
                // add an edge
                graphPartition.AddEdge( nodesId[i], nodesId[j], 0);
cout << "Part " << i << " cut part " << j << endl;

            }

            if(  sint.find( listTwinRemained[j]->mrca1 ) != sint.end()  
                || sint.find( listTwinRemained[j]->mrca2 ) != sint.end()  )
            {
                // add an edge
                graphPartition.AddEdge( nodesId[j], nodesId[i], 0);
cout << "Part " << j << " cut part " << i << endl;

            }

        }
    }
graphPartition.OutputGML("graphPartition.gml");
    // is this graph containing cycle?
    YW_ASSERT_INFO( graphPartition.IsAcyclic() == true, "The graph is NOT acyclic" );
#endif

    return edgesCut.size();
}




// expse for global use
void ReducePairTreesMAF( const MarginalTree &tree1, const MarginalTree &tree2, 
                               MarginalTree &resTree1, MarginalTree &resTree2,
							   vector< pair<int,int> > *pRemovedLeaves, 
							   vector<int> *pRemoveLeavesSurvivors )
{
//cout << "Original tree1 = \n";
//tree1.Dump();
//cout << "Original tree2 = \n";
//tree2.Dump();

	vector< pair<int,int> > listRemovedLeafs;
	vector<int> listRemovedSurviors;

    // now we try to reduce the pair of trees, by the following:
    // a: if a pair of leaves occurs as siblings for both trees, the merge them to form a single node
    resTree1 = tree1;
    resTree2 = tree2;


	// to be maintained
	int numLeavesCur = resTree1.GetNumLeaves();
//cout << "Original Leave num = " << numLeavesCur << endl;
    // we simply checking one by one
    // this big loop search for two kinds of things: identical subtrees, and identical chains
    while(true)
    {
        int numLeavesRemoved = 0;
        while( true )
        {
            bool fChanged = false;
            for( int i=0; i<resTree1.GetNumLeaves(); ++i )
            {
                for( int j=i+1; j<resTree1.GetNumLeaves(); ++j )
                {
                    // if (i,j) siblings is not, skip
                    if( resTree1.GetParent(i) != resTree1.GetParent(j) )
                    {
                        continue;
                    }
                    // now look for them for the second
                    if( resTree2.GetParent(i) != resTree2.GetParent(j) )
                    {
                        continue;
                    }

                    // now we find one 
                    MergeTwoLeavesOfTree( resTree1, i, j );
                    MergeTwoLeavesOfTree( resTree2, i, j );
                    fChanged = true;
					numLeavesCur --;

					// keep track of it
					pair<int,int> pp(i, j);
					listRemovedLeafs.push_back( pp );
					listRemovedSurviors.push_back( numLeavesCur-1 );

//cout << "REMOVING: nodes i = " << i << ", j = " << j << ", and adding to " << numLeavesCur-1 << endl;
                    break;
                }
                if( fChanged == true )
                {
                    break;
                }
            }

            if( fChanged == false )
            {
                break;
            }
            numLeavesRemoved++;
    //cout << "After this step, the reduced tree1 = \n";
    //resTree1.Dump();
    //cout << "After this step, the reduced tree2 = \n";
    //resTree2.Dump();
        }

    //cout << "numLeavesRemoved = " << numLeavesRemoved << endl;
    //cout << "Changed tree1 = \n";
    //resTree1.Dump();
    //cout << "Changed tree2 = \n";
    //resTree2.Dump();



        // now we deal with chains
        map< vector<int>, int > chainsFound1;
        resTree1.BuildDescendantInfo();
        map< vector<int>, int > chainsFound2;
        resTree2.BuildDescendantInfo();
    break;


    cout << "Searching for chain 1...\n";
        FindChainsInTree( resTree1,  chainsFound1 );
    cout << "Searching for chain 2...\n";
        FindChainsInTree( resTree2,  chainsFound2 );

#if 0

        // now test whether there are chains the same
        bool fCont = false;
        for( map< vector<int>, int > :: iterator it = chainsFound1.begin(); it != chainsFound1.end(); ++it )
        {
            if( chainsFound2.find(it->first) == chainsFound2.end() )
            {
                continue;
            }
            // now we find an identical chain
cout << "Found a pair of identical chains!\n";
            fCont = true;

            // what we do is to remove the first leaf from the two trees
cout << "Remove leaf = " << it->first[0]  << endl;
            resTree1.RemoveLeafNodeFromBinaryTree(  it->first[0]  );
            resTree2.RemoveLeafNodeFromBinaryTree(  it->first[0]  );
cout << "After removal, tree1 = \n";
resTree1.Dump();
cout << "After removal, tree2 = \n";
resTree2.Dump();
        }

        if(fCont == false )
        {
            break;
        }
#endif
    }

	// now see if we can do it
	if( pRemovedLeaves != NULL )
	{
		*pRemovedLeaves = listRemovedLeafs;
	}
	if( pRemoveLeavesSurvivors != NULL )
	{
		*pRemoveLeavesSurvivors = listRemovedSurviors;
	}
}

void RecoverContractedSubtree(int lvReduced, set<int> &reoveredSubtree, 
							  const vector< pair<int,int>  > &removedLeaves, const vector<int> &removeLeavesSurvivors)
{
	// go throught the deleted list backwards
	vector<int> trackLvsPos;
	trackLvsPos.push_back( lvReduced );

	for(int i= removedLeaves.size()-1; i>=0;  --i)
	{
		// these two were removed the last time
		int rm1 = removedLeaves[i].first;
		int rm2 = removedLeaves[i].second;
		// make sure rm1 is smaller
		if( rm1 > rm2 )
		{
			int tmp = rm1;
			rm1 = rm2;
			rm2 = tmp;
		}
		
		// update each item in the list
		vector<int> traclLvsListNew;
		for(int j=0; j<(int)trackLvsPos.size(); ++j)
		{
			// if this is what was removed, then add the two removed to the track list
			if( removeLeavesSurvivors[i] == trackLvsPos[j] )
			{
				traclLvsListNew.push_back( rm1 );
				traclLvsListNew.push_back( rm2 );
			}
			else
			{
				// only need to update position for this one
				// this depends on whether the removed one affects the position
				int posNew = trackLvsPos[j];
				if( posNew >= rm1 )
				{
					// SHOUld be after first item since it is after ITS deletion
					posNew++;
				}
				if( posNew >= rm2 )
				{
					posNew ++;
				}
				traclLvsListNew.push_back( posNew );
				
			}
		}
		// store the new track list
		trackLvsPos = traclLvsListNew;
	}

	// 
	PopulateSetByVec( reoveredSubtree, trackLvsPos );
}

void RecoverOrigSubsetLeaves( const vector<int> &listNewLvs, const vector< pair<int,int>  > &removedLeaves,
							  const vector<int> &removeLeavesSurvivors, set<int> &lvsRecovered  )
{
	lvsRecovered.clear();
	for( int i=0; i<(int)listNewLvs.size(); ++i )
	{
		set<int> setLvsOrig;
		RecoverContractedSubtree( listNewLvs[i], setLvsOrig, removedLeaves, removeLeavesSurvivors);
		UnionSets(lvsRecovered, setLvsOrig);
	}
}

// aux. functions for ILP output

static void OutputCki( ofstream &outFile, int tree, int i )
{
    outFile << "C," << tree << "," << i;  
} 
static void OutputMkij( ofstream &outFile, int tree, int i, int j )
{
    outFile << "M," << tree << "," << i << "," << j;  
} 
static void OutputRkit( ofstream &outFile, int tree, int i, int t )
{
    // i is a leaf, and t is a node (ancestral to i)
    outFile << "R," << tree << "," << i << "," << t;  
} 
static void OutputGij( ofstream &outFile, int i, int j )
{
    // only for two leaves i and j
    outFile << "G," << i << "," << j;  
} 





void OutputILPMaxAgreeForest(const char* fileName, const MarginalTree &treeOrig1, const MarginalTree &treeOrig2 )
{
    YW_ASSERT_INFO( treeOrig1.GetTotNodesNum() == treeOrig2.GetTotNodesNum(), "mismatch" );

cout << "OutputILPMaxAgreeForest: treeOrig1 = ";
treeOrig1.Dump();
cout << "OutputILPMaxAgreeForest: tree2 = ";
treeOrig2.Dump();
    // first compute constants that are useful
#if 0
MarginalTree treetest1, treetest2;
treetest1.numLeaves = 5;
treetest1.listNodeLabels.push_back(1);
treetest1.listNodeLabels.push_back(2);
treetest1.listNodeLabels.push_back(3);
treetest1.listNodeLabels.push_back(4);
treetest1.listNodeLabels.push_back(5);
treetest1.listNodeLabels.push_back(6);
treetest1.listNodeLabels.push_back(7);
treetest1.listNodeLabels.push_back(8);
treetest1.listNodeLabels.push_back(9);
treetest1.listParentNodePos.push_back(5);
treetest1.listParentNodePos.push_back(5);
treetest1.listParentNodePos.push_back(6);
treetest1.listParentNodePos.push_back(6);
treetest1.listParentNodePos.push_back(7);
treetest1.listParentNodePos.push_back(7);
treetest1.listParentNodePos.push_back(8);
treetest1.listParentNodePos.push_back(8);
treetest1.listParentNodePos.push_back(-1);

treetest2.numLeaves = 5;
treetest2.listNodeLabels.push_back(1);
treetest2.listNodeLabels.push_back(2);
treetest2.listNodeLabels.push_back(3);
treetest2.listNodeLabels.push_back(4);
treetest2.listNodeLabels.push_back(5);
treetest2.listNodeLabels.push_back(6);
treetest2.listNodeLabels.push_back(7);
treetest2.listNodeLabels.push_back(8);
treetest2.listNodeLabels.push_back(9);
treetest2.listParentNodePos.push_back(6);
treetest2.listParentNodePos.push_back(6);
treetest2.listParentNodePos.push_back(5);
treetest2.listParentNodePos.push_back(7);
treetest2.listParentNodePos.push_back(5);
treetest2.listParentNodePos.push_back(8);
treetest2.listParentNodePos.push_back(7);
treetest2.listParentNodePos.push_back(8);
treetest2.listParentNodePos.push_back(-1);
MarginalTree tree1ReducedTest, tree2ReducedTest;
ReducePairTreesMAF(treetest1, treetest2, tree1ReducedTest, tree2ReducedTest);
exit(1);
#endif
    MarginalTree  tree1Reduced = treeOrig1;
    MarginalTree  tree2Reduced = treeOrig2;


    // buildup the descendent info
    tree1Reduced.BuildDescendantInfo();
    tree2Reduced.BuildDescendantInfo();

//    ReducePairTreesMAF(treeOrig1, treeOrig2, tree1Reduced, tree2Reduced);


    // This function outputs the ILP file
    // The folowing ILP is to minimize an approximate compsoite hapbound when case control is added
    // We approximate hapbound since we want to extend the applicability to larger range of data
	ofstream outFile(  fileName  );
	if(outFile.is_open() == false)
	{
		cout << "Can not open ILP output file: "<< fileName <<  endl; 
		return ; 
	}



    // Now we start to output ILP formulation
    // First is the objective
    // Note that we still only consider lower bounds BEFORE adding case/control
    outFile << "Minimize  \n";

    // finally the edge mutations
    for( int i = 0; i< tree1Reduced.GetTotNodesNum()-1; ++i )
    {
        OutputCki(outFile, 1, i);
        if( i < tree1Reduced.GetTotNodesNum()-2 )
        {
            outFile << "\n+ ";
        }

        //OutputCki(outFile, 2, i);
        //if( i < tree1Reduced.GetTotNodesNum()-2 )
        //{
        //    outFile << "\n+ ";
        //}

    }

    outFile << endl;

    // constraints
    outFile << endl;
    outFile << "subject to " << endl;
    outFile << endl;




    // now enforce m,i
    OutputCki( outFile, 1,  tree1Reduced.GetTotNodesNum()-1 );
    outFile << " = 0 \n";
    OutputCki( outFile, 2 , tree2Reduced.GetTotNodesNum()-1 );
    outFile << " = 0 \n";


    const MarginalTree *ptrTrees[2];
    ptrTrees[0] = &tree1Reduced;
    ptrTrees[1] = &tree2Reduced;

    // start from the first tree
    for(  int k=1; k<=2; ++k  )
    {
        const MarginalTree *pCurrTree = ptrTrees[k-1];

        for( int i= 0; i< pCurrTree->GetNumLeaves() ; ++i  )
        {
            for(int j=i+1; j< pCurrTree->GetNumLeaves(); ++j)
            {
                // first we need to find MRCA of i,j. 
                // note that we actually want to exluce MRCA, but include i,j!
                set<int> listPathNodes;
                int n1=i, n2 = j;
                listPathNodes.insert(i);
                listPathNodes.insert(j);
                while( n1 != n2 )
                {
                    // we alternatively move up, depend on which one is smaller
                    int nodeNew;
                    if( n1 < n2  )
                    {
                        // move n1
                        n1 = pCurrTree->GetParent(n1);
                        nodeNew = n1;
                    }
                    else
                    {
                        // move n2
                        n2 = pCurrTree->GetParent(n2);
                        nodeNew = n2;
                    }
                    // save this when n1 != n2
                    if( n1 != n2 )
                    {
                        listPathNodes.insert( nodeNew );
                    }
                }
                // pop up the last item MRCA
                //listPathNodes.pop_back();
                listPathNodes.erase(  n1  );
                



                // now we start to enforce property
                OutputMkij( outFile, 1, i, j );
                for( set<int> :: iterator it = listPathNodes.begin(); it != listPathNodes.end(); ++it )
                {
                    outFile << " + ";
                    OutputCki( outFile, k, *it );
                    outFile << endl;
                }
                outFile << " >= 1\n";

                /*  do we need the following? yes */
                for( set<int> :: iterator it = listPathNodes.begin(); it != listPathNodes.end(); ++it )
                {
                    OutputMkij( outFile, 1, i, j );
                    outFile << " + ";
                    OutputCki( outFile, k, *it );
                    outFile << " <= 1\n";
                }


            }
        }
    }


    // now make sure Mi,j,k equal
#if 0
    for( int i= 0; i< tree1Reduced.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1Reduced.GetNumLeaves(); ++j)
        {
            OutputMkij( outFile, 1, i, j );
            outFile << " - ";
            OutputMkij( outFile, 2, i, j );
            outFile << " = 0\n";
        }
    }
#endif

    // now try all possible triples of leaves i,j,k
    for( int i= 0; i< tree1Reduced.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1Reduced.GetNumLeaves(); ++j)
        {
            for(int k=j+1; k< tree1Reduced.GetNumLeaves(); ++k)
            {
                // is these have different triples on T1 and T2?
                // we do this by getting MRCA for all pairs of MRCAs
                int mrcaij1 = tree1Reduced.GetMRCA( i, j );
                int mrcajk1 = tree1Reduced.GetMRCA( j, k );
                int mrcaik1 = tree1Reduced.GetMRCA( i, k );
                int mrcaij2 = tree2Reduced.GetMRCA( i, j );
                int mrcajk2 = tree2Reduced.GetMRCA( j, k );
                int mrcaik2 = tree2Reduced.GetMRCA( i, k );

                bool fIncTriple = false;

                // now just test exhustively
                if( mrcaij1 == mrcajk1 )
                {
                    if( mrcaij2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }
                else if( mrcaij1 == mrcaik1 )
                {
                    if( mrcaij2 != mrcaik2  )
                    {
                        fIncTriple = true;
                    }
                }
                else 
                {
                    if( mrcaik2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }

                if(fIncTriple == false)
                {
                    // we are only interested in incompatible triple
                    continue;
                }

                // now require M for this triple
//                OutputMkij( outFile, 1, i, j );
//                outFile << " + ";
//                OutputMkij( outFile, 1, i, k );
//                outFile << " + ";
//                OutputMkij( outFile, 1, j, k );
//                outFile << " <= 1\n ";

//#if 0
                OutputMkij( outFile, 1, i, j );
                outFile << " + ";
                OutputMkij( outFile, 1, i, k );
                outFile << " <= 1\n ";

                OutputMkij( outFile, 1, i, j );
                outFile << " + ";
                OutputMkij( outFile, 1, j, k );
                outFile << " <= 1\n ";

                OutputMkij( outFile, 1, i, k );
                outFile << " + ";
                OutputMkij( outFile, 1, j, k );
                outFile << " <= 1\n ";
//#endif


            }
        }
    }

    // the following constraints are not really needed
    // but we hope they can speedup things
    // we enforce this: if M,i,j = M,j,k = 1, then Mi,k = 1
#if 0
    for( int i= 0; i< tree1Reduced.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1Reduced.GetNumLeaves(); ++j)
        {
            for(int k=j+1; k< tree1Reduced.GetNumLeaves(); ++k)
            {
                OutputMkij( outFile, 1, i, j );
                outFile << " + ";
                OutputMkij( outFile, 1, i, k );
                outFile << " - ";
                OutputMkij( outFile, 1, j, k );
                outFile << " <= 1\n ";

                OutputMkij( outFile, 1, i, j );
                outFile << " + ";
                OutputMkij( outFile, 1, j, k );
                outFile << " - ";
                OutputMkij( outFile, 1, i, k );
                outFile << " <= 1\n ";

                OutputMkij( outFile, 1, i, k );
                outFile << " + ";
                OutputMkij( outFile, 1, j, k );
                outFile << " - ";
                OutputMkij( outFile, 1, i, j );
                outFile << " <= 1\n ";

            }
        }
    }
#endif


//#if  0
    // now enforce additional property here
    // we try to find pair of leaves in tree1Reduced that are sibling and
    // then looks for another tree's same leaves
    for(int k=1; k<=2; ++k)
    {
        const MarginalTree *pCurrTree1; 
        const MarginalTree *pCurrTree2; 
        const MarginalTree *pCurrTree;
        int k1, k2;
        if( k == 1 )
        {
            k1 = 1;
            k2 = 2;
            pCurrTree1 = &tree1Reduced;
            pCurrTree2 = &tree2Reduced;
            pCurrTree = pCurrTree1;
        }
        else
        {
            k1 = 2;
            k2 = 1;
            pCurrTree1 = &tree2Reduced;
            pCurrTree2 = &tree1Reduced;
            pCurrTree = pCurrTree2;
        }
#if 0
        for( int i= 0; i< pCurrTree1->GetNumLeaves() ; ++i  )
        {
            for(int j=i+1; j< pCurrTree1->GetNumLeaves(); ++j)
            {
                // if they do not form siblings, skip
                if( pCurrTree1->GetParent(i) != pCurrTree1->GetParent(j)  )
                {
                    // skip it
                    continue;
                }

                // now what do we do? go to the other tree to see how things are going
                if( pCurrTree2->GetParent(i) == pCurrTree2->GetParent(j)  )
                {
                    // do not cut these tip branches
                    OutputCki( outFile, k1, i );
                    outFile << " = 0" <<  endl;
                    OutputCki( outFile, k1, j );
                    outFile << " = 0" << endl;
                    OutputCki( outFile, k2, i );
                    outFile << " = 0" << endl;
                    OutputCki( outFile, k2, j );
                    outFile << " = 0" << endl;
    cout << "Found one must-match pair of tips: i = " << i << ", j = " << j << endl;
                }
                else
                {
                    int p2i = pCurrTree2->GetParent(i);
                    int p2j = pCurrTree2->GetParent(j);
                    // test whether they are only sepearted by one branch
                    if( p2i == pCurrTree2->GetParent( p2j )    )
                    {
                        set<int> listChildren;
                        pCurrTree2->GetChildren(p2j, listChildren);
                        // remove j
                        listChildren.erase( j );
                        YW_ASSERT_INFO( listChildren.size() == 1, "Non-binary" );

                        // if the other child is a leaf, skip
                        if( pCurrTree2->IsLeaf( *listChildren.begin() ) == true )
                        {
                            continue;
                        }

                        //OutputCki( outFile, k2, *listChildren.begin() );
                        //outFile << " = 1" <<  endl;

                        // YW: changed to reflect the true definition here
                        OutputCki( outFile, k1,  i  );
                        outFile << " = 0" <<  endl;
                        OutputCki( outFile, k1,  j  );
                        outFile << " = 0" <<  endl;

                        OutputCki( outFile, k2,  i  );
                        outFile << " = 0" <<  endl;
                        OutputCki( outFile, k2,  j  );
                        outFile << " = 0" <<  endl;
                        OutputCki( outFile, k2,  p2j  );
                        outFile << " = 0" <<  endl;


    cout << "Found one edge that must be cut: starte = "  << *listChildren.begin() << "\n";
                    }
                    else if( p2j == pCurrTree2->GetParent( p2i ) )
                    {
                        set<int> listChildren;
                        pCurrTree2->GetChildren(p2i, listChildren);
                        // remove j
                        listChildren.erase( i );
                        YW_ASSERT_INFO( listChildren.size() == 1, "Non-binary" );

                        // if the other child is a leaf, skip
                        if( pCurrTree2->IsLeaf( *listChildren.begin() ) == true )
                        {
                            continue;
                        }

                        //OutputCki( outFile, k2, *listChildren.begin() );
                        //outFile << " = 1" << endl;
                        OutputCki( outFile, k1,  i  );
                        outFile << " = 0" <<  endl;
                        OutputCki( outFile, k1,  j  );
                        outFile << " = 0" <<  endl;

                        OutputCki( outFile, k2,  i  );
                        outFile << " = 0" <<  endl;
                        OutputCki( outFile, k2,  j  );
                        outFile << " = 0" <<  endl;
                        OutputCki( outFile, k2,  p2i  );
                        outFile << " = 0" <<  endl;

    cout << "Found one edge that must be cut: starte = "  << *listChildren.begin() << "\n";
                    }
                }
            }
        }
#endif


        // enforce additional property: there is no edge and its immediate parent are cut
        for( int nn = pCurrTree1->GetNumLeaves(); nn < pCurrTree1->GetTotNodesNum()-1;  ++nn )
        {
            // C,k,pa + c,k,desc1 <=1
            //int pp = pCurrTree1->GetParent( nn );
            int pdesc = pCurrTree1->GetLeftDescendant( nn );
            YW_ASSERT_INFO(pdesc >=0, "no descent");
            OutputCki( outFile, k1,  nn  );
            outFile << " + ";
            OutputCki( outFile, k1,  pdesc );
            outFile << " <= 1\n";

            pdesc = pCurrTree1->GetRightDescendant( nn );
            YW_ASSERT_INFO(pdesc >=0, "no descent");
            OutputCki( outFile, k1,  nn  );
            outFile << " + ";
            OutputCki( outFile, k1,  pdesc );
            outFile << " <= 1\n";
        }

    }
//#endif


    // variables
    outFile << "\nBinary " << endl;

    // Cki
    for( int i = 0; i< tree1Reduced.GetTotNodesNum(); ++i )
    {
        OutputCki( outFile, 1, i );
        outFile << endl;
        OutputCki( outFile, 2, i );
        outFile << endl;
    }
    // mkij
    for( int i= 0; i< tree1Reduced.GetNumLeaves() ; ++i  )
    {
        for( int j= i+1; j< tree1Reduced.GetNumLeaves() ; ++j  )
        {
            OutputMkij( outFile, 1, i, j );
            outFile << endl;
//            OutputMkij( outFile, 2, i, j );
//            outFile << endl;
        }
    }


    // For now, we do not really compute the bound directly but output a ILP file
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Finally close the file
    outFile << "end" << endl;
    outFile.close();

}


//
// ########################################################################################################
// The difference from the above is: remove the auxilary variables Mi,j,k
// Rather use the simple idea: if two pairs of nodes is disjoint, then the same pair must be
// disjoint in the other tree as well 
//
void OutputILPMaxAgreeForestVarReduced(const char* fileName, const MarginalTree &treeOrig1, const MarginalTree &treeOrig2 )
{
    YW_ASSERT_INFO( treeOrig1.GetTotNodesNum() == treeOrig2.GetTotNodesNum(), "mismatch" );

cout << "OutputILPMaxAgreeForest: treeOrig1 = ";
treeOrig1.Dump();
cout << "OutputILPMaxAgreeForest: tree2 = ";
treeOrig2.Dump();
    // first compute constants that are useful

    MarginalTree  tree1Reduced = treeOrig1;
    MarginalTree  tree2Reduced = treeOrig2;


    // buildup the descendent info
    tree1Reduced.BuildDescendantInfo();
    tree2Reduced.BuildDescendantInfo();

//    ReducePairTreesMAF(treeOrig1, treeOrig2, tree1Reduced, tree2Reduced);


    // This function outputs the ILP file
    // The folowing ILP is to minimize an approximate compsoite hapbound when case control is added
    // We approximate hapbound since we want to extend the applicability to larger range of data
	ofstream outFile(  fileName  );
	if(outFile.is_open() == false)
	{
		cout << "Can not open ILP output file: "<< fileName <<  endl; 
		return ; 
	}



    // Now we start to output ILP formulation
    // First is the objective
    // Note that we still only consider lower bounds BEFORE adding case/control
    outFile << "Minimize  \n";

    // finally the edge mutations
    for( int i = 0; i< tree1Reduced.GetTotNodesNum()-1; ++i )
    {
        OutputCki(outFile, 1, i);
        if( i < tree1Reduced.GetTotNodesNum()-2 )
        {
            outFile << "\n+ ";
        }

        //OutputCki(outFile, 2, i);
        //if( i < tree1Reduced.GetTotNodesNum()-2 )
        //{
        //    outFile << "\n+ ";
        //}

    }

    outFile << endl;

    // constraints
    outFile << endl;
    outFile << "subject to " << endl;
    outFile << endl;




    // now enforce m,i
    OutputCki( outFile, 1,  tree1Reduced.GetTotNodesNum()-1 );
    outFile << " = 0 \n";
    OutputCki( outFile, 2 , tree2Reduced.GetTotNodesNum()-1 );
    outFile << " = 0 \n";


    const MarginalTree *ptrTrees[2];
    ptrTrees[0] = &tree1Reduced;
    ptrTrees[1] = &tree2Reduced;

    // start from the first tree
    for( int i= 0; i< ptrTrees[0]->GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< ptrTrees[0]->GetNumLeaves(); ++j)
        {
            set<int> listPathNodes[2];
             for(  int k=1; k<=2; ++k  )
             {
                const MarginalTree *pCurrTree = ptrTrees[k-1];
                // first we need to find MRCA of i,j. 
                // note that we actually want to exluce MRCA, but include i,j!
                int n1=i, n2 = j;
                listPathNodes[k-1].insert(i);
                listPathNodes[k-1].insert(j);
                while( n1 != n2 )
                {
                    // we alternatively move up, depend on which one is smaller
                    int nodeNew;
                    if( n1 < n2  )
                    {
                        // move n1
                        n1 = pCurrTree->GetParent(n1);
                        nodeNew = n1;
                    }
                    else
                    {
                        // move n2
                        n2 = pCurrTree->GetParent(n2);
                        nodeNew = n2;
                    }
                    // save this when n1 != n2
                    if( n1 != n2 )
                    {
                        listPathNodes[k-1].insert( nodeNew );
                    }
                }
                // pop up the last item MRCA
                //listPathNodes.pop_back();
                listPathNodes[k-1].erase(  n1  );
            
             }


            // now we start to enforce property
             for(int kk = 1; kk<=2; ++kk)
             {
                int kk2 = 2;
                if( kk2 == kk )
                {
                    kk2 = 1;
                }
                bool fFirst = true;
                for( set<int> :: iterator it = listPathNodes[kk-1].begin(); it != listPathNodes[kk-1].end(); ++it )
                {
                    if( fFirst == true)
                    {
                        fFirst = false;
                    }
                    else
                    {
                        outFile << " + ";
                    }
                    outFile <<  listPathNodes[kk2-1].size() << "   ";
                    OutputCki( outFile, kk, *it );
                    outFile << endl;
                }
                for( set<int> :: iterator it = listPathNodes[kk2-1].begin(); it != listPathNodes[kk2-1].end(); ++it )
                {
                    outFile << " - ";
                    outFile << "   ";
                    OutputCki( outFile, kk2, *it );
                    outFile << endl;
                }
                outFile << " >= 0\n";

             }


        }
    }


    // now try all possible triples of leaves i,j,k
    for( int i= 0; i< tree1Reduced.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1Reduced.GetNumLeaves(); ++j)
        {
            for(int k=j+1; k< tree1Reduced.GetNumLeaves(); ++k)
            {
                // we do this by getting MRCA for all pairs of MRCAs
                int mrcaij1 = tree1Reduced.GetMRCA( i, j );
                int mrcajk1 = tree1Reduced.GetMRCA( j, k );
                int mrcaik1 = tree1Reduced.GetMRCA( i, k );
                int mrcaij2 = tree2Reduced.GetMRCA( i, j );
                int mrcajk2 = tree2Reduced.GetMRCA( j, k );
                int mrcaik2 = tree2Reduced.GetMRCA( i, k );


                bool fIncTriple = false;

                // now just test exhustively
                if( mrcaij1 == mrcajk1 )
                {
                    if( mrcaij2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }
                else if( mrcaij1 == mrcaik1 )
                {
                    if( mrcaij2 != mrcaik2  )
                    {
                        fIncTriple = true;
                    }
                }
                else 
                {
                    if( mrcaik2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }

                if(fIncTriple == false)
                {
                    // we are only interested in incompatible triple
                    continue;
                }

                // now require M for this triple
//                OutputMkij( outFile, 1, i, j );
//                outFile << " + ";
//                OutputMkij( outFile, 1, i, k );
//                outFile << " + ";
//                OutputMkij( outFile, 1, j, k );
//                outFile << " <= 1\n ";


//#if 0
                // we find the edges on the path
                set<int> triPathEdges;
                set<int> listEdgesij;
                tree1Reduced.GetPath( i,j, listEdgesij );
                triPathEdges = listEdgesij;
                set<int> listEdgesjk;
                tree1Reduced.GetPath( j,k, listEdgesjk );
                UnionSets( triPathEdges, listEdgesjk );
                set<int> listEdgesik;
                tree1Reduced.GetPath( i,k, listEdgesik );
                UnionSets( triPathEdges, listEdgesik );


                // ensure at least one edge is cut on tri-path
                YW_ASSERT_INFO(triPathEdges.size() > 0, "Can not be empty");
                set<int> :: iterator it = triPathEdges.begin();
                OutputCki( outFile, 1,  *it );
                ++it;
                for( ; it != triPathEdges.end(); ++it  )
                {
                    outFile << " + \n";
                    OutputCki( outFile, 1,  *it );
                }
                outFile << " >= 1 \n";
//#endif




                // we find the edges on the path
                triPathEdges.clear();
                listEdgesij.clear();
                tree2Reduced.GetPath( i,j, listEdgesij );
                triPathEdges = listEdgesij;
                listEdgesjk.clear();
                tree2Reduced.GetPath( j,k, listEdgesjk );
                UnionSets( triPathEdges, listEdgesjk );
                listEdgesik.clear();
                tree2Reduced.GetPath( i,k, listEdgesik );
                UnionSets( triPathEdges, listEdgesik );


                // ensure at least one edge is cut on tri-path
                YW_ASSERT_INFO(triPathEdges.size() > 0, "Can not be empty");
                set<int> :: iterator it2 = triPathEdges.begin();
                OutputCki( outFile, 2,  *it2 );
                ++it2;
                for( ; it2 != triPathEdges.end(); ++it2  )
                {
                    outFile << " + \n";
                    OutputCki( outFile, 2,  *it2 );
                }
                outFile << " >= 1 \n";


#if 0
                // we find the edges on the path
//                set<int> triPathEdges;
                set<int> listEdgesij;
                tree1.GetPath( i,j, listEdgesij );
 //               triPathEdges = listEdgesij;
                set<int> listEdgesjk;
                tree1.GetPath( j,k, listEdgesjk );
                set<int> setInt;
                JoinSets(listEdgesij, listEdgesjk, setInt);
                SubtractSets(listEdgesij, setInt);
                SubtractSets(listEdgesjk, setInt);

                // ensure at least one edge is cut on tri-path
                YW_ASSERT_INFO(listEdgesij.size() > 0, "Can not be empty");
                set<int> :: iterator it = listEdgesij.begin();
                OutputCki( outFile, 1,  *it );
                ++it;
                for( ; it != listEdgesij.end(); ++it  )
                {
                    outFile << " + \n";
                    OutputCki( outFile, 1,  *it );
                }
                outFile << " + \n";
                //outFile << " >= 1 \n";


                YW_ASSERT_INFO(setInt.size() > 0, "Can not be empty");
                it = setInt.begin();
                OutputCki( outFile, 1,  *it );
                ++it;
                for( ; it != setInt.end(); ++it  )
                {
                    outFile << " + \n";
                    outFile << "2    ";
                    OutputCki( outFile, 1,  *it );
                }
                outFile << " + \n";
                //outFile << " >= 1 \n";

                //UnionSets( triPathEdges, listEdgesjk );
                //set<int> listEdgesik;
                //tree1.GetPath( i,k, listEdgesik );
                //UnionSets( triPathEdges, listEdgesik );
                //triPathEdges = listEdgesjk;
                // ensure at least one edge is cut on tri-path
                YW_ASSERT_INFO(listEdgesjk.size() > 0, "Can not be empty");
                it = listEdgesjk.begin();
                OutputCki( outFile, 1,  *it );
                ++it;
                for( ; it != listEdgesjk.end(); ++it  )
                {
                    outFile << " + \n";
                    OutputCki( outFile, 1,  *it );
                }
                outFile << " >= 1 \n";
#endif



            }
        }
    }



#if 0
    // now try all possible triples of leaves i,j,k
    for( int i= 0; i< tree1Reduced.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1Reduced.GetNumLeaves(); ++j)
        {
            for(int k=j+1; k< tree1Reduced.GetNumLeaves(); ++k)
            {
                // is these have different triples on T1 and T2?
                // we do this by getting MRCA for all pairs of MRCAs
                int mrcaij1 = tree1Reduced.GetMRCA( i, j );
                int mrcajk1 = tree1Reduced.GetMRCA( j, k );
                int mrcaik1 = tree1Reduced.GetMRCA( i, k );
                int mrcaij2 = tree2Reduced.GetMRCA( i, j );
                int mrcajk2 = tree2Reduced.GetMRCA( j, k );
                int mrcaik2 = tree2Reduced.GetMRCA( i, k );

                bool fIncTriple = false;

                // now just test exhustively
                if( mrcaij1 == mrcajk1 )
                {
                    if( mrcaij2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }
                else if( mrcaij1 == mrcaik1 )
                {
                    if( mrcaij2 != mrcaik2  )
                    {
                        fIncTriple = true;
                    }
                }
                else 
                {
                    if( mrcaik2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }

                if(fIncTriple == false)
                {
                    // we are only interested in incompatible triple
                    continue;
                }

                // now require M for this triple
                OutputMkij( outFile, 1, i, j );
                outFile << " + ";
                OutputMkij( outFile, 1, i, k );
                outFile << " + ";
                OutputMkij( outFile, 1, j, k );
                outFile << " <= 1\n ";

#if 0
                OutputMkij( outFile, 1, i, j );
                outFile << " + ";
                OutputMkij( outFile, 1, i, k );
                outFile << " <= 1\n ";

                OutputMkij( outFile, 1, i, j );
                outFile << " + ";
                OutputMkij( outFile, 1, j, k );
                outFile << " <= 1\n ";

                OutputMkij( outFile, 1, i, k );
                outFile << " + ";
                OutputMkij( outFile, 1, j, k );
                outFile << " <= 1\n ";
#endif


            }
        }
    }
#endif

//#if  0
    // now enforce additional property here
    // we try to find pair of leaves in tree1Reduced that are sibling and
    // then looks for another tree's same leaves
    for(int k=1; k<=2; ++k)
    {
        const MarginalTree *pCurrTree1; 
        const MarginalTree *pCurrTree2; 
        const MarginalTree *pCurrTree;
        int k1, k2;
        if( k == 1 )
        {
            k1 = 1;
            k2 = 2;
            pCurrTree1 = &tree1Reduced;
            pCurrTree2 = &tree2Reduced;
            pCurrTree = pCurrTree1;
        }
        else
        {
            k1 = 2;
            k2 = 1;
            pCurrTree1 = &tree2Reduced;
            pCurrTree2 = &tree1Reduced;
            pCurrTree = pCurrTree2;
        }


        // enforce additional property: there is no edge and its immediate parent are cut
        for( int nn = pCurrTree1->GetNumLeaves(); nn < pCurrTree1->GetTotNodesNum()-1;  ++nn )
        {
            // C,k,pa + c,k,desc1 <=1
            //int pp = pCurrTree1->GetParent( nn );
            int pdesc = pCurrTree1->GetLeftDescendant( nn );
            YW_ASSERT_INFO(pdesc >=0, "no descent");
            OutputCki( outFile, k1,  nn  );
            outFile << " + ";
            OutputCki( outFile, k1,  pdesc );
            outFile << " <= 1\n";

            pdesc = pCurrTree1->GetRightDescendant( nn );
            YW_ASSERT_INFO(pdesc >=0, "no descent");
            OutputCki( outFile, k1,  nn  );
            outFile << " + ";
            OutputCki( outFile, k1,  pdesc );
            outFile << " <= 1\n";
        }

    }
//#endif


    // variables
    outFile << "\nBinary " << endl;

    // Cki
    for( int i = 0; i< tree1Reduced.GetTotNodesNum(); ++i )
    {
        OutputCki( outFile, 1, i );
        outFile << endl;
        OutputCki( outFile, 2, i );
        outFile << endl;
    }


    // For now, we do not really compute the bound directly but output a ILP file
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Finally close the file
    outFile << "end" << endl;
    outFile.close();

}























void OutputILPMaxAgreeForestTest(const char* fileName, const MarginalTree &tree1, const MarginalTree &tree2 )
{
    YW_ASSERT_INFO( tree1.GetTotNodesNum() == tree2.GetTotNodesNum(), "mismatch" );

cout << "OutputILPMaxAgreeForest: tree1 = ";
tree1.Dump();
cout << "OutputILPMaxAgreeForest: tree2 = ";
tree2.Dump();
tree1.OutputGML( "tree1.gml" );
tree2.OutputGML( "tree2.gml" );
    // first compute constants that are useful


    // This function outputs the ILP file
    // The folowing ILP is to minimize an approximate compsoite hapbound when case control is added
    // We approximate hapbound since we want to extend the applicability to larger range of data
	ofstream outFile(  fileName  );
	if(outFile.is_open() == false)
	{
		cout << "Can not open ILP output file: "<< fileName <<  endl; 
		return ; 
	}



    // Now we start to output ILP formulation
    // First is the objective
    // Note that we still only consider lower bounds BEFORE adding case/control
    outFile << "Minimize  \n";

    // finally the edge mutations
    for( int i = 0; i< tree1.GetTotNodesNum()-1; ++i )
    {
        OutputCki(outFile, 1, i);
        if( i < tree1.GetTotNodesNum()-2 )
        {
            outFile << "\n+ ";
        }


    }

    outFile << endl;

    // constraints
    outFile << endl;
    outFile << "subject to " << endl;
    outFile << endl;




    // now enforce m,i
    OutputCki( outFile, 1,  tree1.GetTotNodesNum()-1 );
    outFile << " = 0 \n";
    OutputCki( outFile, 2 , tree2.GetTotNodesNum()-1 );
    outFile << " = 0 \n";

    // keep two trees
    const MarginalTree *ptrTrees[2];
    ptrTrees[0] = &tree1;
    ptrTrees[1] = &tree2;

    // now store which pairs of nodes we need to output for constraints
    // WARNING: we assume the first node is always smaller than (or equal) the second node
    set< pair<int,int> > listPairNodesConstraint[2];

    // start from the first tree
    const MarginalTree *pCurrTree = ptrTrees[0];

    for( int i= 0; i< pCurrTree->GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< pCurrTree->GetNumLeaves(); ++j)
        {
            // first we need to find MRCA of i,j. 
            // note that we actually want to exluce MRCA, but include i,j!
            //vector<int> listPathNodes;
            int n1=i, n2 = j;
            //listPathNodes.push_back(i);
            //listPathNodes.push_back(j);
            while( n1 <= n2 )
            {
                // IMPORTANT: make sure n1 <= n2 (true upon entry)

                // enforce an property
                pair<int,int> pp(n1, n2);
                if( listPairNodesConstraint[0].find(pp) != listPairNodesConstraint[0].end()   )
                {
                    // we already reach what we need, stop
                    break;
                }
                listPairNodesConstraint[0].insert(pp);

                if( n1 == n2 )
                {
                    // for the last one, simply set to be 1 as always
                    OutputMkij( outFile, 1, n1, n1 );
                    outFile << " = 1\n";
                    break;
                }
                else
                {
                    // we alternatively move up, depend on which one is smaller
                    int nodeNew;
                    bool fMoven1 = true;
                    if( n1 < n2  )
                    {
                        // move n1
                        nodeNew = pCurrTree->GetParent(n1);
                        fMoven1 = true;
                    }
                    else
                    {
                        // move n2
                        nodeNew = pCurrTree->GetParent(n2);
                        fMoven1 = false;
                    }

                    int n1New, n2New, edgeCuti;
                    if( fMoven1 == true ) 
                    {
                        n1New = nodeNew;
                        n2New = n2;
                        edgeCuti = n1;
                    }
                    else
                    {
                        n1New = n1;
                        n2New = nodeNew;
                        edgeCuti = n2;
                    }
                    if( n1New > n2New )
                    {
                        OrderInt(n1New, n2New);
                    }

                    // here are constraints
                    OutputMkij( outFile, 1, n1, n2 );
                    outFile << " - ";
                    OutputMkij( outFile, 1, n1New, n2New );
                    outFile << " <= 0\n";

                    OutputMkij( outFile, 1, n1, n2 );
                    outFile << " + ";
                    OutputCki( outFile, 1,  edgeCuti);
                    outFile << " - ";
                    OutputMkij( outFile, 1, n1New, n2New );
                    outFile << " >= 0\n";

                    OutputMkij( outFile, 1, n1, n2 );
                    outFile << " + ";
                    OutputCki( outFile, 1,  edgeCuti);
                    outFile << " <= 1\n";

                     // now update n1 and n2
                    n1 = n1New;
                    n2 = n2New;
               }


                // save this when n1 != n2
                //if( n1 != n2 )
                //{
                //    listPathNodes.push_back( nodeNew );
                //}
            }
            // pop up the last item MRCA
            //listPathNodes.pop_back();

        }
    }


    // this is the set of edges that could be cut
    set<int> edgesCutCandidates;

//#if 0
    // now try all possible triples of leaves i,j,k
    for( int i= 0; i< tree1.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1.GetNumLeaves(); ++j)
        {
            for(int k=j+1; k< tree1.GetNumLeaves(); ++k)
            {
                // is these have different triples on T1 and T2?
                // we do this by getting MRCA for all pairs of MRCAs
                int mrcaij1 = tree1.GetMRCA( i, j );
                int mrcajk1 = tree1.GetMRCA( j, k );
                int mrcaik1 = tree1.GetMRCA( i, k );
                int mrcaij2 = tree2.GetMRCA( i, j );
                int mrcajk2 = tree2.GetMRCA( j, k );
                int mrcaik2 = tree2.GetMRCA( i, k );

                bool fIncTriple = false;

                // now just test exhustively
                if( mrcaij1 == mrcajk1 )
                {
                    if( mrcaij2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }
                else if( mrcaij1 == mrcaik1 )
                {
                    if( mrcaij2 != mrcaik2  )
                    {
                        fIncTriple = true;
                    }
                }
                else 
                {
                    if( mrcaik2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }

                if(fIncTriple == false)
                {
                    // we are only interested in incompatible triple
                    continue;
                }

                // now require M for this triple
//                OutputMkij( outFile, 1, i, j );
//                outFile << " + ";
//                OutputMkij( outFile, 1, i, k );
//                outFile << " + ";
//                OutputMkij( outFile, 1, j, k );
//                outFile << " <= 1\n ";

                // YW: now I believe only one of the following (say (i,j) and (j,k) are needed
                OutputMkij( outFile, 1, i, j );
                outFile << " + ";
                OutputMkij( outFile, 1, i, k );
                outFile << " <= 1\n";

//                OutputMkij( outFile, 1, i, j );
//                outFile << " + ";
//                OutputMkij( outFile, 1, j, k );
//                outFile << " <= 1\n";

//                OutputMkij( outFile, 1, i, k );
//                outFile << " + ";
//                OutputMkij( outFile, 1, j, k );
//                outFile << " <= 1\n";

                // edges that may be cut are the edges IMMEDIATELY below cut vertex
                edgesCutCandidates.insert( tree1.GetLeftDescendant( mrcaij1 )  );
                edgesCutCandidates.insert( tree1.GetRightDescendant( mrcaij1 )  );
                edgesCutCandidates.insert( tree1.GetLeftDescendant( mrcaik1 )  );
                edgesCutCandidates.insert( tree1.GetRightDescendant( mrcaik1 )  );


            }
        }
    }
//#endif

//#if 0
    // now we test for all pair of leaf pairs, to ensure there is no intersection in two trees
    // if the two pairs are left in one tree
    for( int i= 0; i< tree1.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1.GetNumLeaves(); ++j)
        {
            for(int p=i+1; p< tree1.GetNumLeaves(); ++p)
            {
                // make sure p <>i or j
                if(  p == j )
                {
                    continue;
                }
                for(int q = p+1; q < tree1.GetNumLeaves(); ++q)
                {
                    // make sure q is unique twoo
                    if(  q == j )
                    {
                        continue;
                    }

                    // now we only worry about two disjoint path (i,j) and (p,q)
                    if( tree1.AreTwoPathsDisjoint( i, j, p, q ) == false  )
                    {
                        continue;
                    }
                    // also ignore when tree2 has disjoint (i,j) and (p,q), since they auto satisfy the partition
                    if( tree2.AreTwoPathsDisjoint( i, j, p, q ) == true  )
                    {
                        continue;
                    }

                    // now for this, make sure Mi,j + Mp,q <= 1
                    OutputMkij( outFile, 1, i, j );
                    outFile << " + ";
                    OutputMkij( outFile, 1, p, q );
                    outFile << " <= 1\n";

                    // edges that may be cut are the edges IMMEDIATELY below cut vertex
                    int mrcaij1 = tree1.GetMRCA( i, j );
                    int mrcapq1 = tree1.GetMRCA( p, q );

                    edgesCutCandidates.insert( tree1.GetLeftDescendant( mrcaij1 )  );
                    edgesCutCandidates.insert( tree1.GetRightDescendant( mrcaij1 )  );
                    edgesCutCandidates.insert( tree1.GetLeftDescendant( mrcapq1 )  );
                    edgesCutCandidates.insert( tree1.GetRightDescendant( mrcapq1 )  );


                }
            }
        }
    }
//#endif

    // now enforce additional property here
    // we try to find pair of leaves in tree1Reduced that are sibling and
    // then looks for another tree's same leaves

    // enforce additional property: there is no edge and its immediate parent are cut
    for( int nn = tree1.GetNumLeaves(); nn < tree1.GetTotNodesNum()-1;  ++nn )
    {
        // C,k,pa + c,k,desc1 <=1
        //int pp = pCurrTree1->GetParent( nn );
        int pdesc = tree1.GetLeftDescendant( nn );
        YW_ASSERT_INFO(pdesc >=0, "no descent");
        OutputCki( outFile, 1,  nn  );
        outFile << " + ";
        OutputCki( outFile, 1,  pdesc );
        outFile << " <= 1\n";

        pdesc = tree1.GetRightDescendant( nn );
        YW_ASSERT_INFO(pdesc >=0, "no descent");
        OutputCki( outFile, 1,  nn  );
        outFile << " + ";
        OutputCki( outFile, 1,  pdesc );
        outFile << " <= 1\n";
    }
    // make every edge not in candidate sets to be 0
#if  0
//cout << "Possible edge cuts = ";
//DumpIntSet(edgesCutCandidates);
    for( int i=0; i<tree1.GetTotNodesNum()-1; ++i )
    {
        if( edgesCutCandidates.find( i ) == edgesCutCandidates.end()  )
        {
            OutputCki( outFile, 1, i);
            outFile << " = 0\n";
        }
    }
#endif


    // variables
    outFile << "\nBinary " << endl;

    // Cki
    for( int i = 0; i< tree1.GetTotNodesNum(); ++i )
    {
        OutputCki( outFile, 1, i );
        outFile << endl;
    }
    // mkij
#if 0
    for( int i= 0; i< tree1.GetNumLeaves() ; ++i  )
    {
        for( int j= i+1; j< tree1.GetNumLeaves() ; ++j  )
        {
            OutputMkij( outFile, 1, i, j );
            outFile << endl;
            OutputMkij( outFile, 2, i, j );
            outFile << endl;
        }
    }
#endif

    //for(int k=1; k<=2; ++k)
    {
        // output m,k,i,js
        for( set<pair<int,int> > :: iterator it = listPairNodesConstraint[0].begin(); 
            it != listPairNodesConstraint[0].end(); ++it )
        {
            pair<int,int> pp = *it;
            OutputMkij( outFile, 1, pp.first, pp.second );
            outFile << endl;
        }
    }

    // For now, we do not really compute the bound directly but output a ILP file
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Finally close the file
    outFile << "end" << endl;
    outFile.close();

}


void OutputILPMaxAgreeForestTest2(const char* fileName, const MarginalTree &tree1, const MarginalTree &tree2 )
{
    YW_ASSERT_INFO( tree1.GetTotNodesNum() == tree2.GetTotNodesNum(), "mismatch" );

//cout << "OutputILPMaxAgreeForest: tree1 = ";
//tree1.Dump();
//cout << "OutputILPMaxAgreeForest: tree2 = ";
//tree2.Dump();
//tree1.OutputGML( "tree1.gml" );
//tree2.OutputGML( "tree2.gml" );
    // first compute constants that are useful


    // This function outputs the ILP file
    // The folowing ILP is to minimize an approximate compsoite hapbound when case control is added
    // We approximate hapbound since we want to extend the applicability to larger range of data
	ofstream outFile(  fileName  );
	if(outFile.is_open() == false)
	{
		cout << "Can not open ILP output file: "<< fileName <<  endl; 
		return ; 
	}



    // Now we start to output ILP formulation
    // First is the objective
    // Note that we still only consider lower bounds BEFORE adding case/control
    outFile << "Minimize  \n";

    // finally the edge mutations
    for( int i = 0; i< tree1.GetTotNodesNum()-1; ++i )
    {
        OutputCki(outFile, 1, i);
        if( i < tree1.GetTotNodesNum()-2 )
        {
            outFile << "\n+ ";
        }


    }

    outFile << endl;

    // constraints
    outFile << endl;
    outFile << "subject to " << endl;
    outFile << endl;




    // now enforce m,i
    OutputCki( outFile, 1,  tree1.GetTotNodesNum()-1 );
    outFile << " = 0 \n";
//    OutputCki( outFile, 2 , tree2.GetTotNodesNum()-1 );
//    outFile << " = 0 \n";

    // keep two trees
    const MarginalTree *ptrTrees[2];
    ptrTrees[0] = &tree1;
    ptrTrees[1] = &tree2;

    // now store which pairs of nodes we need to output for constraints
    // WARNING: we assume the first node is always smaller than (or equal) the second node
//    set< pair<int,int> > listPairNodesConstraint[2];


//#if 0
    // now try all possible triples of leaves i,j,k
    for( int i= 0; i< tree1.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1.GetNumLeaves(); ++j)
        {
            for(int k=j+1; k< tree1.GetNumLeaves(); ++k)
            {
                // is these have different triples on T1 and T2?
                // we do this by getting MRCA for all pairs of MRCAs
                int mrcaij1 = tree1.GetMRCA( i, j );
                int mrcajk1 = tree1.GetMRCA( j, k );
                int mrcaik1 = tree1.GetMRCA( i, k );
                int mrcaij2 = tree2.GetMRCA( i, j );
                int mrcajk2 = tree2.GetMRCA( j, k );
                int mrcaik2 = tree2.GetMRCA( i, k );

                bool fIncTriple = false;

                // now just test exhustively
                if( mrcaij1 == mrcajk1 )
                {
                    if( mrcaij2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }
                else if( mrcaij1 == mrcaik1 )
                {
                    if( mrcaij2 != mrcaik2  )
                    {
                        fIncTriple = true;
                    }
                }
                else 
                {
                    if( mrcaik2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }

                if(fIncTriple == false)
                {
                    // we are only interested in incompatible triple
                    continue;
                }

                // now require M for this triple
//                OutputMkij( outFile, 1, i, j );
//                outFile << " + ";
//                OutputMkij( outFile, 1, i, k );
//                outFile << " + ";
//                OutputMkij( outFile, 1, j, k );
//                outFile << " <= 1\n ";


//#if 0
                // we find the edges on the path
                set<int> triPathEdges;
                set<int> listEdgesij;
                tree1.GetPath( i,j, listEdgesij );
                triPathEdges = listEdgesij;
                set<int> listEdgesjk;
                tree1.GetPath( j,k, listEdgesjk );
                UnionSets( triPathEdges, listEdgesjk );
                set<int> listEdgesik;
                tree1.GetPath( i,k, listEdgesik );
                UnionSets( triPathEdges, listEdgesik );


                // ensure at least one edge is cut on tri-path
                YW_ASSERT_INFO(triPathEdges.size() > 0, "Can not be empty");
                set<int> :: iterator it = triPathEdges.begin();
                OutputCki( outFile, 1,  *it );
                ++it;
                for( ; it != triPathEdges.end(); ++it  )
                {
                    outFile << " + \n";
                    OutputCki( outFile, 1,  *it );
                }
                outFile << " >= 1 \n";
//#endif

#if 0
                // we find the edges on the path
//                set<int> triPathEdges;
                set<int> listEdgesij;
                tree1.GetPath( i,j, listEdgesij );
 //               triPathEdges = listEdgesij;
                set<int> listEdgesjk;
                tree1.GetPath( j,k, listEdgesjk );
                set<int> setInt;
                JoinSets(listEdgesij, listEdgesjk, setInt);
                SubtractSets(listEdgesij, setInt);
                SubtractSets(listEdgesjk, setInt);

                // ensure at least one edge is cut on tri-path
                YW_ASSERT_INFO(listEdgesij.size() > 0, "Can not be empty");
                set<int> :: iterator it = listEdgesij.begin();
                OutputCki( outFile, 1,  *it );
                ++it;
                for( ; it != listEdgesij.end(); ++it  )
                {
                    outFile << " + \n";
                    OutputCki( outFile, 1,  *it );
                }
                outFile << " + \n";
                //outFile << " >= 1 \n";


                YW_ASSERT_INFO(setInt.size() > 0, "Can not be empty");
                it = setInt.begin();
                OutputCki( outFile, 1,  *it );
                ++it;
                for( ; it != setInt.end(); ++it  )
                {
                    outFile << " + \n";
                    outFile << "2    ";
                    OutputCki( outFile, 1,  *it );
                }
                outFile << " + \n";
                //outFile << " >= 1 \n";

                //UnionSets( triPathEdges, listEdgesjk );
                //set<int> listEdgesik;
                //tree1.GetPath( i,k, listEdgesik );
                //UnionSets( triPathEdges, listEdgesik );
                //triPathEdges = listEdgesjk;
                // ensure at least one edge is cut on tri-path
                YW_ASSERT_INFO(listEdgesjk.size() > 0, "Can not be empty");
                it = listEdgesjk.begin();
                OutputCki( outFile, 1,  *it );
                ++it;
                for( ; it != listEdgesjk.end(); ++it  )
                {
                    outFile << " + \n";
                    OutputCki( outFile, 1,  *it );
                }
                outFile << " >= 1 \n";
#endif



            }
        }
    }
//#endif


    // now we test for all pair of leaf pairs, to ensure there is no intersection in two trees
    // if the two pairs are left in one tree
    for( int i= 0; i< tree1.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1.GetNumLeaves(); ++j)
        {
            for(int p=i+1; p< tree1.GetNumLeaves(); ++p)
            {
                // make sure p <>i or j
                if(  p == j )
                {
                    continue;
                }
                for(int q = p+1; q < tree1.GetNumLeaves(); ++q)
                {
                    // make sure q is unique twoo
                    if(  q == j )
                    {
                        continue;
                    }

                    // now we only worry about two disjoint path (i,j) and (p,q)
                    if( tree1.AreTwoPathsDisjoint( i, j, p, q ) == false  )
                    {
                        continue;
                    }
                    // also ignore when tree2 has disjoint (i,j) and (p,q), since they auto satisfy the partition
                    if( tree2.AreTwoPathsDisjoint( i, j, p, q ) == true  )
                    {
                        continue;
                    }

                    // now for this, make sure Mi,j + Mp,q <= 1
//                    OutputMkij( outFile, 1, i, j );
//                    outFile << " + ";
//                    OutputMkij( outFile, 1, p, q );
//                    outFile << " <= 1\n";

                    // rertreive the path here
                    set<int> twinPathEdges;
                    set<int> listEdgesij;
                    tree1.GetPath( i,j, listEdgesij );
                    twinPathEdges = listEdgesij;
                    set<int> listEdgespq;
                    tree1.GetPath( p,q, listEdgespq );
                    UnionSets( twinPathEdges, listEdgespq );


                    YW_ASSERT_INFO(twinPathEdges.size() > 0, "Can not be empty");
                    set<int> :: iterator it = twinPathEdges.begin();
                    OutputCki( outFile, 1,  *it );
                    ++it;
                    for( ; it != twinPathEdges.end(); ++it  )
                    {
                        outFile << " + \n";
                        OutputCki( outFile, 1,  *it );
                    }
                    outFile << " >= 1 \n";


                }
            }
        }
    }

    // variables
    outFile << "\nBinary " << endl;

    // Cki
    for( int i = 0; i< tree1.GetTotNodesNum(); ++i )
    {
        OutputCki( outFile, 1, i );
        outFile << endl;
    }


    // For now, we do not really compute the bound directly but output a ILP file
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Finally close the file
    outFile << "end" << endl;
    outFile.close();

}



void OutputILPMaxGoodAgreeForest(const char* fileName, const MarginalTree &treeOrig1, const MarginalTree &treeOrig2 )
{
    YW_ASSERT_INFO( treeOrig1.GetTotNodesNum() == treeOrig2.GetTotNodesNum(), "mismatch" );

cout << "OutputILPMaxGoodAgreeForest: treeOrig1 = ";
treeOrig1.Dump();
cout << "OutputILPMaxGoodAgreeForest: tree2 = ";
treeOrig2.Dump();
    // first compute constants that are useful
#if 0
MarginalTree treetest1, treetest2;
treetest1.numLeaves = 5;
treetest1.listNodeLabels.push_back(1);
treetest1.listNodeLabels.push_back(2);
treetest1.listNodeLabels.push_back(3);
treetest1.listNodeLabels.push_back(4);
treetest1.listNodeLabels.push_back(5);
treetest1.listNodeLabels.push_back(6);
treetest1.listNodeLabels.push_back(7);
treetest1.listNodeLabels.push_back(8);
treetest1.listNodeLabels.push_back(9);
treetest1.listParentNodePos.push_back(5);
treetest1.listParentNodePos.push_back(5);
treetest1.listParentNodePos.push_back(6);
treetest1.listParentNodePos.push_back(6);
treetest1.listParentNodePos.push_back(7);
treetest1.listParentNodePos.push_back(7);
treetest1.listParentNodePos.push_back(8);
treetest1.listParentNodePos.push_back(8);
treetest1.listParentNodePos.push_back(-1);

treetest2.numLeaves = 5;
treetest2.listNodeLabels.push_back(1);
treetest2.listNodeLabels.push_back(2);
treetest2.listNodeLabels.push_back(3);
treetest2.listNodeLabels.push_back(4);
treetest2.listNodeLabels.push_back(5);
treetest2.listNodeLabels.push_back(6);
treetest2.listNodeLabels.push_back(7);
treetest2.listNodeLabels.push_back(8);
treetest2.listNodeLabels.push_back(9);
treetest2.listParentNodePos.push_back(6);
treetest2.listParentNodePos.push_back(6);
treetest2.listParentNodePos.push_back(5);
treetest2.listParentNodePos.push_back(7);
treetest2.listParentNodePos.push_back(5);
treetest2.listParentNodePos.push_back(8);
treetest2.listParentNodePos.push_back(7);
treetest2.listParentNodePos.push_back(8);
treetest2.listParentNodePos.push_back(-1);
MarginalTree tree1ReducedTest, tree2ReducedTest;
ReducePairTreesMAF(treetest1, treetest2, tree1ReducedTest, tree2ReducedTest);
exit(1);
#endif
    MarginalTree  tree1Reduced = treeOrig1;
    MarginalTree  tree2Reduced = treeOrig2;


    // buildup the descendent info
    tree1Reduced.BuildDescendantInfo();
    tree2Reduced.BuildDescendantInfo();

//    ReducePairTreesMAF(treeOrig1, treeOrig2, tree1Reduced, tree2Reduced);


    // This function outputs the ILP file
    // The folowing ILP is to minimize an approximate compsoite hapbound when case control is added
    // We approximate hapbound since we want to extend the applicability to larger range of data
	ofstream outFile(  fileName  );
	if(outFile.is_open() == false)
	{
		cout << "Can not open ILP output file: "<< fileName <<  endl; 
		return ; 
	}



    // Now we start to output ILP formulation
    // First is the objective
    // Note that we still only consider lower bounds BEFORE adding case/control
    outFile << "Minimize  \n";

    // finally the edge mutations
    for( int i = 0; i< tree1Reduced.GetTotNodesNum()-1; ++i )
    {
        OutputCki(outFile, 1, i);
        if( i < tree1Reduced.GetTotNodesNum()-2 )
        {
            outFile << "\n+ ";
        }

        //OutputCki(outFile, 2, i);
        //if( i < tree1Reduced.GetTotNodesNum()-2 )
        //{
        //    outFile << "\n+ ";
        //}

    }

    outFile << endl;

    // constraints
    outFile << endl;
    outFile << "subject to " << endl;
    outFile << endl;




    // now enforce m,i
    OutputCki( outFile, 1,  tree1Reduced.GetTotNodesNum()-1 );
    outFile << " = 0 \n";
    OutputCki( outFile, 2 , tree2Reduced.GetTotNodesNum()-1 );
    outFile << " = 0 \n";


    const MarginalTree *ptrTrees[2];
    ptrTrees[0] = &tree1Reduced;
    ptrTrees[1] = &tree2Reduced;

    // start from the first tree
    for(  int k=1; k<=2; ++k  )
    {
        const MarginalTree *pCurrTree = ptrTrees[k-1];

        for( int i= 0; i< pCurrTree->GetNumLeaves() ; ++i  )
        {
            for(int j=i+1; j< pCurrTree->GetNumLeaves(); ++j)
            {
                // first we need to find MRCA of i,j. 
                // note that we actually want to exluce MRCA, but include i,j!
                set<int> listPathNodes;
                int n1=i, n2 = j;
                listPathNodes.insert(i);
                listPathNodes.insert(j);
                while( n1 != n2 )
                {
                    // we alternatively move up, depend on which one is smaller
                    int nodeNew;
                    if( n1 < n2  )
                    {
                        // move n1
                        n1 = pCurrTree->GetParent(n1);
                        nodeNew = n1;
                    }
                    else
                    {
                        // move n2
                        n2 = pCurrTree->GetParent(n2);
                        nodeNew = n2;
                    }
                    // save this when n1 != n2
                    if( n1 != n2 )
                    {
                        listPathNodes.insert( nodeNew );
                    }
                }
                // pop up the last item MRCA
                //listPathNodes.pop_back();
                listPathNodes.erase(  n1  );
                



                // now we start to enforce property
                OutputMkij( outFile, 1, i, j );
                for( set<int> :: iterator it = listPathNodes.begin(); it != listPathNodes.end(); ++it )
                {
                    outFile << " + ";
                    OutputCki( outFile, k, *it );
                    outFile << endl;
                }
                outFile << " >= 1\n";

                /*  do we need the following? yes */
                for( set<int> :: iterator it = listPathNodes.begin(); it != listPathNodes.end(); ++it )
                {
                    OutputMkij( outFile, 1, i, j );
                    outFile << " + ";
                    OutputCki( outFile, k, *it );
                    outFile << " <= 1\n";
                }


            }
        }
    }


    // now make sure Mi,j,k equal
#if 0
    for( int i= 0; i< tree1Reduced.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1Reduced.GetNumLeaves(); ++j)
        {
            OutputMkij( outFile, 1, i, j );
            outFile << " - ";
            OutputMkij( outFile, 2, i, j );
            outFile << " = 0\n";
        }
    }
#endif

    // now try all possible triples of leaves i,j,k
    for( int i= 0; i< tree1Reduced.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1Reduced.GetNumLeaves(); ++j)
        {
            for(int k=j+1; k< tree1Reduced.GetNumLeaves(); ++k)
            {
                // is these have different triples on T1 and T2?
                // we do this by getting MRCA for all pairs of MRCAs
                int mrcaij1 = tree1Reduced.GetMRCA( i, j );
                int mrcajk1 = tree1Reduced.GetMRCA( j, k );
                int mrcaik1 = tree1Reduced.GetMRCA( i, k );
                int mrcaij2 = tree2Reduced.GetMRCA( i, j );
                int mrcajk2 = tree2Reduced.GetMRCA( j, k );
                int mrcaik2 = tree2Reduced.GetMRCA( i, k );

                bool fIncTriple = false;

                // now just test exhustively
                if( mrcaij1 == mrcajk1 )
                {
                    if( mrcaij2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }
                else if( mrcaij1 == mrcaik1 )
                {
                    if( mrcaij2 != mrcaik2  )
                    {
                        fIncTriple = true;
                    }
                }
                else 
                {
                    if( mrcaik2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }

                if(fIncTriple == false)
                {
                    // we are only interested in incompatible triple
                    continue;
                }

                // now require M for this triple
//                OutputMkij( outFile, 1, i, j );
//                outFile << " + ";
//                OutputMkij( outFile, 1, i, k );
//                outFile << " + ";
//                OutputMkij( outFile, 1, j, k );
//                outFile << " <= 1\n ";

//#if 0
                OutputMkij( outFile, 1, i, j );
                outFile << " + ";
                OutputMkij( outFile, 1, i, k );
                outFile << " <= 1\n ";

                OutputMkij( outFile, 1, i, j );
                outFile << " + ";
                OutputMkij( outFile, 1, j, k );
                outFile << " <= 1\n ";

                OutputMkij( outFile, 1, i, k );
                outFile << " + ";
                OutputMkij( outFile, 1, j, k );
                outFile << " <= 1\n ";
//#endif


            }
        }
    }

    // the following constraints are not really needed
    // but we hope they can speedup things
    // we enforce this: if M,i,j = M,j,k = 1, then Mi,k = 1
#if 0
    for( int i= 0; i< tree1Reduced.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1Reduced.GetNumLeaves(); ++j)
        {
            for(int k=j+1; k< tree1Reduced.GetNumLeaves(); ++k)
            {
                OutputMkij( outFile, 1, i, j );
                outFile << " + ";
                OutputMkij( outFile, 1, i, k );
                outFile << " - ";
                OutputMkij( outFile, 1, j, k );
                outFile << " <= 1\n ";

                OutputMkij( outFile, 1, i, j );
                outFile << " + ";
                OutputMkij( outFile, 1, j, k );
                outFile << " - ";
                OutputMkij( outFile, 1, i, k );
                outFile << " <= 1\n ";

                OutputMkij( outFile, 1, i, k );
                outFile << " + ";
                OutputMkij( outFile, 1, j, k );
                outFile << " - ";
                OutputMkij( outFile, 1, i, j );
                outFile << " <= 1\n ";

            }
        }
    }
#endif


//#if  0
    // now enforce additional property here
    // we try to find pair of leaves in tree1Reduced that are sibling and
    // then looks for another tree's same leaves
    for(int k=1; k<=2; ++k)
    {
        const MarginalTree *pCurrTree1; 
        const MarginalTree *pCurrTree2; 
        const MarginalTree *pCurrTree;
        int k1, k2;
        if( k == 1 )
        {
            k1 = 1;
            k2 = 2;
            pCurrTree1 = &tree1Reduced;
            pCurrTree2 = &tree2Reduced;
            pCurrTree = pCurrTree1;
        }
        else
        {
            k1 = 2;
            k2 = 1;
            pCurrTree1 = &tree2Reduced;
            pCurrTree2 = &tree1Reduced;
            pCurrTree = pCurrTree2;
        }
        // enforce additional property: there is no edge and its immediate parent are cut
        for( int nn = pCurrTree1->GetNumLeaves(); nn < pCurrTree1->GetTotNodesNum()-1;  ++nn )
        {
            // C,k,pa + c,k,desc1 <=1
            //int pp = pCurrTree1->GetParent( nn );
            int pdesc = pCurrTree1->GetLeftDescendant( nn );
            YW_ASSERT_INFO(pdesc >=0, "no descent");
            OutputCki( outFile, k1,  nn  );
            outFile << " + ";
            OutputCki( outFile, k1,  pdesc );
            outFile << " <= 1\n";

            pdesc = pCurrTree1->GetRightDescendant( nn );
            YW_ASSERT_INFO(pdesc >=0, "no descent");
            OutputCki( outFile, k1,  nn  );
            outFile << " + ";
            OutputCki( outFile, k1,  pdesc );
            outFile << " <= 1\n";
        }

    }
//#endif


    // now for acyclic property for hybridization property


    // now enforce G,i,j
    for( int i= 0; i< ptrTrees[0]->GetNumLeaves() ; ++i  )
    {
        for( int j= i+1; j< ptrTrees[0]->GetNumLeaves() ; ++j  )
        {
            // now try both trees
            for(  int k=1; k<=2; ++k  )
            {
                const MarginalTree *pCurrTree = ptrTrees[k-1];

                // get paths from i and j to root
                //set<int> rootEdgePathi, rootEdgePathj;
                //pCurrTree->GetPath( i, pCurrTree->GetTotNodesNum()-1, rootEdgePathi );
                //pCurrTree->GetPath( j, pCurrTree->GetTotNodesNum()-1, rootEdgePathj );
                //rootEdgePathi.insert(pCurrTree->GetTotNodesNum()-1);
                //rootEdgePathj.insert(pCurrTree->GetTotNodesNum()-1);

                int rmrca = pCurrTree->GetMRCA( i, j );
                // now get path from i to rmrca
                set<int> listEdgesi;
                pCurrTree->GetPath(i, rmrca, listEdgesi );
                listEdgesi.erase( rmrca );
                set<int> listEdgesj;
                pCurrTree->GetPath(j, rmrca, listEdgesj );
                listEdgesj.erase( rmrca );
                YW_ASSERT_INFO( listEdgesi.size() > 0 && listEdgesj.size() >0, "Fail" );

                // now we try both directions, first assume j's root is i's root
                outFile << listEdgesj.size() << "   ";
                OutputGij( outFile, i, j );

                for( set<int> :: iterator it = listEdgesi.begin();  it != listEdgesi.end(); ++it )
                {
                    outFile << " + ";
                    outFile << listEdgesj.size() << "   ";
                    OutputCki( outFile, k,  *it  );
                    outFile << endl;
                }
                
                for( set<int> :: iterator it = listEdgesj.begin();  it != listEdgesj.end(); ++it )
                {
                    outFile << " - ";
                    OutputCki( outFile, k,  *it  );
                    outFile << endl;
                }
                outFile << " >= 0\n";
                


                // now we try both directions, first assume j's root is i's root
                outFile << "-" << listEdgesi.size() << "  ";
                OutputGij( outFile, i, j );

                for( set<int> :: iterator it = listEdgesj.begin();  it != listEdgesj.end(); ++it )
                {
                    outFile << " + ";
                    outFile << listEdgesi.size() << "   ";
                    OutputCki( outFile, k,  *it  );
                    outFile << endl;
                }
                
                for( set<int> :: iterator it = listEdgesi.begin();  it != listEdgesi.end(); ++it )
                {
                    outFile << " - ";
                    OutputCki( outFile, k,  *it  );
                    outFile << endl;
                }
                outFile << " >=   -" <<  listEdgesi.size()  << "\n";
                

            }
        }
    }


    // now try all triples of leaves
    for( int i= 0; i< tree1Reduced.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1Reduced.GetNumLeaves(); ++j)
        {
            //if( j == i )
            //{
            //    continue;
            //}
            for(int k=j+1; k< tree1Reduced.GetNumLeaves(); ++k)
            {
                //if( k == i || k == j )
                //{
                //    continue;
                //}
                // ij=1, jk = 1 => ik = 1
                OutputGij( outFile, i, k );
                outFile << " - ";
                OutputGij( outFile, i, j );
                outFile << " - ";
                OutputGij( outFile, j, k );
                outFile << " >= -1 \n";

                // ij=1 and ik = 0 => jk = 0
                OutputGij( outFile, i, k );
                outFile << " - ";
                OutputGij( outFile, i, j );
                outFile << " - ";
                OutputGij( outFile, j, k );
                outFile << " >= -1 \n";


                // ij=0, jk= 0 => ik = 0
                OutputGij( outFile, i, k );
                outFile << " - ";
                OutputGij( outFile, i, j );
                outFile << " - ";
                OutputGij( outFile, j, k );
                outFile << " <= 0 \n";

                // ij = 0, ik= 1, => jk = 1
                OutputGij( outFile, j, k );
                outFile << " + ";
                OutputGij( outFile, i, j );
                outFile << " - ";
                OutputGij( outFile, i, k );
                outFile << " >= 0 \n";


                // jk = 1, ik= 0  => ij = 0
                OutputGij( outFile, i, k );
                outFile << " - ";
                OutputGij( outFile, i, j );
                outFile << " - ";
                OutputGij( outFile, j, k );
                outFile << " >= -1 \n";

                // jk = 0, ik = 1, => ij = 1
                OutputGij( outFile, i, j );
                outFile << " + ";
                OutputGij( outFile, j, k );
                outFile << " - ";
                OutputGij( outFile, i, k );
                outFile << " >= 0 \n";


            }
        }
    }


    // variables
    outFile << "\nBinary " << endl;

    // Cki
    for( int i = 0; i< tree1Reduced.GetTotNodesNum(); ++i )
    {
        OutputCki( outFile, 1, i );
        outFile << endl;
        OutputCki( outFile, 2, i );
        outFile << endl;
    }
    // mkij
    for( int i= 0; i< tree1Reduced.GetNumLeaves() ; ++i  )
    {
        for( int j= i+1; j< tree1Reduced.GetNumLeaves() ; ++j  )
        {
            OutputMkij( outFile, 1, i, j );
            outFile << endl;
//            OutputMkij( outFile, 2, i, j );
//            outFile << endl;
        }
    }
    // G,i,j
    for( int i= 0; i< tree1Reduced.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1Reduced.GetNumLeaves(); ++j)
        {
            OutputGij( outFile, i, j );
            outFile  << endl;
        }
    }




    // For now, we do not really compute the bound directly but output a ILP file
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Finally close the file
    outFile << "end" << endl;
    outFile.close();

}

void OutputILPMaxGoodAgreeForestTest(const char* fileName, const MarginalTree &tree1, const MarginalTree &tree2 )
{
    YW_ASSERT_INFO( tree1.GetTotNodesNum() == tree2.GetTotNodesNum(), "mismatch" );

//cout << "OutputILPMaxGoodAgreeForestTest: tree1 = ";
//tree1.Dump();
//cout << "OutputILPMaxGoodAgreeForestTest: tree2 = ";
//tree2.Dump();
//tree1.OutputGML( "tree1.gml" );
//tree2.OutputGML( "tree2.gml" );
    // first compute constants that are useful


    // This function outputs the ILP file
    // The folowing ILP is to minimize an approximate compsoite hapbound when case control is added
    // We approximate hapbound since we want to extend the applicability to larger range of data
	ofstream outFile(  fileName  );
	if(outFile.is_open() == false)
	{
		cout << "Can not open ILP output file: "<< fileName <<  endl; 
		return ; 
	}



    // Now we start to output ILP formulation
    // First is the objective
    // Note that we still only consider lower bounds BEFORE adding case/control
    outFile << "Minimize  \n";

    // finally the edge mutations
    for( int i = 0; i< tree1.GetTotNodesNum()-1; ++i )
    {
        OutputCki(outFile, 1, i);
        if( i < tree1.GetTotNodesNum()-2 )
        {
            outFile << "\n+ ";
        }


    }

    outFile << endl;

    // constraints
    outFile << endl;
    outFile << "subject to " << endl;
    outFile << endl;


    // Lower bound known?
    if( minCutLB > 0 )
    {
        for( int i = 0; i< tree1.GetTotNodesNum()-1; ++i )
        {
            OutputCki(outFile, 1, i);
            if( i < tree1.GetTotNodesNum()-2 )
            {
                outFile << "\n+ ";
            }
        }
        outFile << ">= "  << minCutLB  <<  endl;

    }


    // now enforce m,i
    OutputCki( outFile, 1,  tree1.GetTotNodesNum()-1 );
    outFile << " = 0 \n";
    OutputCki( outFile, 2 , tree2.GetTotNodesNum()-1 );
    outFile << " = 0 \n";

    // keep two trees
    const MarginalTree *ptrTrees[2];

    // make sure descendent is built
//    MarginalTree tree1 = tree1;
//    MarginalTree tree2Use = tree2;
//    tree1Use.BuildDescendantInfo();
//    tree2Use.BuildDescendantInfo();

    //
    ptrTrees[0] = &tree1;
    ptrTrees[1] = &tree2;

    // now store which pairs of nodes we need to output for constraints
    // WARNING: we assume the first node is always smaller than (or equal) the second node
    set< pair<int,int> > listPairNodesConstraint[2];

    // start from the first tree
    const MarginalTree *pCurrTree = ptrTrees[0];

    for( int i= 0; i< pCurrTree->GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< pCurrTree->GetNumLeaves(); ++j)
        {
            // first we need to find MRCA of i,j. 
            // note that we actually want to exluce MRCA, but include i,j!
            //vector<int> listPathNodes;
            int n1=i, n2 = j;
            //listPathNodes.push_back(i);
            //listPathNodes.push_back(j);
            while( n1 <= n2 )
            {
                // IMPORTANT: make sure n1 <= n2 (true upon entry)

                // enforce an property
                pair<int,int> pp(n1, n2);
                if( listPairNodesConstraint[0].find(pp) != listPairNodesConstraint[0].end()   )
                {
                    // we already reach what we need, stop
                    break;
                }
                listPairNodesConstraint[0].insert(pp);

                if( n1 == n2 )
                {
                    // for the last one, simply set to be 1 as always
                    OutputMkij( outFile, 1, n1, n1 );
                    outFile << " = 1\n";
                    break;
                }
                else
                {
                    // we alternatively move up, depend on which one is smaller
                    int nodeNew;
                    bool fMoven1 = true;
                    if( n1 < n2  )
                    {
                        // move n1
                        nodeNew = pCurrTree->GetParent(n1);
                        fMoven1 = true;
                    }
                    else
                    {
                        // move n2
                        nodeNew = pCurrTree->GetParent(n2);
                        fMoven1 = false;
                    }

                    int n1New, n2New, edgeCuti;
                    if( fMoven1 == true ) 
                    {
                        n1New = nodeNew;
                        n2New = n2;
                        edgeCuti = n1;
                    }
                    else
                    {
                        n1New = n1;
                        n2New = nodeNew;
                        edgeCuti = n2;
                    }
                    if( n1New > n2New )
                    {
                        OrderInt(n1New, n2New);
                    }

                    // here are constraints
                    OutputMkij( outFile, 1, n1, n2 );
                    outFile << " - ";
                    OutputMkij( outFile, 1, n1New, n2New );
                    outFile << " <= 0\n";

                    OutputMkij( outFile, 1, n1, n2 );
                    outFile << " + ";
                    OutputCki( outFile, 1,  edgeCuti);
                    outFile << " - ";
                    OutputMkij( outFile, 1, n1New, n2New );
                    outFile << " >= 0\n";

                    OutputMkij( outFile, 1, n1, n2 );
                    outFile << " + ";
                    OutputCki( outFile, 1,  edgeCuti);
                    outFile << " <= 1\n";

                     // now update n1 and n2
                    n1 = n1New;
                    n2 = n2New;
               }


                // save this when n1 != n2
                //if( n1 != n2 )
                //{
                //    listPathNodes.push_back( nodeNew );
                //}
            }
            // pop up the last item MRCA
            //listPathNodes.pop_back();

        }
    }


//#if 0
    // now try all possible triples of leaves i,j,k
    for( int i= 0; i< tree1.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1.GetNumLeaves(); ++j)
        {
            for(int k=j+1; k< tree1.GetNumLeaves(); ++k)
            {
                // is these have different triples on T1 and T2?
                // we do this by getting MRCA for all pairs of MRCAs
                int mrcaij1 = tree1.GetMRCA( i, j );
                int mrcajk1 = tree1.GetMRCA( j, k );
                int mrcaik1 = tree1.GetMRCA( i, k );
                int mrcaij2 = tree2.GetMRCA( i, j );
                int mrcajk2 = tree2.GetMRCA( j, k );
                int mrcaik2 = tree2.GetMRCA( i, k );

                bool fIncTriple = false;

                // now just test exhustively
                if( mrcaij1 == mrcajk1 )
                {
                    if( mrcaij2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }
                else if( mrcaij1 == mrcaik1 )
                {
                    if( mrcaij2 != mrcaik2  )
                    {
                        fIncTriple = true;
                    }
                }
                else 
                {
                    if( mrcaik2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }

                if(fIncTriple == false)
                {
                    // we are only interested in incompatible triple
                    continue;
                }

                // now require M for this triple
//                OutputMkij( outFile, 1, i, j );
//                outFile << " + ";
//                OutputMkij( outFile, 1, i, k );
//                outFile << " + ";
//                OutputMkij( outFile, 1, j, k );
//                outFile << " <= 1\n ";

                // YW: now I believe only one of the following (say (i,j) and (j,k) are needed
                OutputMkij( outFile, 1, i, j );
                outFile << " + ";
                OutputMkij( outFile, 1, i, k );
                outFile << " <= 1\n";

//                OutputMkij( outFile, 1, i, j );
//                outFile << " + ";
//                OutputMkij( outFile, 1, j, k );
//                outFile << " <= 1\n";

//                OutputMkij( outFile, 1, i, k );
//                outFile << " + ";
//                OutputMkij( outFile, 1, j, k );
//                outFile << " <= 1\n";


            }
        }
    }
//#endif

//#if 0
    // now we test for all pair of leaf pairs, to ensure there is no intersection in two trees
    // if the two pairs are left in one tree
    for( int i= 0; i< tree1.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1.GetNumLeaves(); ++j)
        {
            for(int p=i+1; p< tree1.GetNumLeaves(); ++p)
            {
                // make sure p <>i or j
                if(  p == j )
                {
                    continue;
                }
                for(int q = p+1; q < tree1.GetNumLeaves(); ++q)
                {
                    // make sure q is unique twoo
                    if(  q == j )
                    {
                        continue;
                    }

                    // now we only worry about two disjoint path (i,j) and (p,q)
                    if( tree1.AreTwoPathsDisjoint( i, j, p, q ) == false  )
                    {
                        continue;
                    }
                    // also ignore when tree2 has disjoint (i,j) and (p,q), since they auto satisfy the partition
                    if( tree2.AreTwoPathsDisjoint( i, j, p, q ) == true  )
                    {
                        continue;
                    }

                    // now for this, make sure Mi,j + Mp,q <= 1
                    OutputMkij( outFile, 1, i, j );
                    outFile << " + ";
                    OutputMkij( outFile, 1, p, q );
                    outFile << " <= 1\n";

                }
            }
        }
    }
//#endif

    // now enforce additional property here
    // we try to find pair of leaves in tree1Reduced that are sibling and
    // then looks for another tree's same leaves

    // enforce additional property: there is no edge and its immediate parent are cut
    for( int nn = tree1.GetNumLeaves(); nn < tree1.GetTotNodesNum()-1;  ++nn )
    {
        // C,k,pa + c,k,desc1 <=1
        //int pp = pCurrTree1->GetParent( nn );
        int pdesc = tree1.GetLeftDescendant( nn );
        YW_ASSERT_INFO(pdesc >=0, "no descent");
        OutputCki( outFile, 1,  nn  );
        outFile << " + ";
        OutputCki( outFile, 1,  pdesc );
        outFile << " <= 1\n";

        pdesc = tree1.GetRightDescendant( nn );
        YW_ASSERT_INFO(pdesc >=0, "no descent");
        OutputCki( outFile, 1,  nn  );
        outFile << " + ";
        OutputCki( outFile, 1,  pdesc );
        outFile << " <= 1\n";
    }

    // now for acyclic property for hybridization property

#if  0
    // now enforce G,i,j
    for( int i= 0; i< ptrTrees[0]->GetNumLeaves() ; ++i  )
    {
        for( int j= i+1; j< ptrTrees[0]->GetNumLeaves() ; ++j  )
        {
            // now try only one trees
            int k = 1;
//            for(  int k=1; k<=1; ++k  )
            {
                const MarginalTree *pCurrTree = ptrTrees[k-1];

                // get paths from i and j to root
                //set<int> rootEdgePathi, rootEdgePathj;
                //pCurrTree->GetPath( i, pCurrTree->GetTotNodesNum()-1, rootEdgePathi );
                //pCurrTree->GetPath( j, pCurrTree->GetTotNodesNum()-1, rootEdgePathj );
                //rootEdgePathi.insert(pCurrTree->GetTotNodesNum()-1);
                //rootEdgePathj.insert(pCurrTree->GetTotNodesNum()-1);

                int rmrca = pCurrTree->GetMRCA( i, j );
                // now get path from i to rmrca
                set<int> listEdgesi;
                pCurrTree->GetPath(i, rmrca, listEdgesi );
                listEdgesi.erase( rmrca );
                set<int> listEdgesj;
                pCurrTree->GetPath(j, rmrca, listEdgesj );
                listEdgesj.erase( rmrca );
                YW_ASSERT_INFO( listEdgesi.size() > 0 && listEdgesj.size() >0, "Fail" );

                // now we try both directions, first assume j's root is i's root
                outFile << listEdgesj.size() << "   ";
                OutputGij( outFile, i, j );

                for( set<int> :: iterator it = listEdgesi.begin();  it != listEdgesi.end(); ++it )
                {
                    outFile << " + ";
                    outFile << listEdgesj.size() << "   ";
                    OutputCki( outFile, k,  *it  );
                    outFile << endl;
                }
                
                for( set<int> :: iterator it = listEdgesj.begin();  it != listEdgesj.end(); ++it )
                {
                    outFile << " - ";
                    OutputCki( outFile, k,  *it  );
                    outFile << endl;
                }
                outFile << " >= 0\n";
                


                // now we try both directions, first assume j's root is i's root
                outFile << "-" << listEdgesi.size() << "  ";
                OutputGij( outFile, i, j );

                for( set<int> :: iterator it = listEdgesj.begin();  it != listEdgesj.end(); ++it )
                {
                    outFile << " + ";
                    outFile << listEdgesi.size() << "   ";
                    OutputCki( outFile, k,  *it  );
                    outFile << endl;
                }
                
                for( set<int> :: iterator it = listEdgesi.begin();  it != listEdgesi.end(); ++it )
                {
                    outFile << " - ";
                    OutputCki( outFile, k,  *it  );
                    outFile << endl;
                }
                outFile << " >=   -" <<  listEdgesi.size()  << "\n";
                

            }
        }
    }
#endif

    // now try the other tree
    for( int i= 0; i< ptrTrees[0]->GetNumLeaves() ; ++i  )
    {
        for( int j= i+1; j< ptrTrees[0]->GetNumLeaves() ; ++j  )
        {
            // now try only one trees
            //int k = 2;
            for(  int k=1; k<=2; ++k  )
            {
                const MarginalTree *pCurrTree = ptrTrees[k-1];

                int rmrca = pCurrTree->GetMRCA( i, j );

                set<int> subtreei, subtreej, subtreek;
                // the subtreei = leaves under left descendent of rmrca
                //set<int> pathi;
                pCurrTree->GetLeavesUnder( pCurrTree->GetLeftDescendant(rmrca) , subtreei );
                //set<int> pathj;
                pCurrTree->GetLeavesUnder( pCurrTree->GetRightDescendant(rmrca) , subtreej );
                if( subtreei.find(i) == subtreei.end() )
                {
                    YW_ASSERT_INFO( subtreej.find(i) != subtreej.end()  
                        && subtreei.find(j) != subtreei.end(), "false"  );
                    set<int> tmpset = subtreei;
                    subtreei = subtreej;
                    subtreej = tmpset;
                }
                // now also the other part of leaves by taking a complement
                set<int> subtreeij = subtreei;
                UnionSets(subtreeij,  subtreej);
                PopulateSetWithInterval( subtreek, 0, pCurrTree->GetNumLeaves()-1 );
                SubtractSets( subtreek, subtreeij );


                set<int> subtreeTest = subtreek;
                UnionSets( subtreeTest, subtreej );
                int numik = subtreeTest.size()-1;

                if( numik > 0 )
                {
                    outFile << numik << "   ";
                    OutputGij( outFile, i, j );
                    outFile << " + ";
                    outFile << numik << "   ";
                    OutputMkij( outFile, 1, i, j );
                    for( set<int> :: iterator itt = subtreeTest.begin(); itt != subtreeTest.end(); ++itt  )
                    {
                        int ppp = *itt;
                        YW_ASSERT_INFO( ppp != i, "false" );

                        if( ppp == j )
                        {
                            continue;
                        }
                        outFile <<" - ";

                        if(i < ppp)
                        {
                         OutputMkij( outFile, 1, i, ppp );
                        }
                        else
                        {
                         OutputMkij( outFile, 1, ppp, i );
                        }
                        outFile << endl;

                    }
                    outFile << " >= 0\n";;
                }
#if 0
                for( set<int> :: iterator itt = subtreeTest.begin(); itt != subtreeTest.end(); ++itt  )
                {
                    int ppp = *itt;
                    YW_ASSERT_INFO( ppp != i, "false" );

                    if( ppp == j )
                    {
                        continue;
                    }

                    OutputGij( outFile, i, j );
                    outFile << " + ";
                    OutputMkij( outFile, 1, i, j );
                    outFile <<" - ";
                    if(i < ppp)
                    {
                     OutputMkij( outFile, 1, j, ppp );
                    }
                    else
                    {
                     OutputMkij( outFile, 1, ppp, j );
                    }
                    outFile << " >= 0\n";;

                }
#endif

                subtreeTest = subtreek;
                UnionSets( subtreeTest, subtreei );
                int numjk = subtreeTest.size()-1;

                if( numjk > 0 )
                {
                    outFile << numjk << "   ";
                    OutputGij( outFile, i, j );
                    outFile << " - ";
                    outFile << numjk << "   ";
                    OutputMkij( outFile, 1, i, j );
                    for( set<int> :: iterator itt = subtreeTest.begin(); itt != subtreeTest.end(); ++itt  )
                    {
                        int ppp = *itt;
                        YW_ASSERT_INFO( ppp != j, "false" );

                        if( ppp == i )
                        {
                            continue;
                        }
                        outFile <<" + ";

                        if(i < ppp)
                        {
                         OutputMkij( outFile, 1, j, ppp );
                        }
                        else
                        {
                         OutputMkij( outFile, 1, ppp, j );
                        }
                        outFile << endl;

                    }
                    outFile << " <= " <<  numjk <<"\n";
                }

#if 0
                for( set<int> :: iterator itt = subtreeTest.begin(); itt != subtreeTest.end(); ++itt  )
                {
                    int ppp = *itt;
                    YW_ASSERT_INFO( ppp != j, "false" );

                    if( ppp == i )
                    {
                        continue;
                    }

                    OutputGij( outFile, i, j );
                    outFile << " - ";
                    OutputMkij( outFile, 1, i, j );
                    outFile <<" + ";
                    if(j < ppp)
                    {
                     OutputMkij( outFile, 1, j, ppp );
                    }
                    else
                    {
                     OutputMkij( outFile, 1, ppp, j );
                    }
                    outFile << " <= 1\n";;
                }
#endif


            }
        }
    }


    // now try all triples of leaves
    for( int i= 0; i< tree1.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1.GetNumLeaves(); ++j)
        {
            //if( j == i )
            //{
            //    continue;
            //}
            for(int k=j+1; k< tree1.GetNumLeaves(); ++k)
            {
                //if( k == i || k == j )
                //{
                //    continue;
                //}
                // ij=1, jk = 1 => ik = 1
                OutputGij( outFile, i, k );
                outFile << " - ";
                OutputGij( outFile, i, j );
                outFile << " - ";
                OutputGij( outFile, j, k );
                outFile << " >= -1 \n";

                // ij=1 and ik = 0 => jk = 0
                OutputGij( outFile, i, k );
                outFile << " - ";
                OutputGij( outFile, i, j );
                outFile << " - ";
                OutputGij( outFile, j, k );
                outFile << " >= -1 \n";


                // ij=0, jk= 0 => ik = 0
                OutputGij( outFile, i, k );
                outFile << " - ";
                OutputGij( outFile, i, j );
                outFile << " - ";
                OutputGij( outFile, j, k );
                outFile << " <= 0 \n";

                // ij = 0, ik= 1, => jk = 1
                OutputGij( outFile, j, k );
                outFile << " + ";
                OutputGij( outFile, i, j );
                outFile << " - ";
                OutputGij( outFile, i, k );
                outFile << " >= 0 \n";


                // jk = 1, ik= 0  => ij = 0
                OutputGij( outFile, i, k );
                outFile << " - ";
                OutputGij( outFile, i, j );
                outFile << " - ";
                OutputGij( outFile, j, k );
                outFile << " >= -1 \n";

                // jk = 0, ik = 1, => ij = 1
                OutputGij( outFile, i, j );
                outFile << " + ";
                OutputGij( outFile, j, k );
                outFile << " - ";
                OutputGij( outFile, i, k );
                outFile << " >= 0 \n";


            }
        }
    }







    // variables
    outFile << "\nBinary " << endl;

    // Cki
    for( int i = 0; i< tree1.GetTotNodesNum(); ++i )
    {
        OutputCki( outFile, 1, i );
        outFile << endl;
    }


    //for(int k=1; k<=2; ++k)
    {
        // output m,k,i,js
        for( set<pair<int,int> > :: iterator it = listPairNodesConstraint[0].begin(); 
            it != listPairNodesConstraint[0].end(); ++it )
        {
            pair<int,int> pp = *it;
            OutputMkij( outFile, 1, pp.first, pp.second );
            outFile << endl;
        }
    }

    // G,i,j
    for( int i= 0; i< tree1.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1.GetNumLeaves(); ++j)
        {
            OutputGij( outFile, i, j );
            outFile  << endl;
        }
    }



    // For now, we do not really compute the bound directly but output a ILP file
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Finally close the file
    outFile << "end" << endl;
    outFile.close();

}




void OutputILPMaxGoodAgreeForestSave(const char* fileName, const MarginalTree &treeOrig1, const MarginalTree &treeOrig2 )
{
    YW_ASSERT_INFO( treeOrig1.GetTotNodesNum() == treeOrig2.GetTotNodesNum(), "mismatch" );

cout << "OutputILPMaxGoodAgreeForest: treeOrig1 = ";
treeOrig1.Dump();
cout << "OutputILPMaxGoodAgreeForest: tree2 = ";
treeOrig2.Dump();
    // first compute constants that are useful
#if 0
MarginalTree treetest1, treetest2;
treetest1.numLeaves = 5;
treetest1.listNodeLabels.push_back(1);
treetest1.listNodeLabels.push_back(2);
treetest1.listNodeLabels.push_back(3);
treetest1.listNodeLabels.push_back(4);
treetest1.listNodeLabels.push_back(5);
treetest1.listNodeLabels.push_back(6);
treetest1.listNodeLabels.push_back(7);
treetest1.listNodeLabels.push_back(8);
treetest1.listNodeLabels.push_back(9);
treetest1.listParentNodePos.push_back(5);
treetest1.listParentNodePos.push_back(5);
treetest1.listParentNodePos.push_back(6);
treetest1.listParentNodePos.push_back(6);
treetest1.listParentNodePos.push_back(7);
treetest1.listParentNodePos.push_back(7);
treetest1.listParentNodePos.push_back(8);
treetest1.listParentNodePos.push_back(8);
treetest1.listParentNodePos.push_back(-1);

treetest2.numLeaves = 5;
treetest2.listNodeLabels.push_back(1);
treetest2.listNodeLabels.push_back(2);
treetest2.listNodeLabels.push_back(3);
treetest2.listNodeLabels.push_back(4);
treetest2.listNodeLabels.push_back(5);
treetest2.listNodeLabels.push_back(6);
treetest2.listNodeLabels.push_back(7);
treetest2.listNodeLabels.push_back(8);
treetest2.listNodeLabels.push_back(9);
treetest2.listParentNodePos.push_back(6);
treetest2.listParentNodePos.push_back(6);
treetest2.listParentNodePos.push_back(5);
treetest2.listParentNodePos.push_back(7);
treetest2.listParentNodePos.push_back(5);
treetest2.listParentNodePos.push_back(8);
treetest2.listParentNodePos.push_back(7);
treetest2.listParentNodePos.push_back(8);
treetest2.listParentNodePos.push_back(-1);
MarginalTree tree1ReducedTest, tree2ReducedTest;
ReducePairTreesMAF(treetest1, treetest2, tree1ReducedTest, tree2ReducedTest);
exit(1);
#endif
    MarginalTree  tree1Reduced = treeOrig1;
    MarginalTree  tree2Reduced = treeOrig2;


    // buildup the descendent info
    tree1Reduced.BuildDescendantInfo();
    tree2Reduced.BuildDescendantInfo();

//    ReducePairTreesMAF(treeOrig1, treeOrig2, tree1Reduced, tree2Reduced);


    // This function outputs the ILP file
    // The folowing ILP is to minimize an approximate compsoite hapbound when case control is added
    // We approximate hapbound since we want to extend the applicability to larger range of data
	ofstream outFile(  fileName  );
	if(outFile.is_open() == false)
	{
		cout << "Can not open ILP output file: "<< fileName <<  endl; 
		return ; 
	}



    // Now we start to output ILP formulation
    // First is the objective
    // Note that we still only consider lower bounds BEFORE adding case/control
    outFile << "Minimize  \n";

    // finally the edge mutations
    for( int i = 0; i< tree1Reduced.GetTotNodesNum()-1; ++i )
    {
        OutputCki(outFile, 1, i);
        if( i < tree1Reduced.GetTotNodesNum()-2 )
        {
            outFile << "\n+ ";
        }

        //OutputCki(outFile, 2, i);
        //if( i < tree1Reduced.GetTotNodesNum()-2 )
        //{
        //    outFile << "\n+ ";
        //}

    }

    outFile << endl;

    // constraints
    outFile << endl;
    outFile << "subject to " << endl;
    outFile << endl;




    // now enforce m,i
    OutputCki( outFile, 1,  tree1Reduced.GetTotNodesNum()-1 );
    outFile << " = 0 \n";
    OutputCki( outFile, 2 , tree2Reduced.GetTotNodesNum()-1 );
    outFile << " = 0 \n";


    const MarginalTree *ptrTrees[2];
    ptrTrees[0] = &tree1Reduced;
    ptrTrees[1] = &tree2Reduced;

    // start from the first tree
    for(  int k=1; k<=2; ++k  )
    {
        const MarginalTree *pCurrTree = ptrTrees[k-1];

        for( int i= 0; i< pCurrTree->GetNumLeaves() ; ++i  )
        {
            for(int j=i+1; j< pCurrTree->GetNumLeaves(); ++j)
            {
                // first we need to find MRCA of i,j. 
                // note that we actually want to exluce MRCA, but include i,j!
                set<int> listPathNodes;
                int n1=i, n2 = j;
                listPathNodes.insert(i);
                listPathNodes.insert(j);
                while( n1 != n2 )
                {
                    // we alternatively move up, depend on which one is smaller
                    int nodeNew;
                    if( n1 < n2  )
                    {
                        // move n1
                        n1 = pCurrTree->GetParent(n1);
                        nodeNew = n1;
                    }
                    else
                    {
                        // move n2
                        n2 = pCurrTree->GetParent(n2);
                        nodeNew = n2;
                    }
                    // save this when n1 != n2
                    if( n1 != n2 )
                    {
                        listPathNodes.insert( nodeNew );
                    }
                }
                // pop up the last item MRCA
                //listPathNodes.pop_back();
                listPathNodes.erase(  n1  );
                



                // now we start to enforce property
                OutputMkij( outFile, 1, i, j );
                for( set<int> :: iterator it = listPathNodes.begin(); it != listPathNodes.end(); ++it )
                {
                    outFile << " + ";
                    OutputCki( outFile, k, *it );
                    outFile << endl;
                }
                outFile << " >= 1\n";

                /*  do we need the following? yes */
                for( set<int> :: iterator it = listPathNodes.begin(); it != listPathNodes.end(); ++it )
                {
                    OutputMkij( outFile, 1, i, j );
                    outFile << " + ";
                    OutputCki( outFile, k, *it );
                    outFile << " <= 1\n";
                }


            }
        }
    }


    // now make sure Mi,j,k equal
#if 0
    for( int i= 0; i< tree1Reduced.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1Reduced.GetNumLeaves(); ++j)
        {
            OutputMkij( outFile, 1, i, j );
            outFile << " - ";
            OutputMkij( outFile, 2, i, j );
            outFile << " = 0\n";
        }
    }
#endif

    // now try all possible triples of leaves i,j,k
    for( int i= 0; i< tree1Reduced.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1Reduced.GetNumLeaves(); ++j)
        {
            for(int k=j+1; k< tree1Reduced.GetNumLeaves(); ++k)
            {
                // is these have different triples on T1 and T2?
                // we do this by getting MRCA for all pairs of MRCAs
                int mrcaij1 = tree1Reduced.GetMRCA( i, j );
                int mrcajk1 = tree1Reduced.GetMRCA( j, k );
                int mrcaik1 = tree1Reduced.GetMRCA( i, k );
                int mrcaij2 = tree2Reduced.GetMRCA( i, j );
                int mrcajk2 = tree2Reduced.GetMRCA( j, k );
                int mrcaik2 = tree2Reduced.GetMRCA( i, k );

                bool fIncTriple = false;

                // now just test exhustively
                if( mrcaij1 == mrcajk1 )
                {
                    if( mrcaij2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }
                else if( mrcaij1 == mrcaik1 )
                {
                    if( mrcaij2 != mrcaik2  )
                    {
                        fIncTriple = true;
                    }
                }
                else 
                {
                    if( mrcaik2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }

                if(fIncTriple == false)
                {
                    // we are only interested in incompatible triple
                    continue;
                }

                // now require M for this triple
//                OutputMkij( outFile, 1, i, j );
//                outFile << " + ";
//                OutputMkij( outFile, 1, i, k );
//                outFile << " + ";
//                OutputMkij( outFile, 1, j, k );
//                outFile << " <= 1\n ";

//#if 0
                OutputMkij( outFile, 1, i, j );
                outFile << " + ";
                OutputMkij( outFile, 1, i, k );
                outFile << " <= 1\n ";

                OutputMkij( outFile, 1, i, j );
                outFile << " + ";
                OutputMkij( outFile, 1, j, k );
                outFile << " <= 1\n ";

                OutputMkij( outFile, 1, i, k );
                outFile << " + ";
                OutputMkij( outFile, 1, j, k );
                outFile << " <= 1\n ";
//#endif


            }
        }
    }

    // the following constraints are not really needed
    // but we hope they can speedup things
    // we enforce this: if M,i,j = M,j,k = 1, then Mi,k = 1
#if 0
    for( int i= 0; i< tree1Reduced.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1Reduced.GetNumLeaves(); ++j)
        {
            for(int k=j+1; k< tree1Reduced.GetNumLeaves(); ++k)
            {
                OutputMkij( outFile, 1, i, j );
                outFile << " + ";
                OutputMkij( outFile, 1, i, k );
                outFile << " - ";
                OutputMkij( outFile, 1, j, k );
                outFile << " <= 1\n ";

                OutputMkij( outFile, 1, i, j );
                outFile << " + ";
                OutputMkij( outFile, 1, j, k );
                outFile << " - ";
                OutputMkij( outFile, 1, i, k );
                outFile << " <= 1\n ";

                OutputMkij( outFile, 1, i, k );
                outFile << " + ";
                OutputMkij( outFile, 1, j, k );
                outFile << " - ";
                OutputMkij( outFile, 1, i, j );
                outFile << " <= 1\n ";

            }
        }
    }
#endif


//#if  0
    // now enforce additional property here
    // we try to find pair of leaves in tree1Reduced that are sibling and
    // then looks for another tree's same leaves
    for(int k=1; k<=2; ++k)
    {
        const MarginalTree *pCurrTree1; 
        const MarginalTree *pCurrTree2; 
        const MarginalTree *pCurrTree;
        int k1, k2;
        if( k == 1 )
        {
            k1 = 1;
            k2 = 2;
            pCurrTree1 = &tree1Reduced;
            pCurrTree2 = &tree2Reduced;
            pCurrTree = pCurrTree1;
        }
        else
        {
            k1 = 2;
            k2 = 1;
            pCurrTree1 = &tree2Reduced;
            pCurrTree2 = &tree1Reduced;
            pCurrTree = pCurrTree2;
        }
#if 0
        for( int i= 0; i< pCurrTree1->GetNumLeaves() ; ++i  )
        {
            for(int j=i+1; j< pCurrTree1->GetNumLeaves(); ++j)
            {
                // if they do not form siblings, skip
                if( pCurrTree1->GetParent(i) != pCurrTree1->GetParent(j)  )
                {
                    // skip it
                    continue;
                }

                // now what do we do? go to the other tree to see how things are going
                if( pCurrTree2->GetParent(i) == pCurrTree2->GetParent(j)  )
                {
                    // do not cut these tip branches
                    OutputCki( outFile, k1, i );
                    outFile << " = 0" <<  endl;
                    OutputCki( outFile, k1, j );
                    outFile << " = 0" << endl;
                    OutputCki( outFile, k2, i );
                    outFile << " = 0" << endl;
                    OutputCki( outFile, k2, j );
                    outFile << " = 0" << endl;
    cout << "Found one must-match pair of tips: i = " << i << ", j = " << j << endl;
                }
                else
                {
                    int p2i = pCurrTree2->GetParent(i);
                    int p2j = pCurrTree2->GetParent(j);
                    // test whether they are only sepearted by one branch
                    if( p2i == pCurrTree2->GetParent( p2j )    )
                    {
                        set<int> listChildren;
                        pCurrTree2->GetChildren(p2j, listChildren);
                        // remove j
                        listChildren.erase( j );
                        YW_ASSERT_INFO( listChildren.size() == 1, "Non-binary" );

                        // if the other child is a leaf, skip
                        if( pCurrTree2->IsLeaf( *listChildren.begin() ) == true )
                        {
                            continue;
                        }

                        //OutputCki( outFile, k2, *listChildren.begin() );
                        //outFile << " = 1" <<  endl;

                        // YW: changed to reflect the true definition here
                        OutputCki( outFile, k1,  i  );
                        outFile << " = 0" <<  endl;
                        OutputCki( outFile, k1,  j  );
                        outFile << " = 0" <<  endl;

                        OutputCki( outFile, k2,  i  );
                        outFile << " = 0" <<  endl;
                        OutputCki( outFile, k2,  j  );
                        outFile << " = 0" <<  endl;
                        OutputCki( outFile, k2,  p2j  );
                        outFile << " = 0" <<  endl;


    cout << "Found one edge that must be cut: starte = "  << *listChildren.begin() << "\n";
                    }
                    else if( p2j == pCurrTree2->GetParent( p2i ) )
                    {
                        set<int> listChildren;
                        pCurrTree2->GetChildren(p2i, listChildren);
                        // remove j
                        listChildren.erase( i );
                        YW_ASSERT_INFO( listChildren.size() == 1, "Non-binary" );

                        // if the other child is a leaf, skip
                        if( pCurrTree2->IsLeaf( *listChildren.begin() ) == true )
                        {
                            continue;
                        }

                        //OutputCki( outFile, k2, *listChildren.begin() );
                        //outFile << " = 1" << endl;
                        OutputCki( outFile, k1,  i  );
                        outFile << " = 0" <<  endl;
                        OutputCki( outFile, k1,  j  );
                        outFile << " = 0" <<  endl;

                        OutputCki( outFile, k2,  i  );
                        outFile << " = 0" <<  endl;
                        OutputCki( outFile, k2,  j  );
                        outFile << " = 0" <<  endl;
                        OutputCki( outFile, k2,  p2i  );
                        outFile << " = 0" <<  endl;

    cout << "Found one edge that must be cut: starte = "  << *listChildren.begin() << "\n";
                    }
                }
            }
        }
#endif


        // enforce additional property: there is no edge and its immediate parent are cut
        for( int nn = pCurrTree1->GetNumLeaves(); nn < pCurrTree1->GetTotNodesNum()-1;  ++nn )
        {
            // C,k,pa + c,k,desc1 <=1
            //int pp = pCurrTree1->GetParent( nn );
            int pdesc = pCurrTree1->GetLeftDescendant( nn );
            YW_ASSERT_INFO(pdesc >=0, "no descent");
            OutputCki( outFile, k1,  nn  );
            outFile << " + ";
            OutputCki( outFile, k1,  pdesc );
            outFile << " <= 1\n";

            pdesc = pCurrTree1->GetRightDescendant( nn );
            YW_ASSERT_INFO(pdesc >=0, "no descent");
            OutputCki( outFile, k1,  nn  );
            outFile << " + ";
            OutputCki( outFile, k1,  pdesc );
            outFile << " <= 1\n";
        }

    }
//#endif


    // now for acyclic property for hybridization property
    set< pair<int,int>  >  collectionAllLeafAncesters[2];
    for(  int k=1; k<=2; ++k  )
    {
        const MarginalTree *pCurrTree = ptrTrees[k-1];

        for( int i= 0; i< pCurrTree->GetNumLeaves() ; ++i  )
        {
            // now retrieve path from i to root
            set<int> pathEdges;
            pCurrTree->GetPath( i, pCurrTree->GetTotNodesNum()-1, pathEdges);

            set<int> nodesLast;

            for( set<int> :: iterator it = pathEdges.begin(); it != pathEdges.end(); ++it  )
            {
                int t = *it;

                pair<int,int> pp(i, t);
                collectionAllLeafAncesters[k-1].insert( pp );

                // if i == t i.e. node itself as root?
                if( i == t )
                {
                    // is root if C,k,t = 1
                    OutputRkit( outFile, k, i, t );
                    outFile << " - ";
                    OutputCki( outFile, k, t );
                    outFile << " = 0"  <<  endl;

                    YW_ASSERT_INFO( nodesLast.size()  ==  0, "Wrong" );
                }
                else 
                {
                    // this is the grand root, will be 1 if 
                    YW_ASSERT_INFO( nodesLast.size() > 0, "Wrong" );

                    OutputRkit( outFile, k, i, t );
                    outFile << " - ";
                    OutputCki( outFile, k, t );
                    outFile << " <= 0"  <<  endl;

                    OutputRkit( outFile, k, i, t );
                    //outFile << " + ";
                    //OutputRkit( outFile, k, i, nodeLast );
                    for(  set<int> :: iterator itt = nodesLast.begin(); itt != nodesLast.end(); ++itt )
                    {
                       outFile << " + ";
                       OutputRkit( outFile, k, i, *itt );
                       outFile << endl;
                    }
                    outFile << " - ";
                    OutputCki( outFile, k, t );
                    outFile << " >= 0"  <<  endl;

                    OutputRkit( outFile, k, i, t );
                    for(  set<int> :: iterator itt = nodesLast.begin(); itt != nodesLast.end(); ++itt )
                    {
                       outFile << " + ";
                       OutputRkit( outFile, k, i, *itt );
                       outFile << endl;
                    }
                    outFile << " <= " << 1  <<  endl;
                }

                nodesLast.insert(  t );
            }

            // we handle the final root. If 
//cout << "nodesLast = ";
//DumpIntSet( nodesLast );
//cout << "pathEdges = ";
//DumpIntSet( pathEdges );

            YW_ASSERT_INFO( nodesLast == pathEdges, "Wrong" );
            OutputRkit( outFile, k, i, pCurrTree->GetTotNodesNum()-1 );
            //outFile << " + ";
            //OutputRkit( outFile, k, i, nodeLast );
            for(  set<int> :: iterator itt = nodesLast.begin(); itt != nodesLast.end(); ++itt )
            {
               outFile << " + ";
               OutputRkit( outFile, k, i, *itt );
               outFile << endl;
            }
            outFile << " = 1"  <<  endl;

            pair<int,int> pp(i, pCurrTree->GetTotNodesNum()-1 );
            collectionAllLeafAncesters[k-1].insert( pp );

        }
    }

cout << "Here\n";

    // now enforce G,i,j
    for( int i= 0; i< ptrTrees[0]->GetNumLeaves() ; ++i  )
    {
        for( int j= i+1; j< ptrTrees[0]->GetNumLeaves() ; ++j  )
        {
            // now try both trees
            for(  int k=1; k<=2; ++k  )
            {
                const MarginalTree *pCurrTree = ptrTrees[k-1];

                // get paths from i and j to root
                set<int> rootEdgePathi, rootEdgePathj;
                pCurrTree->GetPath( i, pCurrTree->GetTotNodesNum()-1, rootEdgePathi );
                pCurrTree->GetPath( j, pCurrTree->GetTotNodesNum()-1, rootEdgePathj );
                rootEdgePathi.insert(pCurrTree->GetTotNodesNum()-1);
                rootEdgePathj.insert(pCurrTree->GetTotNodesNum()-1);

                // now we try both directions, first assume j's root is i's root
                for( set<int> :: iterator it = rootEdgePathi.begin();  it != rootEdgePathi.end(); ++it )
                {
                    int r1 = *it;

                    // now try upper ancesters from ri
                    set<int> :: iterator it2 = it ;
                    it2 ++;
                    for(  ;  it2 != rootEdgePathi.end(); ++it2  )
                    {
                        int r2 = *it2;
                        if(rootEdgePathj.find(r2)  == rootEdgePathj.end() )
                        {
                            continue;
                        }

                        OutputGij( outFile, i, j );
                        outFile << " - ";
                        OutputRkit( outFile, k, i, r1 );
                        outFile << " - ";
                        OutputRkit( outFile, k, j, r2 );
                        outFile << " >= -1"  <<  endl;



                    }
                }

                // now we try both directions, first assume i's root is j's root
                for( set<int> :: iterator it = rootEdgePathj.begin();  it != rootEdgePathj.end(); ++it )
                {
                    int r1 = *it;

                    // now try upper ancesters from ri
                    set<int> :: iterator it2 = it ;
                    it2 ++;
                    for(  ;  it2 != rootEdgePathj.end(); ++it2  )
                    {
                        int r2 = *it2;
                        if(rootEdgePathi.find(r2)  == rootEdgePathi.end() )
                        {
                            continue;
                        }

                        OutputGij( outFile, i, j );
                        outFile << " + ";
                        OutputRkit( outFile, k, j, r1 );
                        outFile << " + ";
                        OutputRkit( outFile, k, i, r2 );
                        outFile << " <= 2"  <<  endl;


                    }
                }



            }
        }
    }


    // now try all triples of leaves
    for( int i= 0; i< tree1Reduced.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1Reduced.GetNumLeaves(); ++j)
        {
            //if( j == i )
            //{
            //    continue;
            //}
            for(int k=j+1; k< tree1Reduced.GetNumLeaves(); ++k)
            {
                //if( k == i || k == j )
                //{
                //    continue;
                //}
                OutputGij( outFile, i, k );
                outFile << " - ";
                OutputGij( outFile, i, j );
                outFile << " - ";
                OutputGij( outFile, j, k );
                outFile << " >= -1 \n";

                OutputGij( outFile, i, k );
                outFile << " - ";
                OutputGij( outFile, i, j );
                outFile << " - ";
                OutputGij( outFile, j, k );
                outFile << " <= 0 \n";


                // another roation
                OutputGij( outFile, i, j );
                outFile << " - ";
                OutputGij( outFile, i, k );
                outFile << " - ";
                OutputGij( outFile, j, k );
                outFile << " >= -1 \n";

                OutputGij( outFile, i, j );
                outFile << " - ";
                OutputGij( outFile, i, k );
                outFile << " - ";
                OutputGij( outFile, j, k );
                outFile << " <= 0 \n";


                // another roation
                OutputGij( outFile, j, k );
                outFile << " - ";
                OutputGij( outFile, i, j );
                outFile << " - ";
                OutputGij( outFile, i, k );
                outFile << " >= -1 \n";

                OutputGij( outFile, j, k );
                outFile << " - ";
                OutputGij( outFile, i, j );
                outFile << " - ";
                OutputGij( outFile, i, k );
                outFile << " <= 0 \n";


            }
        }
    }


    // variables
    outFile << "\nBinary " << endl;

    // Cki
    for( int i = 0; i< tree1Reduced.GetTotNodesNum(); ++i )
    {
        OutputCki( outFile, 1, i );
        outFile << endl;
        OutputCki( outFile, 2, i );
        outFile << endl;
    }
    // mkij
    for( int i= 0; i< tree1Reduced.GetNumLeaves() ; ++i  )
    {
        for( int j= i+1; j< tree1Reduced.GetNumLeaves() ; ++j  )
        {
            OutputMkij( outFile, 1, i, j );
            outFile << endl;
//            OutputMkij( outFile, 2, i, j );
//            outFile << endl;
        }
    }
    // G,i,j
    for( int i= 0; i< tree1Reduced.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1Reduced.GetNumLeaves(); ++j)
        {
            OutputGij( outFile, i, j );
            outFile  << endl;
        }
    }

    for(  int k=1; k<=2; ++k  )
    {
        for( set< pair<int,int>  > :: iterator it = collectionAllLeafAncesters[k-1].begin(); 
            it != collectionAllLeafAncesters[k-1].end(); ++it )
        {
            OutputRkit( outFile, k, it->first, it->second );
            outFile << endl;
        }
    }


    // For now, we do not really compute the bound directly but output a ILP file
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Finally close the file
    outFile << "end" << endl;
    outFile.close();

}




////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////

// class for compute the distance auto


ILPSolverSPR :: ILPSolverSPR(const MarginalTree &tp1, const MarginalTree &tp2 ) : tree1(tp1), tree2(tp2)
{
}

// Another way is to form sub-string of existing partialsequence
ILPSolverSPR :: ~ILPSolverSPR()
{
}

int ILPSolverSPR :: ComputeILP()
{

    ILPSolver *pILPSolver;
#ifdef LPSOLVER_CPLEX
	pILPSolver = new CPlexILPSolver;
#endif

#ifdef LPSOLVER_GLPK
	pILPSolver = new GLPKILPSolver;
#endif


    // now store which pairs of nodes we need to output for constraints
    // WARNING: we assume the first node is always smaller than (or equal) the second node
    set< pair<int,int> > listPairNodesConstraint;

    // start from the first tree
    const MarginalTree *pCurrTree = &tree1;

    for( int i= 0; i< pCurrTree->GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< pCurrTree->GetNumLeaves(); ++j)
        {
            // first we need to find MRCA of i,j. 
            // note that we actually want to exluce MRCA, but include i,j!
            //vector<int> listPathNodes;
            int n1=i, n2 = j;
            while( n1 <= n2 )
            {
                // IMPORTANT: make sure n1 <= n2 (true upon entry)

                // enforce an property
                pair<int,int> pp(n1, n2);
                if( listPairNodesConstraint.find(pp) != listPairNodesConstraint.end()   )
                {
                    // we already reach what we need, stop
                    break;
                }
                listPairNodesConstraint.insert(pp);

                if( n1 == n2 )
                {
                    // for the last one, simply set to be 1 as always
                    //OutputMkij( outFile, 1, n1, n1 );
                    //outFile << " = 1\n";
                    break;
                }
                else
                {
                    // we alternatively move up, depend on which one is smaller
                    int nodeNew;
                    bool fMoven1 = true;
                    if( n1 < n2  )
                    {
                        // move n1
                        nodeNew = pCurrTree->GetParent(n1);
                        fMoven1 = true;
                    }
                    else
                    {
                        // move n2
                        nodeNew = pCurrTree->GetParent(n2);
                        fMoven1 = false;
                    }

                    int n1New, n2New, edgeCuti;
                    if( fMoven1 == true ) 
                    {
                        n1New = nodeNew;
                        n2New = n2;
                        edgeCuti = n1;
                    }
                    else
                    {
                        n1New = n1;
                        n2New = nodeNew;
                        edgeCuti = n2;
                    }
                    if( n1New > n2New )
                    {
                        OrderInt(n1New, n2New);
                    }

                    // here are constraints
                    //OutputMkij( outFile, 1, n1, n2 );
                    //outFile << " - ";
                    //OutputMkij( outFile, 1, n1New, n2New );
                    //outFile << " <= 0\n";

                    //OutputMkij( outFile, 1, n1, n2 );
                    //outFile << " + ";
                    //OutputCki( outFile, 1,  edgeCuti);
                    //outFile << " - ";
                    //OutputMkij( outFile, 1, n1New, n2New );
                    //outFile << " >= 0\n";

                    //OutputMkij( outFile, 1, n1, n2 );
                    //outFile << " + ";
                    //OutputCki( outFile, 1,  edgeCuti);
                    //outFile << " <= 1\n";

                     // now update n1 and n2
                    n1 = n1New;
                    n2 = n2New;
               }
            }

        }
    }


//#if 0
    // now try all possible triples of leaves i,j,k
    vector<  pair<int, pair<int,int> >  > listTriples;
    for( int i= 0; i< tree1.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1.GetNumLeaves(); ++j)
        {
            for(int k=j+1; k< tree1.GetNumLeaves(); ++k)
            {
                // is these have different triples on T1 and T2?
                // we do this by getting MRCA for all pairs of MRCAs
                int mrcaij1 = tree1.GetMRCA( i, j );
                int mrcajk1 = tree1.GetMRCA( j, k );
                int mrcaik1 = tree1.GetMRCA( i, k );
                int mrcaij2 = tree2.GetMRCA( i, j );
                int mrcajk2 = tree2.GetMRCA( j, k );
                int mrcaik2 = tree2.GetMRCA( i, k );
//cout << "i = " << i << ", j = " << j << ", k = " << k << endl;
//cout << "mrcaij1 = " << mrcaij1 << ", mrcajk1 = " << mrcajk1 << ", mrcaik1 = " << mrcaik1;
//cout << ", mrcaij2 = " << mrcaij2 << ", mrcajk2 = " << mrcajk2 << ", mrcaik2 = " << mrcaik2 << endl;
                bool fIncTriple = false;

                // now just test exhustively
                if( mrcaij1 == mrcajk1 )
                {
                    if( mrcaij2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }
                else if( mrcaij1 == mrcaik1 )
                {
                    if( mrcaij2 != mrcaik2  )
                    {
                        fIncTriple = true;
                    }
                }
                else 
                {
                    if( mrcaik2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }

                if(fIncTriple == false)
                {
                    // we are only interested in incompatible triple
                    continue;
                }

                pair<int, int> pp(j, k);
                pair<int, pair<int,int> > ppp(i, pp);
                listTriples.push_back(ppp);
//cout << "Incompatible triples = ";
//cout << i << ", " << j << ", " << k << endl;
                // YW: now I believe only one of the following (say (i,j) and (j,k) are needed
                //OutputMkij( outFile, 1, i, j );
                //outFile << " + ";
                //OutputMkij( outFile, 1, i, k );
                //outFile << " <= 1\n";

            }
        }
    }
//#endif

//#if 0
    vector< pair< pair<int,int>, pair<int,int> > > listPairsLeafPairs;
    // now we test for all pair of leaf pairs, to ensure there is no intersection in two trees
    // if the two pairs are left in one tree
    for( int i= 0; i< tree1.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1.GetNumLeaves(); ++j)
        {
            for(int p=i+1; p< tree1.GetNumLeaves(); ++p)
            {
                // make sure p <>i or j
                if(  p == j )
                {
                    continue;
                }
                for(int q = p+1; q < tree1.GetNumLeaves(); ++q)
                {
                    // make sure q is unique twoo
                    if(  q == j )
                    {
                        continue;
                    }

                    // now we only worry about two disjoint path (i,j) and (p,q)
                    if( tree1.AreTwoPathsDisjoint( i, j, p, q ) == false  )
                    {
                        continue;
                    }
                    // also ignore when tree2 has disjoint (i,j) and (p,q), since they auto satisfy the partition
                    if( tree2.AreTwoPathsDisjoint( i, j, p, q ) == true  )
                    {
                        continue;
                    }

                    // now for this, make sure Mi,j + Mp,q <= 1
                    //OutputMkij( outFile, 1, i, j );
                    //outFile << " + ";
                    //OutputMkij( outFile, 1, p, q );
                    //outFile << " <= 1\n";
                    pair<int,int> pp1(i,j);
                    pair<int,int> pp2(p,q);
                    pair< pair<int,int>, pair<int,int> > ppp2(pp1, pp2);
                    listPairsLeafPairs.push_back( ppp2 );

                }
            }
        }
    }
//#endif

    // now enforce additional property here
    // we try to find pair of leaves in tree1Reduced that are sibling and
    // then looks for another tree's same leaves

    // enforce additional property: there is no edge and its immediate parent are cut
//    for( int nn = tree1.GetNumLeaves(); nn < tree1.GetTotNodesNum()-1;  ++nn )
//    {
//        // C,k,pa + c,k,desc1 <=1
//        //int pp = pCurrTree1->GetParent( nn );
//        int pdesc = tree1.GetLeftDescendant( nn );
//        YW_ASSERT_INFO(pdesc >=0, "no descent");
//        OutputCki( outFile, 1,  nn  );
//        outFile << " + ";
//        OutputCki( outFile, 1,  pdesc );
//        outFile << " <= 1\n";

//        pdesc = tree1.GetRightDescendant( nn );
//        YW_ASSERT_INFO(pdesc >=0, "no descent");
//        OutputCki( outFile, 1,  nn  );
//        outFile << " + ";
//        OutputCki( outFile, 1,  pdesc );
//        outFile << " <= 1\n";
//    }




    //
    // now start to create ILP formulation
    // first create the problem
    vector< pair<int,int> > listNodePairs;
    for( set< pair<int,int> > :: iterator it = listPairNodesConstraint.begin(); it != listPairNodesConstraint.end(); ++it )
    {
        listNodePairs.push_back(*it);
    }
    int mvarNum = listPairNodesConstraint.size();
	int objSize = GetCVarNum() + mvarNum;
//cout << "objSize = " << objSize << endl;

    // 3 types of constraints: Mi,j, triples and pair of pairs
    int numConstraints =  3*listPairNodesConstraint.size() + 
        listTriples.size() + listPairsLeafPairs.size() + 2;
//    int numConstraints = boundsInfo.size() ;
//cout << "numConstraints = " << numConstraints << endl;

	YW_ASSERT(  pILPSolver != NULL  );
	// Now, we first create a LP problem
	pILPSolver->CreateProblem( numConstraints, objSize, true );    // we want to minimize

    // setup variables (coluns)
    //int c = 0;
    // first part is the Ci
	for(int ni = 0; ni < tree1.GetTotNodesNum(); ++ni )
	{
        int realVarId = GetCVarPos( ni );
	    char objName[1280];
		objName[0] = 'C'; 
		sprintf(&objName[1], ",%d", ni );
        // the var can be any of the integer value
        // How do we assign coefficient to it
        double coeff = 1.0;
		pILPSolver->SetupVar( realVarId, objName, coeff, true);	
	}

    int mindex = 0;
    for( set< pair<int,int>  > :: iterator it = listPairNodesConstraint.begin(); it != listPairNodesConstraint.end(); ++it )
    {
        //int realVarId = GetMVarPos (ni, nj );
	    char objName[1280];
		objName[0] = 'M'; 
		sprintf(&objName[1], "%d,%d", it->first, it->second );
		pILPSolver->SetupVar( mindex + GetCVarNum(), objName, 0.0, true);	
        mindex ++;
    }


    //setup constraints
    int rcons = 0;

    // first setup root node edge mut to be 0, always
    vector<int> nonzerosPosRoot;
    vector<double> colCoeffsRoot;
    nonzerosPosRoot.push_back(  GetCVarPos( tree1.GetTotNodesNum()-1)  );
    colCoeffsRoot.push_back( 1.0 );
    pILPSolver->AddConstraint( rcons++, nonzerosPosRoot, colCoeffsRoot, 0.0, HAP_ILP_UB);


    // constraints Mi,j
    mindex = 0;
    for( set< pair<int,int>  > :: iterator it = listPairNodesConstraint.begin(); it != listPairNodesConstraint.end(); ++it )
    {
//cout << "n1 = " << it->first << ", n2 = " << it->second << endl;
        int n1 = it->first;
        int n2 = it->second;
        vector<int> nonzerosPos;
        vector<double> colCoeffs;

        int mvarindex = mindex + GetCVarNum();

        if( n1 == n2 )
        {
            // for the last one, simply set to be 1 as always
            //OutputMkij( outFile, 1, n1, n1 );
            //outFile << " = 1\n";
            nonzerosPos.push_back( mvarindex );
            colCoeffs.push_back( 1.0 );
            pILPSolver->AddConstraint( rcons++, nonzerosPos, colCoeffs, 1.0, HAP_ILP_LB);
        }
        else
        {
            // we alternatively move up, depend on which one is smaller
            int nodeNew;
            bool fMoven1 = true;
            if( n1 < n2  )
            {
                // move n1
                nodeNew = pCurrTree->GetParent(n1);
                fMoven1 = true;
            }
            else
            {
                // move n2
                nodeNew = pCurrTree->GetParent(n2);
                fMoven1 = false;
            }

            int n1New, n2New, edgeCuti;
            if( fMoven1 == true ) 
            {
                n1New = nodeNew;
                n2New = n2;
                edgeCuti = n1;
            }
            else
            {
                n1New = n1;
                n2New = nodeNew;
                edgeCuti = n2;
            }
            if( n1New > n2New )
            {
                OrderInt(n1New, n2New);
            }

            int mvarpos2 = GetMVarPos( n1New, n2New, listNodePairs );
            // 
            nonzerosPos.clear();
            colCoeffs.clear();
            nonzerosPos.push_back( mvarindex );
            colCoeffs.push_back( 1.0 );
            nonzerosPos.push_back( mvarpos2 );       // next item must be the next one here
            colCoeffs.push_back( -1.0 );
            pILPSolver->AddConstraint( rcons++, nonzerosPos, colCoeffs, 0.0, HAP_ILP_UB);

            nonzerosPos.clear();
            colCoeffs.clear();
            nonzerosPos.push_back( mvarindex );
            colCoeffs.push_back( 1.0 );
            nonzerosPos.push_back( mvarpos2 );       // next item must be the next one here
            colCoeffs.push_back( -1.0 );
            nonzerosPos.push_back(  GetCVarPos( edgeCuti )  );       // next item must be the next one here
            colCoeffs.push_back( 1.0 );
            pILPSolver->AddConstraint( rcons++, nonzerosPos, colCoeffs, 0.0, HAP_ILP_LB);

            nonzerosPos.clear();
            colCoeffs.clear();
            nonzerosPos.push_back( mvarindex );
            colCoeffs.push_back( 1.0 );
            nonzerosPos.push_back(  GetCVarPos( edgeCuti )  );       // next item must be the next one here
            colCoeffs.push_back( 1.0 );
            pILPSolver->AddConstraint( rcons++, nonzerosPos, colCoeffs, 1.0, HAP_ILP_UB);

       }

        // update index
        mindex ++;

    }

    // second group of constraints
    // now try all possible triples of leaves i,j,k
    vector<int> nonzerosPos;
    vector<double> colCoeffs;
    for( int i=0; i<(int)listTriples.size(); ++i )
    {
//cout << "Triples i, j, k = " <<  listTriples[i].first << ", " << listTriples[i].second.first << ", " 
//<< listTriples[i].second.second << endl;
        pair<int,int> pp1( listTriples[i].first, listTriples[i].second.first );
        pair<int,int> pp2( listTriples[i].first, listTriples[i].second.second );
        int mvar1pos = GetMVarPos(pp1.first, pp1.second, listNodePairs);
        int mvar2pos = GetMVarPos(pp2.first, pp2.second, listNodePairs);
//cout << "Adding triples var pos1 = " << mvar1pos << ", pos2 = " << mvar2pos << endl;
        nonzerosPos.clear();
        colCoeffs.clear();
        nonzerosPos.push_back( mvar1pos );
        colCoeffs.push_back( 1.0 );
        nonzerosPos.push_back( mvar2pos );       // next item must be the next one here
        colCoeffs.push_back( 1.0 );
        pILPSolver->AddConstraint( rcons++, nonzerosPos, colCoeffs, 1.0, HAP_ILP_UB);
    }
    // now pair of pair constraints
    for( int i=0; i<(int)listPairsLeafPairs.size(); ++i )
    {
        int mvar1pos = GetMVarPos(listPairsLeafPairs[i].first.first, listPairsLeafPairs[i].first.second, listNodePairs);
        int mvar2pos = GetMVarPos(listPairsLeafPairs[i].second.first, listPairsLeafPairs[i].second.second, listNodePairs);
//cout << "Adding pair of pairs var pos1 = " << mvar1pos << ", pos2 = " << mvar2pos << endl;
        nonzerosPos.clear();
        colCoeffs.clear();
        nonzerosPos.push_back( mvar1pos );
        colCoeffs.push_back( 1.0 );
        nonzerosPos.push_back( mvar2pos );       // next item must be the next one here
        colCoeffs.push_back( 1.0 );
        pILPSolver->AddConstraint( rcons++, nonzerosPos, colCoeffs, 1.0, HAP_ILP_UB);
    }

    // finish up the constraints
    for( int j = rcons; j < numConstraints; ++j)
    {
    	vector<int> nonzerosPos;
        vector<double> colCoeffs;
        pILPSolver->AddConstraint( rcons++, nonzerosPos, colCoeffs, 0.0, HAP_ILP_LB);
    }


    //solve and retrive the result
	ILPSolution solILP(0, objSize-1);
	solILP.Init( objSize, objSize, NULL);
	bool f = pILPSolver->Solve( solILP );
	if( f == false)
	{
		cout << "Fail to solve interger program." << endl;
		exit(-1); 
	}
//cout << "The objective = " << solILP.optObjective << endl; 
    int res = (int)(solILP.optObjective + 0.01) ;


    // also keep track of which edges are cut
    FindCutEdges( solILP );

    // free up ILP
    delete pILPSolver;

    return res;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
int ILPSolverSPR :: GetCVarNum() const
{
    // equal to 2*number of edges
    return (tree1.GetTotNodesNum()  );
}
int ILPSolverSPR :: GetCVarPos(  int edgePos ) const
{
    //  just the edge var position
    return  edgePos;
}

//int ILPSolverSPR :: GetMVarNum() const
//{
    // equal to numleaf*(numleaf-1)/2
//    return (tree1.GetNumLeaves()-1)*tree1.GetNumLeaves()/2;
//}

int ILPSolverSPR :: GetMVarPos( int ni, int nj, const vector<pair<int,int> > &listNodePairs  ) const
{
    //int numItemsBefore = ni*( tree1.GetNumLeaves()-1  + tree1.GetNumLeaves()  - ni   )/2;
    int numItemsBefore = 0;
    
    for( int i=0; i<(int)listNodePairs.size(); ++i )
    {
        if( listNodePairs[i].first != ni || listNodePairs[i].second != nj )
        {
            numItemsBefore++;
        }
        else
        {
            break;
        }
    }

    int res =  GetCVarNum() + numItemsBefore ;
//    YW_ASSERT_INFO( res < GetCVarNum() + GetMVarNum(), "Variable out of range." );
    return res;
}
#if 0
int ILPSolverSPR :: GetTotConstraintsNum() const
{
    // for now, use very conservative number
    // this include two parts, for each edge up to 2*2*max-ht*num of pairs of node
    int nL = tree1.GetNumLeaves();
    int maxht1 = tree1.GetMaxHt();
    int maxht2 = tree2.GetMaxHt();
    int maxht = maxht1;
    if( maxht < maxht2 )
    {
        maxht = maxht2;
    }
    int numc1 = 2*maxht*(nL)*(nL-1);

    // second part is all triples of nodes
    int numc2 = nL * (nL-1)*(nL-2)/2;
    int numExtra = 2;
    return numc1 + numc2 + numExtra;
}
#endif

int ILPSolverSPR :: GetGVarPos( int ni, int nj, int vstart) const
{
    int numItemsBefore = ni*( tree1.GetNumLeaves()-1  + tree1.GetNumLeaves()  - ni   )/2;

    int res =  vstart + numItemsBefore + nj - ni -1;
    return res;
}


int ILPSolverSPR :: ComputeHeuristic()
{
    // we first collect path set information
    vector< set<int> > hittingEdgeSets;

    // now try all possible triples of leaves i,j,k
    for( int i= 0; i< tree1.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1.GetNumLeaves(); ++j)
        {
            for(int k=j+1; k< tree1.GetNumLeaves(); ++k)
            {
                // is these have different triples on T1 and T2?
                // we do this by getting MRCA for all pairs of MRCAs
                int mrcaij1 = tree1.GetMRCA( i, j );
                int mrcajk1 = tree1.GetMRCA( j, k );
                int mrcaik1 = tree1.GetMRCA( i, k );
                int mrcaij2 = tree2.GetMRCA( i, j );
                int mrcajk2 = tree2.GetMRCA( j, k );
                int mrcaik2 = tree2.GetMRCA( i, k );

                bool fIncTriple = false;

                // now just test exhustively
                if( mrcaij1 == mrcajk1 )
                {
                    if( mrcaij2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }
                else if( mrcaij1 == mrcaik1 )
                {
                    if( mrcaij2 != mrcaik2  )
                    {
                        fIncTriple = true;
                    }
                }
                else 
                {
                    if( mrcaik2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }

                if(fIncTriple == false)
                {
                    // we are only interested in incompatible triple
                    continue;
                }

                // we find the edges on the path
                set<int> triPathEdges;
                set<int> listEdgesij;
                tree1.GetPath( i,j, listEdgesij );
                triPathEdges = listEdgesij;
                set<int> listEdgesjk;
                tree1.GetPath( j,k, listEdgesjk );
                UnionSets( triPathEdges, listEdgesjk );
                set<int> listEdgesik;
                tree1.GetPath( i,k, listEdgesik );
                UnionSets( triPathEdges, listEdgesik );

                // ensure at least one edge is cut on tri-path
                hittingEdgeSets.push_back( triPathEdges );
            }
        }
    }
    // now we test for all pair of leaf pairs, to ensure there is no intersection in two trees
    // if the two pairs are left in one tree
    for( int i= 0; i< tree1.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1.GetNumLeaves(); ++j)
        {
            for(int p=i+1; p< tree1.GetNumLeaves(); ++p)
            {
                // make sure p <>i or j
                if(  p == j )
                {
                    continue;
                }
                for(int q = p+1; q < tree1.GetNumLeaves(); ++q)
                {
                    // make sure q is unique twoo
                    if(  q == j )
                    {
                        continue;
                    }

                    // now we only worry about two disjoint path (i,j) and (p,q)
                    if( tree1.AreTwoPathsDisjoint( i, j, p, q ) == false  )
                    {
                        continue;
                    }
                    // also ignore when tree2 has disjoint (i,j) and (p,q), since they auto satisfy the partition
                    if( tree2.AreTwoPathsDisjoint( i, j, p, q ) == true  )
                    {
                        continue;
                    }

                    // rertreive the path here
                    set<int> twinPathEdges;
                    set<int> listEdgesij;
                    tree1.GetPath( i,j, listEdgesij );
                    twinPathEdges = listEdgesij;
                    set<int> listEdgespq;
                    tree1.GetPath( p,q, listEdgespq );
                    UnionSets( twinPathEdges, listEdgespq );

                    // ensure at least one edge is cut on tri-path
                    hittingEdgeSets.push_back( twinPathEdges );
                }
            }
        }
    }
    // to speedup search, construct an indexing: for each edge, list sets that comes with it
    vector< set<int> > listEdgeMemberInSets;
    for( int i=0; i<tree1.GetTotNodesNum(); ++i )
    {
        set<int> edgeMemberSet;
        // find all sets that has it
        for( int ss = 0; ss <(int) hittingEdgeSets.size(); ++ss )
        {
            if( hittingEdgeSets[ss].find( i ) != hittingEdgeSets[ss].end()  )
            {
                edgeMemberSet.insert( ss ) ;
            }
        }

        listEdgeMemberInSets.push_back( edgeMemberSet );
    }

    // now we first collect statistics on how often each edge appears in hitting sets
    vector<int> listEdgeMemberCounts;
    for( int i=0; i<tree1.GetTotNodesNum(); ++i )
    {
        listEdgeMemberCounts.push_back(0);
    }
    for(  vector< set<int> > :: iterator it = hittingEdgeSets.begin(); it != hittingEdgeSets.end(); ++it)
    {
        for( set<int> :: iterator it2 = it->begin(); it2 != it->end(); ++it2 )
        {
            listEdgeMemberCounts[*it2]++;
        }
    }


    // compute a heuristic result by uniformly picking edges to cut
    const int MAX_NUM_RUN = 500;
    int minRes = HAP_MAX_INT;
    for(int i=0; i<MAX_NUM_RUN; ++i)
    {
        int resCurr = ComputeHeuristicRun( hittingEdgeSets, listEdgeMemberCounts, listEdgeMemberInSets );
        if( resCurr < minRes )
        {
            minRes = resCurr;
cout << "Current best result = " << minRes << endl;
        }
    }
    return minRes;
}

int ILPSolverSPR :: ComputeHeuristicRun( const vector<set<int> > &hittingEdgeSets, 
                                        const vector<int> &listEdgeMemberCountsInit, 
                                        const vector< set<int> > &listEdgeMemberInSets)
{
    // one run of heuristic
    //vector< set<int> > hittingSetsCurr = hittingEdgeSetsInit;
    vector<double> listEdgeMemberCntCurr;
    vector<bool> activeSetFlags;
    for( int i=0; i<(int)hittingEdgeSets.size(); ++i )
    {
        activeSetFlags.push_back(true); // initially, every set is active
    }
    for(int i=0; i<(int)listEdgeMemberCountsInit.size(); ++i)
    {
        listEdgeMemberCntCurr.push_back( listEdgeMemberCountsInit[i] );
    }

    int setsRemainNum = hittingEdgeSets.size();
    int res = 0;
    while( setsRemainNum > 0 )
    {
//cout << "listEdgeMemberCntCurr = ";
//DumpDoubleVec( listEdgeMemberCntCurr );
        // uniformly pick one from list
        int edge = GetWeightedRandItemIndex(listEdgeMemberCntCurr);
        YW_ASSERT_INFO(edge >=0, "fail");
        res ++;

        // now update weights and find current sets
        // we simply find all sets with edge as part of its set
        //set< set<int> > hittingSetNew;
        for(  set<int> :: iterator it = listEdgeMemberInSets[edge].begin(); it != listEdgeMemberInSets[edge].end(); ++it)
        {
            // if this is not an active set, skip
            if( activeSetFlags[ *it ] == false )
            {
                continue;
            }

            // now decrease edge count from this
            for( set<int> :: iterator it2 = hittingEdgeSets[*it].begin(); it2 != hittingEdgeSets[*it].end(); ++it2)
            {
                listEdgeMemberCntCurr[ *it2 ] --;
                YW_ASSERT_INFO( listEdgeMemberCntCurr[*it2] >= 0.0, "negative" );
            }

            // mark off this
            activeSetFlags[*it] = false;
            setsRemainNum --;
        }
        // make sure the edge count is close to 0
        YW_ASSERT_INFO( listEdgeMemberCntCurr[edge] < 0.001, "wrong");
        //hittingSetsCurr = hittingSetNew;

        // stop when all sets are covered
        ;

    }
//cout << "Remaining vectors : ";
//DumpDoubleVec(listEdgeMemberCntCurr);
    return res;
}


int ILPSolverSPR :: ComputeAcyclicrSPR()
{
    // This is similar to rSPR, but we require one additonal stuff to ensure acyclic

    // first call SPR to ensure we have a lower bound
//    int lbarSPR = ComputeILP();
    int lbarSPR = -1;

    // now setup constraints 
    ILPSolver *pILPSolver;
#ifdef LPSOLVER_CPLEX
	pILPSolver = new CPlexILPSolver;
#endif

#ifdef LPSOLVER_GLPK
	pILPSolver = new GLPKILPSolver;
#endif


    // now store which pairs of nodes we need to output for constraints
    // WARNING: we assume the first node is always smaller than (or equal) the second node
    set< pair<int,int> > listPairNodesConstraint;

    // start from the first tree
    const MarginalTree *pCurrTree = &tree1;

    for( int i= 0; i< pCurrTree->GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< pCurrTree->GetNumLeaves(); ++j)
        {
            // first we need to find MRCA of i,j. 
            // note that we actually want to exluce MRCA, but include i,j!
            //vector<int> listPathNodes;
            int n1=i, n2 = j;
            while( n1 <= n2 )
            {
                // IMPORTANT: make sure n1 <= n2 (true upon entry)

                // enforce an property
                pair<int,int> pp(n1, n2);
                if( listPairNodesConstraint.find(pp) != listPairNodesConstraint.end()   )
                {
                    // we already reach what we need, stop
                    break;
                }
                listPairNodesConstraint.insert(pp);

                if( n1 == n2 )
                {
                    // for the last one, simply set to be 1 as always
                    //OutputMkij( outFile, 1, n1, n1 );
                    //outFile << " = 1\n";
                    break;
                }
                else
                {
                    // we alternatively move up, depend on which one is smaller
                    int nodeNew;
                    bool fMoven1 = true;
                    if( n1 < n2  )
                    {
                        // move n1
                        nodeNew = pCurrTree->GetParent(n1);
                        fMoven1 = true;
                    }
                    else
                    {
                        // move n2
                        nodeNew = pCurrTree->GetParent(n2);
                        fMoven1 = false;
                    }

                    int n1New, n2New, edgeCuti;
                    if( fMoven1 == true ) 
                    {
                        n1New = nodeNew;
                        n2New = n2;
                        edgeCuti = n1;
                    }
                    else
                    {
                        n1New = n1;
                        n2New = nodeNew;
                        edgeCuti = n2;
                    }
                    if( n1New > n2New )
                    {
                        OrderInt(n1New, n2New);
                    }

                    // here are constraints
                    //OutputMkij( outFile, 1, n1, n2 );
                    //outFile << " - ";
                    //OutputMkij( outFile, 1, n1New, n2New );
                    //outFile << " <= 0\n";

                    //OutputMkij( outFile, 1, n1, n2 );
                    //outFile << " + ";
                    //OutputCki( outFile, 1,  edgeCuti);
                    //outFile << " - ";
                    //OutputMkij( outFile, 1, n1New, n2New );
                    //outFile << " >= 0\n";

                    //OutputMkij( outFile, 1, n1, n2 );
                    //outFile << " + ";
                    //OutputCki( outFile, 1,  edgeCuti);
                    //outFile << " <= 1\n";

                     // now update n1 and n2
                    n1 = n1New;
                    n2 = n2New;
               }
            }

        }
    }


//#if 0
    // now try all possible triples of leaves i,j,k
    vector<  pair<int, pair<int,int> >  > listTriples;
    for( int i= 0; i< tree1.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1.GetNumLeaves(); ++j)
        {
            for(int k=j+1; k< tree1.GetNumLeaves(); ++k)
            {
                // is these have different triples on T1 and T2?
                // we do this by getting MRCA for all pairs of MRCAs
                int mrcaij1 = tree1.GetMRCA( i, j );
                int mrcajk1 = tree1.GetMRCA( j, k );
                int mrcaik1 = tree1.GetMRCA( i, k );
                int mrcaij2 = tree2.GetMRCA( i, j );
                int mrcajk2 = tree2.GetMRCA( j, k );
                int mrcaik2 = tree2.GetMRCA( i, k );

                bool fIncTriple = false;

                // now just test exhustively
                if( mrcaij1 == mrcajk1 )
                {
                    if( mrcaij2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }
                else if( mrcaij1 == mrcaik1 )
                {
                    if( mrcaij2 != mrcaik2  )
                    {
                        fIncTriple = true;
                    }
                }
                else 
                {
                    if( mrcaik2 != mrcajk2  )
                    {
                        fIncTriple = true;
                    }
                }

                if(fIncTriple == false)
                {
                    // we are only interested in incompatible triple
                    continue;
                }

                pair<int, int> pp(j, k);
                pair<int, pair<int,int> > ppp(i, pp);
                listTriples.push_back(ppp);

                // YW: now I believe only one of the following (say (i,j) and (j,k) are needed
                //OutputMkij( outFile, 1, i, j );
                //outFile << " + ";
                //OutputMkij( outFile, 1, i, k );
                //outFile << " <= 1\n";

            }
        }
    }
//#endif

//#if 0
    vector< pair< pair<int,int>, pair<int,int> > > listPairsLeafPairs;
    // now we test for all pair of leaf pairs, to ensure there is no intersection in two trees
    // if the two pairs are left in one tree
    for( int i= 0; i< tree1.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1.GetNumLeaves(); ++j)
        {
            for(int p=i+1; p< tree1.GetNumLeaves(); ++p)
            {
                // make sure p <>i or j
                if(  p == j )
                {
                    continue;
                }
                for(int q = p+1; q < tree1.GetNumLeaves(); ++q)
                {
                    // make sure q is unique twoo
                    if(  q == j )
                    {
                        continue;
                    }

                    // now we only worry about two disjoint path (i,j) and (p,q)
                    if( tree1.AreTwoPathsDisjoint( i, j, p, q ) == false  )
                    {
                        continue;
                    }
                    // also ignore when tree2 has disjoint (i,j) and (p,q), since they auto satisfy the partition
                    if( tree2.AreTwoPathsDisjoint( i, j, p, q ) == true  )
                    {
                        continue;
                    }

                    // now for this, make sure Mi,j + Mp,q <= 1
                    //OutputMkij( outFile, 1, i, j );
                    //outFile << " + ";
                    //OutputMkij( outFile, 1, p, q );
                    //outFile << " <= 1\n";
                    pair<int,int> pp1(i,j);
                    pair<int,int> pp2(p,q);
                    pair< pair<int,int>, pair<int,int> > ppp2(pp1, pp2);
                    listPairsLeafPairs.push_back( ppp2 );

                }
            }
        }
    }
//#endif

    // now enforce additional property here
    // we try to find pair of leaves in tree1Reduced that are sibling and
    // then looks for another tree's same leaves

    // enforce additional property: there is no edge and its immediate parent are cut
//    for( int nn = tree1.GetNumLeaves(); nn < tree1.GetTotNodesNum()-1;  ++nn )
//    {
//        // C,k,pa + c,k,desc1 <=1
//        //int pp = pCurrTree1->GetParent( nn );
//        int pdesc = tree1.GetLeftDescendant( nn );
//        YW_ASSERT_INFO(pdesc >=0, "no descent");
//        OutputCki( outFile, 1,  nn  );
//        outFile << " + ";
//        OutputCki( outFile, 1,  pdesc );
//        outFile << " <= 1\n";

//        pdesc = tree1.GetRightDescendant( nn );
//        YW_ASSERT_INFO(pdesc >=0, "no descent");
//        OutputCki( outFile, 1,  nn  );
//        outFile << " + ";
//        OutputCki( outFile, 1,  pdesc );
//        outFile << " <= 1\n";
//    }

    const MarginalTree *ptrTrees[2];
    ptrTrees[0] = &tree1;
    ptrTrees[1] = &tree2;
    // now try the other tree
    vector< pair< pair<int,int>, set<int> >   >  listRootConstraints;
    for( int i= 0; i< tree1.GetNumLeaves() ; ++i  )
    {
        for( int j= i+1; j< tree1.GetNumLeaves() ; ++j  )
        {
            // now try only one trees
            //int k = 2;
            for(  int k=1; k<=2; ++k  )
            {
                const MarginalTree *pCurrTree = ptrTrees[k-1];

                int rmrca = pCurrTree->GetMRCA( i, j );

                set<int> subtreei, subtreej, subtreek;
                // the subtreei = leaves under left descendent of rmrca
                //set<int> pathi;
                pCurrTree->GetLeavesUnder( pCurrTree->GetLeftDescendant(rmrca) , subtreei );
                //set<int> pathj;
                pCurrTree->GetLeavesUnder( pCurrTree->GetRightDescendant(rmrca) , subtreej );
                if( subtreei.find(i) == subtreei.end() )
                {
                    YW_ASSERT_INFO( subtreej.find(i) != subtreej.end()  
                        && subtreei.find(j) != subtreei.end(), "false"  );
                    set<int> tmpset = subtreei;
                    subtreei = subtreej;
                    subtreej = tmpset;
                }
                // now also the other part of leaves by taking a complement
                set<int> subtreeij = subtreei;
                UnionSets(subtreeij,  subtreej);
                PopulateSetWithInterval( subtreek, 0, pCurrTree->GetNumLeaves()-1 );
                SubtractSets( subtreek, subtreeij );


                set<int> subtreeTest = subtreek;
                UnionSets( subtreeTest, subtreej );
                int numik = subtreeTest.size()-1;

                if( numik > 0 )
                {
                    // add one root consrraint
                    pair<int, int> pp(i,j);
//                    subtreeTest.erase( j );
                    pair< pair<int,int>, set<int> > pps(pp, subtreeTest );
                    listRootConstraints.push_back(pps);

                }

                subtreeTest = subtreek;
                UnionSets( subtreeTest, subtreei );
                int numjk = subtreeTest.size()-1;

                if( numjk > 0 )
                {
                    pair<int, int> pp(i,j);
//                    subtreeTest.erase( i );
                    pair< pair<int,int>, set<int> > pps(pp, subtreeTest );
                    listRootConstraints.push_back(pps);



                }

            }
        }
    }





    //
    // now start to create ILP formulation
    // first create the problem
    vector< pair<int,int> > listNodePairs;
    for( set< pair<int,int> > :: iterator it = listPairNodesConstraint.begin(); it != listPairNodesConstraint.end(); ++it )
    {
        listNodePairs.push_back(*it);
    }
    int mvarNum = listPairNodesConstraint.size();
    int gvarNum =  tree1.GetNumLeaves()*(  tree1.GetNumLeaves()-1) /2;
	int objSize = GetCVarNum() + mvarNum + gvarNum;
//cout << "objSize = " << objSize << endl;

    // 3 types of constraints: Mi,j, triples and pair of pairs
    int numConstraints =  3*listPairNodesConstraint.size() + 
        listTriples.size() + listPairsLeafPairs.size() + 2 + listRootConstraints.size() + 
        gvarNum*(tree1.GetNumLeaves()-2)*2/3 ;
//    int numConstraints = boundsInfo.size() ;
//cout << "numConstraints = " << numConstraints << endl;

	YW_ASSERT(  pILPSolver != NULL  );
	// Now, we first create a LP problem
	pILPSolver->CreateProblem( numConstraints, objSize, true );    // we want to minimize

    // setup variables (coluns)
    //int c = 0;
    // first part is the Ci
	for(int ni = 0; ni < tree1.GetTotNodesNum(); ++ni )
	{
        int realVarId = GetCVarPos( ni );
	    char objName[1280];
		objName[0] = 'C'; 
		sprintf(&objName[1], ",%d", ni );
        // the var can be any of the integer value
        // How do we assign coefficient to it
        double coeff = 1.0;
		pILPSolver->SetupVar( realVarId, objName, coeff, true);	
	}

    int mindex = 0;
    for( set< pair<int,int>  > :: iterator it = listPairNodesConstraint.begin(); it != listPairNodesConstraint.end(); ++it )
    {
        //int realVarId = GetMVarPos (ni, nj );
	    char objName[1280];
		objName[0] = 'M'; 
		sprintf(&objName[1], "%d,%d", it->first, it->second );
		pILPSolver->SetupVar( mindex + GetCVarNum(), objName, 0.0, true);	
        mindex ++;
    }
    // vars for Gi,j
    int rindex = 0;
    for( int i= 0; i< tree1.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1.GetNumLeaves(); ++j)
        {
            //if( j == i )
            //{
            //    continue;
            //}
            //for(int k=j+1; k< tree1.GetNumLeaves(); ++k)
            {
                // setup this?
	            char objName[1280];
		        objName[0] = 'G'; 
		        sprintf(&objName[1], "%d,%d", i, j );
		        pILPSolver->SetupVar( rindex + GetCVarNum() + mvarNum, objName, 0.0, true);	
                rindex ++;
            }
        }
    }


    //setup constraints
    int rcons = 0;

    // if LB is given, then setup a lower bound
    if( lbarSPR > 0 )
    {
        // find it
        vector<int> nonzerosPos;
        vector<double> colCoeffs;

	    for(int ni = 0; ni < tree1.GetTotNodesNum(); ++ni )
	    {
            //
            nonzerosPos.push_back(ni);
            colCoeffs.push_back( 1.0 );
	    }
        pILPSolver->AddConstraint( rcons++, nonzerosPos, colCoeffs, lbarSPR, HAP_ILP_LB);
    }

    // first setup root node edge mut to be 0, always
    vector<int> nonzerosPosRoot;
    vector<double> colCoeffsRoot;
    nonzerosPosRoot.push_back(  GetCVarPos( tree1.GetTotNodesNum()-1)  );
    colCoeffsRoot.push_back( 1.0 );
    pILPSolver->AddConstraint( rcons++, nonzerosPosRoot, colCoeffsRoot, 0.0, HAP_ILP_UB);


    // constraints Mi,j
    mindex = 0;
    for( set< pair<int,int>  > :: iterator it = listPairNodesConstraint.begin(); it != listPairNodesConstraint.end(); ++it )
    {
//cout << "n1 = " << it->first << ", n2 = " << it->second << endl;
        int n1 = it->first;
        int n2 = it->second;
        vector<int> nonzerosPos;
        vector<double> colCoeffs;

        int mvarindex = mindex + GetCVarNum();

        if( n1 == n2 )
        {
            // for the last one, simply set to be 1 as always
            //OutputMkij( outFile, 1, n1, n1 );
            //outFile << " = 1\n";
            nonzerosPos.push_back( mvarindex );
            colCoeffs.push_back( 1.0 );
            pILPSolver->AddConstraint( rcons++, nonzerosPos, colCoeffs, 1.0, HAP_ILP_LB);
        }
        else
        {
            // we alternatively move up, depend on which one is smaller
            int nodeNew;
            bool fMoven1 = true;
            if( n1 < n2  )
            {
                // move n1
                nodeNew = pCurrTree->GetParent(n1);
                fMoven1 = true;
            }
            else
            {
                // move n2
                nodeNew = pCurrTree->GetParent(n2);
                fMoven1 = false;
            }

            int n1New, n2New, edgeCuti;
            if( fMoven1 == true ) 
            {
                n1New = nodeNew;
                n2New = n2;
                edgeCuti = n1;
            }
            else
            {
                n1New = n1;
                n2New = nodeNew;
                edgeCuti = n2;
            }
            if( n1New > n2New )
            {
                OrderInt(n1New, n2New);
            }

            int mvarpos2 = GetMVarPos( n1New, n2New, listNodePairs );
            // 
            nonzerosPos.clear();
            colCoeffs.clear();
            nonzerosPos.push_back( mvarindex );
            colCoeffs.push_back( 1.0 );
            nonzerosPos.push_back( mvarpos2 );       // next item must be the next one here
            colCoeffs.push_back( -1.0 );
            pILPSolver->AddConstraint( rcons++, nonzerosPos, colCoeffs, 0.0, HAP_ILP_UB);

            nonzerosPos.clear();
            colCoeffs.clear();
            nonzerosPos.push_back( mvarindex );
            colCoeffs.push_back( 1.0 );
            nonzerosPos.push_back( mvarpos2 );       // next item must be the next one here
            colCoeffs.push_back( -1.0 );
            nonzerosPos.push_back(  GetCVarPos( edgeCuti )  );       // next item must be the next one here
            colCoeffs.push_back( 1.0 );
            pILPSolver->AddConstraint( rcons++, nonzerosPos, colCoeffs, 0.0, HAP_ILP_LB);

            nonzerosPos.clear();
            colCoeffs.clear();
            nonzerosPos.push_back( mvarindex );
            colCoeffs.push_back( 1.0 );
            nonzerosPos.push_back(  GetCVarPos( edgeCuti )  );       // next item must be the next one here
            colCoeffs.push_back( 1.0 );
            pILPSolver->AddConstraint( rcons++, nonzerosPos, colCoeffs, 1.0, HAP_ILP_UB);

       }

        // update index
        mindex ++;

    }

    // second group of constraints
    // now try all possible triples of leaves i,j,k
    vector<int> nonzerosPos;
    vector<double> colCoeffs;
    for( int i=0; i<(int)listTriples.size(); ++i )
    {
//cout << "Triples i, j, k = " <<  listTriples[i].first << ", " << listTriples[i].second.first << ", " 
//<< listTriples[i].second.second << endl;
        pair<int,int> pp1( listTriples[i].first, listTriples[i].second.first );
        pair<int,int> pp2( listTriples[i].first, listTriples[i].second.second );
        int mvar1pos = GetMVarPos(pp1.first, pp1.second, listNodePairs);
        int mvar2pos = GetMVarPos(pp2.first, pp2.second, listNodePairs);
//cout << "Adding triples var pos1 = " << mvar1pos << ", pos2 = " << mvar2pos << endl;
        nonzerosPos.clear();
        colCoeffs.clear();
        nonzerosPos.push_back( mvar1pos );
        colCoeffs.push_back( 1.0 );
        nonzerosPos.push_back( mvar2pos );       // next item must be the next one here
        colCoeffs.push_back( 1.0 );
        pILPSolver->AddConstraint( rcons++, nonzerosPos, colCoeffs, 1.0, HAP_ILP_UB);
    }
    // now pair of pair constraints
    for( int i=0; i<(int)listPairsLeafPairs.size(); ++i )
    {
        int mvar1pos = GetMVarPos(listPairsLeafPairs[i].first.first, listPairsLeafPairs[i].first.second, listNodePairs);
        int mvar2pos = GetMVarPos(listPairsLeafPairs[i].second.first, listPairsLeafPairs[i].second.second, listNodePairs);
//cout << "Adding pair of pairs var pos1 = " << mvar1pos << ", pos2 = " << mvar2pos << endl;
        nonzerosPos.clear();
        colCoeffs.clear();
        nonzerosPos.push_back( mvar1pos );
        colCoeffs.push_back( 1.0 );
        nonzerosPos.push_back( mvar2pos );       // next item must be the next one here
        colCoeffs.push_back( 1.0 );
        pILPSolver->AddConstraint( rcons++, nonzerosPos, colCoeffs, 1.0, HAP_ILP_UB);
    }

    // constraint roots
    for( vector< pair< pair<int,int>, set<int> > > :: iterator it = listRootConstraints.begin(); it != listRootConstraints.end(); ++it )
    {
        int i = it->first.first;
        int j = it->first.second;
        int vargij = GetGVarPos( i,j, GetCVarNum() + mvarNum  );
        int subsetsize = it->second.size()-1;

        if( subsetsize <= 0)
        {
            continue;
        }

        nonzerosPos.clear();
        colCoeffs.clear();
        nonzerosPos.push_back( vargij );
        colCoeffs.push_back( subsetsize );
        bool isIIn = (it->second.find( i ) != it->second.end() );
        int mvarpos = GetMVarPos( i, j, listNodePairs );
        nonzerosPos.push_back( mvarpos );       // next item must be the next one here
        int coeffToUse = subsetsize;
        if( isIIn == true )
        {
            coeffToUse *= -1;
        }
        colCoeffs.push_back( coeffToUse );

        for( set<int> :: iterator itt = it->second.begin(); itt != it->second.end(); ++itt  )
        {
            int ppp = *itt;

            if( ppp == i || ppp == j)
            {
                continue;
            }

            int pos1 = i;
            if(  isIIn == true )
            {
                pos1 = j;
            }
            int pos2 = ppp;
            OrderInt( pos1, pos2);
            int varmjk = GetMVarPos( pos1, pos2, listNodePairs );;
            nonzerosPos.push_back( varmjk );
            int coeffToUse = -1;
            if( isIIn == true)
            {
                coeffToUse = 1;
            }
            colCoeffs.push_back( coeffToUse );

        }
        if( isIIn == true )
        {
            pILPSolver->AddConstraint( rcons++, nonzerosPos, colCoeffs, subsetsize, HAP_ILP_UB);
        }
        else
        {
             pILPSolver->AddConstraint( rcons++, nonzerosPos, colCoeffs, 0.0, HAP_ILP_LB);
       }
    }

    // now enforce acylic property
    for( int i= 0; i< tree1.GetNumLeaves() ; ++i  )
    {
        for(int j=i+1; j< tree1.GetNumLeaves(); ++j)
        {
            int vargij = GetGVarPos( i,j, GetCVarNum() + mvarNum  );
            //if( j == i )
            //{
            //    continue;
            //}
            for(int k=j+1; k< tree1.GetNumLeaves(); ++k)
            {
                int vargjk = GetGVarPos( j,k, GetCVarNum() + mvarNum  );
                int vargik = GetGVarPos( i,k, GetCVarNum() + mvarNum  );


                nonzerosPos.clear();
                colCoeffs.clear();
                nonzerosPos.push_back( vargik );
                colCoeffs.push_back( 1.0 );
                nonzerosPos.push_back( vargij );       // next item must be the next one here
                colCoeffs.push_back( -1.0 );
                nonzerosPos.push_back( vargjk );       // next item must be the next one here
                colCoeffs.push_back( -1.0 );
                pILPSolver->AddConstraint( rcons++, nonzerosPos, colCoeffs, -1.0, HAP_ILP_LB);

                nonzerosPos.clear();
                colCoeffs.clear();
                nonzerosPos.push_back( vargik );
                colCoeffs.push_back( 1.0 );
                nonzerosPos.push_back( vargij );       // next item must be the next one here
                colCoeffs.push_back( -1.0 );
                nonzerosPos.push_back( vargjk );       // next item must be the next one here
                colCoeffs.push_back( -1.0 );
                pILPSolver->AddConstraint( rcons++, nonzerosPos, colCoeffs, 0.0, HAP_ILP_UB);


            }
        }
    }


    // finish up the constraints
    for( int j = rcons; j < numConstraints; ++j)
    {
    	vector<int> nonzerosPos;
        vector<double> colCoeffs;
        pILPSolver->AddConstraint( rcons++, nonzerosPos, colCoeffs, 0.0, HAP_ILP_LB);
    }

cout << "Now ready to solve...\n";
    //solve and retrive the result
	ILPSolution solILP(0, objSize-1);
	solILP.Init( objSize, objSize, NULL);
	bool f = pILPSolver->Solve( solILP );
	if( f == false)
	{
		cout << "Fail to solve interger program." << endl;
		exit(-1); 
	}
//cout << "The objective = " << solILP.optObjective << endl; 
    int res = (int)(solILP.optObjective + 0.01) ;

    // also keep track of which edges are cut
    FindCutEdges( solILP );

    // free up ILP
    delete pILPSolver;

    return res;
}


void ILPSolverSPR :: FindCutEdges( const ILPSolution &solILP )
{
    edgesCut.clear();
    // 
    for( int i=0; i<tree1.GetTotNodesNum()-1; ++i )
    {
        if( solILP.pSolution[i] >= 0.9 )
        {
            edgesCut.push_back( i );
        }
    }
}
