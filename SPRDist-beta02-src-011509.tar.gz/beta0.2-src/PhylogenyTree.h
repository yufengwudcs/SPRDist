#ifndef PHYLOGENY_TREE_H
#define PHYLOGENY_TREE_H


#include <iostream>
#include <fstream>
#include <cstdio>
#include <vector>
#include <set> 
#include <string>
#include <stack>

#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include <ctime>
#include <cstdlib>
#include <cstdio>

#include "Utils.h"
#include "BinaryMatrix.h"



using namespace std;


//*****************************************************************************
// Defintions and utilties class, not for external use. 
// Myabe I should create a separate file for these implementation-only stuff. Later
// ****************************************************************************
typedef enum
{
    PHY_TN_DEFAULT_SHAPE = 0,
    PHY_TN_RECTANGLE = 1
} TREE_NODE_SHAPE;

class TreeNode
{
    friend class PhylogenyTree;
public:
    TreeNode();
    TreeNode(int iid);
    ~TreeNode();

    void AddChild( TreeNode *pChild, const vector<int> &labels);
    void SetLabel( const string str ) {label = str;}
    bool IsLeaf() const {return listChildren.size() == 0;}
    void AddNodeValue(int val) {nodeValues.push_back( val ); }
    int GetChildrenNum() { return listChildren.size(); }
    TreeNode* GetChild( int i  )  { return listChildren[i]; }
    void GetDescendentLabelSet( set<int> &labelSet ) ;
    bool IsAncesterOf(TreeNode *pAssumedDescend, int &branchIndex);
    int GetID() const {return id;}
	void SetID(int i) {id = i;}
    string GetLabel() {return label;}
    TREE_NODE_SHAPE GetShape() {return shape;}
    void SetShape(TREE_NODE_SHAPE param) {shape = param;}
	void GetEdgeLabelsAtBranch(int i, vector<int> &labels) {labels = listEdgeLabels[i];}

private:
    vector< TreeNode *> listChildren;
    vector< vector<int> > listEdgeLabels;       // What labels is used in the edge
    TreeNode *parent;
    int id;       // id of this node, should be UNIQUE
    vector<int>     nodeValues;         // A node can have several values, for example, nodes labeling
                                        // CAUTION: we assume node value is >=0 !!!!!
    string label;
    TREE_NODE_SHAPE  shape;
} ;



// ***************************************************************************
// Utilities
// ***************************************************************************

// ***************************************************************************
// Define phylogeny tree class
// ***************************************************************************

class PhylogenyTree
{
public:
    PhylogenyTree();        // Empty tree
    ~PhylogenyTree();
    bool ConsOnBinMatrix( const BinaryMatrix &mat );       // Build tree from binary matrix
    void InitPostorderWalk(  );             // when walk, return the value of the node if any
    TreeNode *NextPostorderWalk( );
    void OutputGML ( const char *inFileName );
    void ConsNewick( string &strNewick );
    TreeNode *AddTreeNode( TreeNode *parNode, int id );
    void ConsOnNewick( const string &nwString );
    int GetNumVertices() const;
    void SetRoot(const vector<int> &rootToSet) { knownRoot = rootToSet; }
	void GetNodeParInfo( vector<int> &nodeIds, vector<int> &parPos );
	bool ConsOnParPosList( const vector<int> &parPos  );
	void GetLeaveIds( set<int> &lvids );

private:
    void GetARoot( const BinaryMatrix &mat, vector<int> &root );
    void RadixSortByCol(const BinaryMatrix &mat, const vector<int> &root,  vector<int> &sortList);
    void SortByOneBit(int bitPosRow, const BinaryMatrix &mat, const vector<int> &root, vector<int> &sortList);
    void RemoveDupSites( const BinaryMatrix &mat, vector<int> &sortedPosList, vector< vector<int> >& duplicates  );
    void ComputeLijLj( const BinaryMatrix &mat, const vector<int> &root, const vector<int> &sortedPosList,
        vector<int*> &Lij, vector<int> &Lj);
    bool ExamineLijLj( const BinaryMatrix &mat, const vector<int> &root, const vector<int> &sortedPosList, 
        const vector<int *> &Lij, const vector<int> &Lj );
    void BuildTree( const BinaryMatrix &mat, const vector<int> &root, const vector<int> &sortedPosList, 
        const vector< vector<int> > &duplicates,  const vector<int> &Lj );
    void CleanupTree(const BinaryMatrix &mat);
    void PostOrderPushStack( TreeNode *treeNode,  stack<TreeNode *> &stackPostorder);
    string ConsNewickTreeNode( TreeNode *pNode );
    TreeNode * ConsOnNewickSubtree( const string & nwStringPart, int &invId );
	bool ConvParPosToNewick( const vector<int> &parPos, string &strNewick );
	void ConvParPosToNewickSubtree( int nodeInd, const vector<int> &parPos, string &strNewick );

    // Privaet data members
    TreeNode *rootNode;
    vector<int> knownRoot;

    // Postoder traversal
    stack<TreeNode *> stackPostorder;
};



#endif  // PHYLOGENY_TREE_H
