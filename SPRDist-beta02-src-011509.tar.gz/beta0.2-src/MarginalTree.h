#ifndef MARGINAL_TREE_H
#define MARGINAL_TREE_H


#include <stack>
#include <vector>
using namespace std;

#include "Utils.h"
#include "Utils2.h"
#include "Utils3.h"




///////////////////////////////////////////////////////////////////////////////////////////////
// Define a simple coalescent tree. My experience shows that such a data structure can 
// be quite useful


// yet another structure to represent marginal tree

class MarginalTree
{
public:
    MarginalTree();
    void Clear();
    void Binarize();
    void Consolidate();
    void BuildDescendantInfo();
    void InitDefaultEdgeLen();
    double GetDefaultEdgeLen( int child );
    void SetParent( int child, int par );
    int GetParent( int child ) const;
    int GetLeftDescendant( int node ) const;
    int GetRightDescendant( int node ) const;
    double GetEdgeLen( int childNodeIndex ) const;
    int GetTotNodesNum() const  {return listNodeLabels.size();}
    int GetNumLeaves() const {return numLeaves;}
    void ConsDecedentInfo( vector<vector<int> > &descNodes ) const;
    void ConsAllDecedentInfo( vector<set<int> > &descNodes, bool fIncSelf = true ) const;
    void ConsDecedentLeavesInfo( vector<set<int> > &descNodes ) const;
    void ConsHeightsInfo( vector<int> &nodesHt ) const;
    void Dump() const;
    int GetLabel(int r) const 
    {  YW_ASSERT_INFO( r >= 0 && r <(int)listNodeLabels.size(), "wrong");  return listNodeLabels[r]; }
    bool IsLeaf( int node ) const { return node < numLeaves; }
    bool IsToplogicSame( const MarginalTree &tree ) const;
    int GetMRCA(int v1, int v2) const;
    void GetChildren(int node, set<int> &listChildren) const;
    int GetMaxHt() const;
    void RemoveLeafNodeFromBinaryTree( int lfn );
    bool AreTwoPathsDisjoint( int sn1, int en1, int sn2, int en2 ) const;
    int GetPath( int sn, int en, set<int> &edgesOnPath ) const;
    void OutputGML( const char *fileName ) const;
    void GetLeavesUnder( int nn, set<int> &leavesUnder) const;
    void GetLeafSetsForCuts( const vector<int> &listCuts, vector< set<int> > &listLeafSets )  const;
    int GetMRCAForNodes( const set<int> & listNodes ) const;
    bool IsNodeUnder( int nn, int ancesNode) const;
    void RandPermuateLeaves();

public:
    int  CalcNormHeight( int node);
	void GetParPosInfo( vector<int> &parPosList ) {parPosList = listParentNodePos;}


    // Use an array to store  leaves
    int numLeaves;
    // assume the first numLeaves nodes are leaves
    vector<int> listNodeLabels;
    vector<int> listParentNodePos;
    vector< double > listEdgeDist;
    vector<int> listLeftDescs;
    vector<int> listRightDescs;

private:

};


///////////////////////////////////////////////////////////////////////////////////////////////
// Global Utilities
bool ReadinMarginalTrees( ifstream &inFile, vector<MarginalTree> &treeList);
bool ReadinMarginalTreesNewick( ifstream &inFile, int numLeaves, vector<MarginalTree> &treeList);
void AddRootAsLeafToTree( MarginalTree &tree1 );
void GenRandBinaryTree( int numLeaves, MarginalTree &tree1);
// vector<int>: list of leaves in the order from top down, int = top node of chain
void FindChainsInTree( const MarginalTree &tree1,  map< vector<int>, int > &foundChains  );
void InitMarginalTree(MarginalTree &mTree,  int numLeaves, const vector<int> &listLabels, const vector<int> &listParentNodePos );

#endif  // MARGINAL_TREE_H

