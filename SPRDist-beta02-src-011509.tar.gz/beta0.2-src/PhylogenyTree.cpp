#include <stack>
#include <fstream>
#include <iostream>
#include "PhylogenyTree.h"

// ***************************************************************************
// The following code is largely based on Gusfield's 1991 Paper
// ***************************************************************************
extern void OutputQuotedString(ofstream &outFile, const char *buf);


// ***************************************************************************
// Tree class functions
// ***************************************************************************
TreeNode :: TreeNode() : id(-1), parent(NULL), label("-"), shape(PHY_TN_DEFAULT_SHAPE)
{
}

TreeNode :: TreeNode(int iid)  : parent(NULL), label("-"), shape(PHY_TN_DEFAULT_SHAPE)
{
    id = iid;
//    cout << "Creating tree node " << iid << endl;
}

TreeNode :: ~TreeNode()
{
//    cout << "Deleting tree node " << id << endl;
    // We recursively delete all its children here
    for(int i=0; i<listChildren.size(); ++i)
    {
        delete listChildren[i];
    }
    listChildren.clear();
}



void TreeNode :: AddChild( TreeNode *pChild, const vector<int> &labels)
{
    // This function add an edge. The edge can be labeled with a set of labels (for now, only integers)
    YW_ASSERT( pChild != NULL);

    // make sure this child is not already a children
    // not sure if really need it

    pChild->parent = this;
    listChildren.push_back( pChild );
    listEdgeLabels.push_back( labels );
}
    

void TreeNode :: GetDescendentLabelSet( set<int> &labelSet ) 
{
    // This function accumulate the set of descendents in the label sets
    // CAUTION: assume labelset is EMPTY!!!!
    //if( IsLeaf() == true)
    //{
    string lbl = GetLabel();
//cout << "lbl = " << lbl << endl;

    if( lbl != "-" && lbl != "?" && lbl != "()" && lbl != "(?)" )
    {
        const char *buf = lbl.c_str();
        int rowIndex;
        if( buf[0] < '0' || buf[0] > '9' )
        {
            sscanf( buf+1, "%d", &rowIndex );
        }
        else
        {
            // This is a plain label, use it
            sscanf( buf, "%d", &rowIndex );
        }
//cout << "rowIndex = " << rowIndex << endl;
        labelSet.insert( rowIndex );
    }
    else if( nodeValues.size() >= 1 )
    {
            // simply insert a single value here
            //labelSet.insert( nodeValues[0] );
    }

#if 0
        // set every label into the set
        for(int i=0; i<nodeValues.size(); ++i)
        {
            if( nodeValues[i] >= 0 )
            {
                labelSet.insert( nodeValues[i] );
            }
        }
#endif
    //}
    //else
    if( IsLeaf() == false)
    {
        for(int i=0; i<GetChildrenNum(); ++i)
        {
            GetChild(i)->GetDescendentLabelSet( labelSet );
        }
    }
}

bool TreeNode :: IsAncesterOf(TreeNode *pAssumedDescend, int &branchIndex)
{
    // This function check to see if pAssumedDescend is descedent of the current node
    // If so, we also find the branch index that comes to this node
    if( pAssumedDescend == NULL)
    {
        return false;
    }
    if( pAssumedDescend == this)
    {
        branchIndex = -1;
        return true;
    }

    TreeNode *pCurrent = pAssumedDescend;
    TreeNode *pParent = pAssumedDescend->parent;

    while(pParent != NULL)
    {
        if(pParent == this)
        {
            // Find out which branch leads to it
            branchIndex = -1;
            for(int i=0; i<listChildren.size();++i)
            {
                if(listChildren[i] == pCurrent)
                {
                    branchIndex = i;
                }
            }
            YW_ASSERT( branchIndex >= 0);
            // Tell the good news
            return true;
        }
        pCurrent = pParent;
        pParent = pParent->parent;
    }
    

    return false;
}

// ***************************************************************************
// Utilites functions
// ***************************************************************************


void PhylogenyTree :: GetARoot( const BinaryMatrix &mat, vector<int> &root )
{
    if( knownRoot.size() > 0 )
    {
        root = knownRoot;
        return;
    }

    // We take the majority sequence as root. Refer to the paper for details
    root.clear();
    for(int c=0; c<mat.GetColNum(); ++c)
    {
        int rc = 0;
        int numOne = 0;
        for(int r = 0; r < mat.GetRowNum(); ++r)
        {
            if( mat( r, c ) == 1)
            {
                numOne++;
            }
        }
		// 12/08/07: fixed. Must consider the case say 6 0 and 5 1,
		// has to plus one to ensure correctness
        if( numOne >= (mat.GetRowNum()+1)/2 )
        {
            rc = 1;
        }
        root.push_back ( rc );
    }
//    cout << "Root = ";
//    DumpIntVec ( root );
}

void PhylogenyTree :: RadixSortByCol(const BinaryMatrix &mat, const vector<int> &root,  vector<int> &sortList)
{
//cout << "root = ";
//DumpIntVec( root );
    // This is the step 1 of Gusfield tree building algorithm
    // We treat each column as a number, encoded by the binary vecgtor stored in the column
    // row 1 contains the MSB of the number
    // The result is stored in a sorted list, with LARGEST number comes in first
    // For details of radix sort, refer CLR
    sortList.clear();
    for(int i=0; i<mat.GetColNum(); ++i)
    {
        sortList.push_back ( i );
    }

    // Now sort from LSB of the number, i.e. last row first
    for(int i=mat.GetRowNum() -1; i>=0; --i)
    {
        SortByOneBit(i, mat, root, sortList);
    }
}

void PhylogenyTree :: SortByOneBit(int bitPosRow, const BinaryMatrix &mat, const vector<int> &root, 
                                   vector<int> &sortList)
{
//cout << "bitPosRow = " << bitPosRow << endl;
//cout << "root here = ";
//DumpIntVec( root );
//cout << "entry sortList = ";
//DumpIntVec( sortList );
    // Sort the list by one bit (the ith row)
    // Initailize a pre-list, holding the last sorted list. Simply initailize to original order
    vector<int> preList = sortList;
    sortList.clear();

    // We do two path, first to find 1 cells in that row and next one cell (since we want the LARGEST first)
    // This is in fact counting sort, with k (the limit) == 1
    for(int i=0; i<preList.size(); ++i)
    {
        // Note that we 1 = NON-ROOT-VALUE
// cout << "mat(bitPosRow, preList[i] ) = " << mat( bitPosRow, preList[i]  ) << endl;
        if(  mat( bitPosRow, preList[i]  ) != root[ preList[i]  ]  )
        {
            sortList.push_back( preList[ i ]  );
        }
    }
//cout << "parital sortList = ";
//DumpIntVec( sortList );

    for(int i=0; i<preList.size(); ++i)
    {
        if(  mat( bitPosRow, preList[i]  ) == root[ preList[i] ]  )
        {
            sortList.push_back(  preList[i]  );
        }
    }
//cout << "exit sortList = ";
//DumpIntVec( sortList );
}

void PhylogenyTree :: RemoveDupSites( const BinaryMatrix &mat, vector<int> &sortedPosList, 
                                     vector< vector<int> >& duplicates )
{
    // This function takes the sorted list, and then remove the duplicate sites
    // by comparing one site to its left row, if duplicate, do not put into new list
    vector<int> noDupList;
    if(sortedPosList.size() > 0)
    {
        noDupList.push_back ( sortedPosList[0] );
    }
    vector<int> dupList;    // store which sites are duplicates to this one
    for(int i=1; i<sortedPosList.size(); ++i)
    {
        bool match = true;
        // Check to see if this column is the same as its immediate left one
        for(int r = 0; r<mat.GetRowNum(); ++r )
        {
            if(  mat(r, sortedPosList[i] ) != mat(r, sortedPosList[i-1] )  )
            {
                match = false;
                break;
            }

        }
        if(match == false)
        {
            noDupList.push_back( sortedPosList[i] );

            // Now we maintian the duplicate list
//cout << "for site " << noDupList[noDupList.size() - 2] << ", duplicate sites are: ";
//DumpIntVec( dupList );

            duplicates.push_back ( dupList );
            dupList.clear();
        }
        else
        {
            // This site is the same as its immediate left one
            dupList.push_back(  sortedPosList[i] );
        }
    }

    // Finally, add the final list to it
    duplicates.push_back ( dupList );
//cout << "for site " << noDupList[noDupList.size() - 1] << ", duplicate sites are: ";
//DumpIntVec( dupList );
    dupList.clear();


    // Now set the noDupList to result
    sortedPosList.clear();
    sortedPosList = noDupList;
}

void PhylogenyTree :: ComputeLijLj( const BinaryMatrix &mat, const vector<int> &root, const vector<int> &sortedPosList,  
                                   vector<int*> &Lij, vector<int> &Lj)
{
//    cout << "sortedPosList = ";
//    DumpIntVec( sortedPosList );

    // Build Lij and Lj according to the algorithm
    // CAUTION: you have to keep in mind that Lij, Lj are all based on M', not M
    // so do a conversion before use
    for(int i=0; i<mat.GetRowNum(); ++i)
    {
        int last1Pos = -1;
        for(int j=0; j<sortedPosList.size(); ++j)
        {
            if(  mat(i, sortedPosList[j] ) != root[ sortedPosList[j]  ]   )
            {
                // We find a one here, good
                Lij[ i ][ j ] = last1Pos;

//cout << "at (" << i << ", " << j << "), Lij = " << last1Pos << endl;

                // Remember it
                last1Pos = j;
            }
        }
    }

    // Now we computes the Lj vector
    Lj.clear();
    for( int j=0; j<sortedPosList.size(); ++j  )
    {
        int max = -1;
        for(int r=0; r<mat.GetRowNum(); ++r)
        {
            if( mat(r, sortedPosList[j] ) != root[ sortedPosList[j]  ]  &&     Lij[r][j] > max )
            {
                max = Lij[r][j];
            }
        }
        // Now set Lj
        Lj.push_back ( max );
//cout << "At j = " << j << ", Lj = " << max << endl;
    }
}

bool PhylogenyTree :: ExamineLijLj( const BinaryMatrix &mat, const vector<int> &root, const vector<int> &sortedPosList, 
                                   const vector<int *> &Lij,  const vector<int> &Lj )
{
//cout << "Examine here...\n";
    for(int i=0; i<mat.GetRowNum(); ++i)
    {
        for(int j=0; j<sortedPosList.size(); ++j)
        {
            if(  mat(i, sortedPosList[j] ) != root[ sortedPosList[j] ]   &&  Lj[j] != Lij[i][j]   )
            {
 //cout << "At (" << i << ", " << j << "), Lij = " << Lij[i][j] << ", but Lj = " << Lj[j] << endl;
                return false;
            }
        }
    }
//cout << "done here.\n";
    return true;    // yes, there is a tree
}

void PhylogenyTree :: BuildTree( const BinaryMatrix &mat, const vector<int> &root, const vector<int> &sortedPosList, 
    const vector< vector<int> > &duplicates,  const vector<int> &Lj )
{
    // This function creates the tree by creating and linking tree nodes
    // Make sure the tree is empty
    if( rootNode != NULL)
    {
        delete rootNode;
        rootNode = NULL;
    }

    // root is labeled as -1, since all other (column) nodes are labeled by a site
    rootNode = new TreeNode(-1);

    // Create a node for each site
    vector<TreeNode *> colNodes;
    for(int i=0; i<sortedPosList.size(); ++i)
    {
        TreeNode *pNode = new TreeNode( sortedPosList[i] ); // for now, use original labels to do it
        colNodes.push_back ( pNode );
    }

    // Link each node Nj (where L(j) >= 0) to that L(j) node
    for(int j=0; j<Lj.size(); ++j)
    {
         // Figure out the labels
        vector<int> labels;
        labels.push_back ( sortedPosList[j]  );
        // Add those in the duplicates
        for(int dup = 0; dup<duplicates[j].size(); ++dup)
        {
            labels.push_back ( duplicates[j][dup] );
        }
        if(  Lj[j] >= 0  )
        {
            // Link it
            TreeNode *nodeLj = colNodes[ Lj[j] ];

            // Add it
            nodeLj->AddChild( colNodes[j], labels );
//cout << "Add col node " << sortedPosList[j]  << " under node " << sortedPosList[ Lj[j] ] << ".\n";
        }
        else
        {
            // For this node, we link it from the root
            rootNode->AddChild( colNodes[j], labels ); 
//cout << "Add col node " << sortedPosList[j]  << " under root.\n";
        }
    }

    // Now add rows into this tree
    for(int i=0; i<mat.GetRowNum(); ++i)
    {
        int ci = -1;
        // Find ci that is the largest cell has one in row i
        for(int j=sortedPosList.size()-1; j>=0; j--)
        {
            if(  mat(i, sortedPosList[j]   ) != root[  sortedPosList[j]  ]  )
            {
                ci = j;
                break;
            }
        }
        if( ci < 0)
        {
        //    cout << "trouble here.\n";
        //    YW_ASSERT(false);
            // This is the same as the root sequence
            TreeNode *pLeaf = new TreeNode( mat.GetColNum() + i   );       // Use id=row index + colNum
            pLeaf->AddNodeValue( i );
            // also set its label
            char buf[100];
            sprintf( buf, "(%d)", i );
            pLeaf->SetLabel( buf );

            vector<int> emptyLabel;
            rootNode->AddChild( pLeaf, emptyLabel );
//cout << "Add row " << i << " under root node.\n";

        }
        else
        {
            // Here we always add a node as children. CAUTION: here we may create degree-2 nodes, 
            // we need to cleanup after this
            // 06/05/05: actually I decided to go another way: put to leaf first, then splits the 
            // multiple labels into different leaves if needed
            TreeNode *pn = colNodes[ ci ];
            if( pn->IsLeaf() == true)
            {
                // also set its label
                char buf[100];
                sprintf( buf, "(%d)", i );
                pn->SetLabel( buf );

                // Now attach this row to the existing leaf, HOW?
                pn->AddNodeValue(  i  );
//cout << "Add row " << i << " to a leaf (col node) " << sortedPosList[ci]  << ".\n";

            }
            else
            {
                TreeNode *pLeaf = new TreeNode( mat.GetColNum() + i   );       // Use id=row index + colNum
                pLeaf->AddNodeValue( i );
                // also set its label
                char buf[100];
                sprintf( buf, "(%d)", i );
                pLeaf->SetLabel( buf );

                vector<int> emptyLabel;
                pn->AddChild( pLeaf, emptyLabel );
//cout << "Add row " << i << " to a non-leaf (col node) " << sortedPosList[ci]  << ".\n";

            }
        }

    }

}


void PhylogenyTree :: CleanupTree( const BinaryMatrix &mat )
{
    // This function removes all degree-2 nodes
    // we start from the root and remove any node with degree 2
    // 06/05/05: take another route, breakup multiple labels
    TreeNode *curTN = NULL;
    stack<TreeNode *> stackNodes;
    if(rootNode != NULL)
    {
        stackNodes.push(rootNode );
    }

    while( stackNodes.empty() == false )
    {
        // Move to next node in stack
        curTN = stackNodes.top();
        stackNodes.pop();

        // For a leaf, we try to split it
        if( curTN->IsLeaf() == true && curTN->nodeValues.size() > 1 )
        {
            for(int i = 0; i< curTN->nodeValues.size() ; ++i)
            {
                // Find one to split
                TreeNode *pLeaf = new TreeNode( mat.GetColNum() +  curTN->nodeValues[i]  );       // Use id=row index + colNum
                pLeaf->AddNodeValue( curTN->nodeValues[i] );
                vector<int> emptyLabel;
                curTN->AddChild( pLeaf, emptyLabel );
//cout << "Spliting row " << curTN->nodeValues[i] << " from leaf " << curTN->id  << ".\n";

                // Set the label to the individual nodes values
                char buf[100];
                sprintf( buf, "(%d)", curTN->nodeValues[i]   );
                pLeaf->SetLabel( buf );

                
            }

            // Finally, clear the labels at parent node
            curTN->nodeValues.clear();

            // We also clear the old label
            curTN->SetLabel("-");
        }


        // push children into stack
        for(int i=0; i<curTN->listChildren.size(); ++i)
        {
            stackNodes.push(curTN->listChildren[i]);
        }

    }
}

void PhylogenyTree :: PostOrderPushStack( TreeNode *treeNode,  stack<TreeNode *> &stackPostorder)
{
    stackPostorder.push( treeNode);
//cout << "Pusing node " << treeNode->GetLabel() << endl;

    for(int i=0; i<treeNode->listChildren.size(); ++i)
    {
        PostOrderPushStack( treeNode->listChildren[i],  stackPostorder);
    }
}

// ***************************************************************************
// Main functions
// ***************************************************************************

PhylogenyTree :: PhylogenyTree() :  rootNode(NULL)
{
}

PhylogenyTree :: ~PhylogenyTree() 
{
    // Should delete the tree
    if( rootNode != NULL)
    {
        delete rootNode;
        rootNode = NULL;
    }
}


bool PhylogenyTree :: ConsOnBinMatrix( const BinaryMatrix &mat )
{
    // Build tree from binary matrix
    vector<int> sortedPosList;

    // We first find a good root from data
    vector<int> root;
    GetARoot( mat, root );

    // We first sort columns (treated as binary number) by putting the largest first
    RadixSortByCol(mat, root,  sortedPosList);

//cout << "the sorted column list is: \n";
//DumpIntVec( sortedPosList);

    // Remove Duplicate columns
    vector< vector<int> > listDuplicates;       // used to save for each one in sortedPosList
                                                // the sites to its right that is duplicate as it, in ORIGINAL numbering
    RemoveDupSites( mat, sortedPosList, listDuplicates );
//cout << "the no duplicate sorted column list is: \n";
//DumpIntVec( sortedPosList);


    // Now we compute the Lij and Lj values, from Gusfield's algorithm
    vector<int *> Lij;
    for(int i=0; i<mat.GetRowNum(); ++i)
    {
        int *pbuf = new int[sortedPosList.size()];
        Lij.push_back ( pbuf );
    }
    vector<int> Lj;
    ComputeLijLj(mat, root, sortedPosList, Lij, Lj);
    if( ExamineLijLj( mat, root, sortedPosList, Lij, Lj ) == false)
    {
        cout << "No tree.\n";
        return false;       // no tree
    }
    // Now we start to build tree here
    BuildTree( mat, root, sortedPosList, listDuplicates,  Lj );
//cout << "Yes, there is a tree here.\n";

    // Finally, we cleanup
    CleanupTree(mat);


    // Now we have to do cleanup
    for(int i=0; i<Lij.size(); ++i)
    {
        delete []   Lij[i];
    }

    return true;
}


void PhylogenyTree :: ConsOnNewick( const string &nwString )
{
    // Here we try to reconstruct from a newick string here
    // This function creates the tree by creating and linking tree nodes
    // Make sure the tree is empty
    if( rootNode != NULL)
    {
        delete rootNode;
        rootNode = NULL;
    }

    // we perform this by recursively
    int invId = 10000;
    rootNode = ConsOnNewickSubtree( nwString, invId );

}


void PhylogenyTree :: InitPostorderWalk( )
{
//cout << "InitPostorderWalk() entry\n";
    // when walk, return the value of the node if any
    // Clearup the previous storage if any
    while( stackPostorder.empty() == false)
    {
        stackPostorder.pop();
    }
//cout << "Nnow stack empty.\n";
    // Now recurisvely store the order of the walk
    if( rootNode != NULL)
    {
        PostOrderPushStack( rootNode,  stackPostorder);
    }
}

TreeNode *PhylogenyTree :: NextPostorderWalk( )
{
    // Return false, when nothing to go any more
    if( stackPostorder.empty() == true)
    {
        return NULL;
    }
    TreeNode *pn = stackPostorder.top();
    stackPostorder.pop();

//    node = pn;
#if 0
    if( pn->nodeValues.size() > 0 )
    {
        // There is valid node value stored here
        nodeValue = pn->nodeValues[0];
    }
    else
    {
        nodeValue = -1;     // no node value is stored here
    }
#endif
    return pn;
}

void PhylogenyTree :: OutputGML ( const char *inFileName )
{
	// Now output a file in GML format
	// First create a new name
	string name = inFileName;
//cout << "num edges = " << listEdges.size() << endl;

	DEBUG("FileName=");
	DEBUG(name);
	DEBUG("\n");
	// Now open file to write out
	ofstream outFile( name.c_str() );

	// First output some header info
	outFile << "graph [\n"; 
	outFile << "comment ";
	OutputQuotedString(outFile, "Automatically generated by Graphing tool");
	outFile << "\ndirected  1\n";
	outFile << "id  1\n";
	outFile << "label ";
	OutputQuotedString ( outFile, "Phylogeny Tree....\n");

	// Now output all the vertices
//	int i;
	stack<TreeNode *> nodesStack;
    if( rootNode != NULL)
    {
        nodesStack.push( rootNode );
    }
//cout << "a.1.1\n";
	while(  nodesStack.empty() == false )
	{
        TreeNode *pn = nodesStack.top();
        nodesStack.pop();

		outFile << "node [\n";

		outFile << "id " <<  pn->id  << endl;
		outFile << "label ";
 		string nameToUse = " ";
        if( pn->GetLabel()  != "-" )
        {
          nameToUse = pn->GetLabel();
        }
#if 0
        else
        {
            // we take the nonde value here
            char buf[100];
            if( pn->nodeValues.size() > 0 )
            {
                sprintf(buf, "(%d)", pn->nodeValues[0] );        // CAUTION, here we assume each leaf has exactly 1 label
                nameToUse = buf;
            }
            else
            {
                // if no nodes value is set, still use label
         //       nameToUse = pn->GetLabel();

                // YW: TBD change
                nameToUse.empty();
            }
        }
#endif
        const char *name = nameToUse.c_str();

// 		char name[100];
//       if( pn->IsLeaf() == false)
//        {
//		    name[0] = 'v'; 
//		    sprintf(&name[1], "%d", pn->id);
//        }
//        else
//        {
            // For leaf, we simply output their value (row number)
//            sprintf(name, "%d", pn->nodeValues[0] );        // CAUTION, here we assume each leaf has exactly 1 label
//        }
        OutputQuotedString (outFile,  name  ); 
		outFile << endl;

        // See if we need special shape here
        if( pn->GetShape() == PHY_TN_RECTANGLE)
        {
            outFile << "vgj [ \n shape  ";
            OutputQuotedString( outFile, "Rectangle");
    		outFile << "\n]\n";
        }
        else
        {
		    outFile << "defaultAtrribute   1\n";
        }
        
		outFile << "]\n";

        // Now try to get more nodes
        for(int i=0; i<pn->listChildren.size(); ++i)
        {
            nodesStack.push( pn->listChildren[i] );
        }
//cout << "a.1.2\n";
	}
//cout << "a.1.3\n";

	// Now output all the edges, by again starting from root and output all nodes
    YW_ASSERT( nodesStack.empty() == true );
    if( rootNode != NULL)
    {
        nodesStack.push( rootNode );
    }
	while(  nodesStack.empty() == false )
	{
        TreeNode *pn = nodesStack.top();
        nodesStack.pop();
        
        for(int i=0; i<pn->listChildren.size(); ++i)
        {
        
//cout << "Output an edge \n"; 
			outFile << "edge [\n";
			outFile << "source " << pn->id << endl; 
			outFile << "target  " << pn->listChildren[i]->id << endl; 
			outFile << "label " ;
            if( pn->listEdgeLabels[i].size() >0 )
            {
                string lblName;
		        char name[100];
//		        name[0] = 'e'; 
                for(int iel =0; iel<pn->listEdgeLabels[i].size(); ++iel )
                {
		            sprintf(name, "e%d  ", pn->listEdgeLabels[i][iel]  );
                    lblName += name;
                }
			    OutputQuotedString( outFile,  lblName.c_str()  );
            }
            else
            {
			    OutputQuotedString( outFile,  ""  );
            }
			outFile << "\n";
			outFile << "]\n";
    
            // Store next one to stack
            nodesStack.push( pn->listChildren[i] );
		}
	}


	// Finally quite after closing file
	outFile << "\n]\n";
	outFile.close();
}

// construct a newick string for this tree
void PhylogenyTree :: ConsNewick( string &strNewick )
{
    strNewick.empty();

    // work from this node
	YW_ASSERT_INFO( rootNode != NULL, "Root is not set" );
    strNewick =  ConsNewickTreeNode( rootNode );
}

string PhylogenyTree :: ConsNewickTreeNode( TreeNode *pNode )
{	

    // Is this node a leaf? If so, we output the label of it
    if( pNode->IsLeaf() == true )
    {
        // Add this label if this label is not there
//        if( pNode->nodeValues.size() > 0 )
//        {
//            char buf[1024];
//            sprintf(buf, "%d", pNode->nodeValues[0] );        // CAUTION, here we assume each leaf has exactly 1 label
//            return buf;
        string tmpstr = pNode->GetLabel();
        if( tmpstr.size() > 2 )
        {
            return tmpstr.substr( 1, tmpstr.size()-2   );
        }
        else
        {
            string emptyStr;
            return emptyStr;
        }
    }
    else
    {
        string tmpstr = pNode->GetLabel();
        YW_ASSERT_INFO(pNode->listChildren.size() >=1, "Must have some children here.");

        // When there is only one child and no self-label
        if( tmpstr.size() <=2 &&  pNode->listChildren.size() == 1 )
        {
            return ConsNewickTreeNode( pNode->listChildren[0]  );
        }


        // Otherwise, we simply collect all sub strings here, and sepearate by a ,
        string comboStrName = "(";

        bool fAddSep = false;
        // does this node has a label by itself? if so, output it
        if( tmpstr.size() > 2 )
        {
            comboStrName += tmpstr.substr( 1, tmpstr.size()-2   );
            //comboStrName += ",";

            // all others should be added sep.
            fAddSep = true;
        }


        // handle its children
        for(unsigned int i=0; i<pNode->listChildren.size(); ++i)
        {
            string stepRes = ConsNewickTreeNode( pNode->listChildren[i]  );

            if( stepRes.size() > 0 )
            {
                if( fAddSep == true )
                {
                    comboStrName += ",";
                }

                comboStrName += stepRes;

                // from now on, add sep 
                fAddSep = true;

                //if( i+1 < pNode->listChildren.size() )
                //{
                //    comboStrName += ",";
                //}
            }
        }
        comboStrName += ")";
//cout << "comboStrName = " << comboStrName << endl;
        return comboStrName;
    }


}



// This function adds a new tree node, and return it. Also set the parent node to the pareamter
TreeNode *PhylogenyTree :: AddTreeNode( TreeNode *parNode, int id )
{
    if( id < 0)
    {
        id = GetNumVertices();
    }

    TreeNode *pnode = new TreeNode(id);
    pnode->AddNodeValue( id );

    // Should delete the tree
    if(  parNode == NULL)
    {
        YW_ASSERT_INFO(rootNode == NULL, "Can not add a node with no parent if the tree is not empty");
        rootNode = pnode;
        return pnode;
    }

    // Otherwise, set the parent
    SEQUENCE emptySeq;
    parNode->AddChild( pnode,  emptySeq);
    return pnode;
}

int PhylogenyTree :: GetNumVertices() const
{
    int res = 0;
    stack<TreeNode *> stackNodes;
    if( rootNode != NULL )
    {
        stackNodes.push( rootNode );
    }
    while( stackNodes.empty() == false )
    {
        TreeNode *pcurr = stackNodes.top();
        stackNodes.pop();
        ++res;
        // Now enque its children
        for(int i=0; i<pcurr->listChildren.size(); ++i)
        {
            stackNodes.push( pcurr->listChildren[i]  );
        }
    }
    return res;
}

TreeNode * PhylogenyTree :: ConsOnNewickSubtree( const string & nwStringPart, int &invId )
{
//cout << "Entry nwStringPart = "<< nwStringPart << endl;

    // this function builds recursively subtrees for this part of string
    // First, is this string a leaf or not
    if( nwStringPart[0] != '('  )
    {
        // Yes, this is a leaf
        int nodeId;
        sscanf( nwStringPart.c_str(), "%d", &nodeId  );
//cout << "leaf id = " << nodeId << endl;
        TreeNode *pLeaf = new TreeNode( nodeId  );
        // also set its label this way
        pLeaf->AddNodeValue( nodeId );
        pLeaf->SetLabel( nwStringPart );

        return pLeaf;
    }
    else
    {
        // This is not a leaf
        // so we create underlying level for it
        TreeNode *pInternal = new TreeNode( invId++  );
        int lastpos = 1;
        int curpos = 0;
        int parnet = 0; // (: +1, ) -1
        while( true )
        {
//cout << "curpos = " << curpos << endl;

            if( curpos >= (int) nwStringPart.size() )
            {
                // we are done
                break;
            }


            // keep balance
            if( nwStringPart[curpos] == '(' ) 
            {
                parnet ++;
            }
            else if( nwStringPart[curpos] == ')'  )
            {
                parnet --;

                // when parnet = 0, we know we end
                if( parnet == 0 )
                {
                    // now adding the last piece
                    // create a new node
                    int strl = curpos-lastpos;
                    string subs = nwStringPart.substr( lastpos, strl );
//    cout << "last subs = " << subs << endl; 
                    TreeNode *pChild = ConsOnNewickSubtree( subs, invId );

                    // also append it as child
                    vector<int> empytLabels;
                    pInternal->AddChild( pChild, empytLabels );

                    // aslo update lastpos
                    lastpos = curpos+1;
                }

            }
            else if( nwStringPart[curpos] == ','  )
            {
                // Yes, this is a sepeartor, but we only start to process it when the
                // balance of parenetnis is right
                if( parnet == 1 )
                {
                    // create a new node
                    int strl = curpos-lastpos;
                    string subs = nwStringPart.substr( lastpos, strl );
//    cout << "subs = " << subs << endl; 
                    TreeNode *pChild = ConsOnNewickSubtree( subs, invId );

                    // also append it as child
                    vector<int> empytLabels;
                    pInternal->AddChild( pChild, empytLabels );

                    // aslo update lastpos
                    lastpos = curpos+1;
                }
           }


            // now move to next pos
            curpos ++;
        }

        return pInternal;
    }
}

// Get nodes info
void PhylogenyTree :: GetNodeParInfo( vector<int> &nodeIds, vector<int> &parPos )
{
	// simply put consecutive node ids but keep track of node parent positions
	// ensure we get the correct node mapping between id and pointer to node
	map<TreeNode *,int> mapNodeIds;

	// id is simply consecutive
	int numTotVerts = GetNumVertices();
	nodeIds.resize(numTotVerts);
	for(int i=0; i<numTotVerts; ++i)
	{
		nodeIds[i] = i;
	}
	parPos.resize(numTotVerts);
	for(int i=0; i<numTotVerts; ++i)
	{
		parPos[i] = -1;
	}

	// IMPORTANT: assume binary tree, otherwise all bets are off!!!!
	int numLeaves = ( numTotVerts+1 )/2;

	// do traversal
	int curNodeNum = 0;
	InitPostorderWalk();
	while(true)
	{
        TreeNode *pn = NextPostorderWalk( ) ;
        if( pn == NULL)
        {
//cout << "No node here. Stop.\n";
            break;      // done with all nodes
        }

		// 
		if( pn->IsLeaf() == true  )
		{
			// skip it for now
			continue;
		}

		// 
		int nonleafInd = numLeaves + curNodeNum;
		curNodeNum++;
		// remember it
		mapNodeIds.insert( map<TreeNode *,int> :: value_type( pn, nonleafInd ) );
		// now set its descendents to this index, either leaf or non-leaf
		// if it is non-leaf, do a lookup of the stored id. Leaf: just go by its id
		for(int jj=0; jj<pn->GetChildrenNum(); ++jj)
		{
			TreeNode *pnjj = pn->GetChild(jj);
			int pnjjid;
			if( pnjj->IsLeaf() == true )
			{
				pnjjid = pnjj->GetID();
				YW_ASSERT_INFO( pnjjid >=0 && pnjjid < numLeaves, "Leaf id: out of range" );
			}
			else
			{
				YW_ASSERT_INFO( mapNodeIds.find( pnjj ) != mapNodeIds.end(), "Fail to find the node"  );
				pnjjid = mapNodeIds[pnjj];
			}
			parPos[pnjjid] = nonleafInd;
		}
	}

// print out
//cout << "original tree:  ";
//string strTree;
//ConsNewick(strTree);
//cout << strTree << endl;
//cout << "Parent position : ";
//DumpIntVec( parPos );
}

//
bool PhylogenyTree :: ConsOnParPosList( const vector<int> &parPos  )
{
	// 
	string strNewick;
	if( ConvParPosToNewick(parPos, strNewick) == false  )
	{
		return false;
	}
cout << "Newick string = " << strNewick << endl;
	ConsOnNewick(strNewick);
}

bool PhylogenyTree :: ConvParPosToNewick( const vector<int> &parPos, string &strNewick )
{
	// convert par position representation to newick
	// we always assume the last item is -1
	YW_ASSERT_INFO( parPos[parPos.size()-1] == -1, "Must be -1 for the last value in parPos" );
	ConvParPosToNewickSubtree( parPos.size()-1, parPos, strNewick );
	return true;
}

void PhylogenyTree :: ConvParPosToNewickSubtree( int nodeInd, const vector<int> &parPos, string &strNewick )
{
	// this function generate under a single node (leaf or non-leaf), the newick under the subtree
	vector<int> listUnderNodeInds;
	for(int i=0; i<(int)parPos.size(); ++i)
	{
		if( parPos[i] == nodeInd )
		{
			listUnderNodeInds.push_back( i );
		}
	}
	// leaf if empty
	if( listUnderNodeInds.size() == 0 )
	{
		char buf[100];
		sprintf( buf, "%d", nodeInd );
		strNewick = buf;
		return;
	}
	YW_ASSERT_INFO(listUnderNodeInds.size() == 2, "Only binary trees are supported for now");

	// now get newick for the two part and merge it
	string strFirst, strSecond;
	ConvParPosToNewickSubtree( listUnderNodeInds[0], parPos, strFirst );
	ConvParPosToNewickSubtree( listUnderNodeInds[1], parPos, strSecond );
	strNewick = "(";
	strNewick += strFirst;
	strNewick += ",";
	strNewick += strSecond;
	strNewick += ")";
}


void PhylogenyTree ::  GetLeaveIds( set<int> &lvids )
{
	lvids.clear();

	InitPostorderWalk();
	while(true)
	{
		TreeNode *pn = NextPostorderWalk( ) ;
		if( pn == NULL)
		{
			break;      // done with all nodes
		}
		if( pn->IsLeaf() == true )
		{
			lvids.insert(  pn->GetID()  );
		}
	}
}

